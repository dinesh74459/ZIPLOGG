# Current verified status - October 13, 2026

This section supersedes older dated notes below.
- Google OAuth Audience now shows In production after owner-approved publishing; retry succeeded. Public non-test-account login still needs a customer test.
- Search Console: 6 indexed pages, 2 search clicks; sitemap Success, last read October 11, 8 discovered pages. URL inspection returned a Google error. Older exclusion report is dated October 8.
- Owner confirmed business name ZIPLOGG, 214 Conant St, Manchester, NH 03102, USA; support +1 831-809-0310, operations@ziplogg.com. Contact details added to Help and policy draft.
- Owner confirms no Shippo Sales resale approval. Carrier dashboard Enabled does not mean platform resale approved. Previous FedEx test API returned account restricted.
- Stripe dashboard/account status currently returns Stripe engineering incident message; live eligibility not verified.
- Current pricing is comparable verified FedEx retail * 45%; eligible JAYHO first shipment * 80% of that. Migration 008 and customer-test-checkout listing deployed; 35 tests passed before contact-only update.
- Referral backend and checkout reservation protections are implemented. Real matched retail/account rate retrieval, label worker and end-to-end payment-label-email test remain unfinished. Live payments remain disabled.
- Policy page remains a draft: contact details alone do not finalize cancellation, claims, retention and carrier terms.

# Fulfillment status — 12 October 2026

## Verified
- Make scenario 6603753 is saved and inactive.
- Stripe test connection and Shippo test connection are established.
- Checkout-paid filter, PaymentIntent retrieval, succeeded-payment filter and Shippo shipment lookup are configured. No end-to-end event has passed through this workflow yet.
- Shippo requires a live-key request. Reseller approval remains unverified.

## Implemented safeguards
- `lib/fulfillment-guard.js` checks a retrieved Stripe session/payment against a trusted database order, including environment, amount, currency, ownership reference and settled status.
- `supabase/migrations/003_fulfillment_jobs.sql` adds private orders/jobs and server-only enqueue/claim functions. Unique payment/session/order references and an atomic claim prevent simultaneous workers from owning the same job.
- Migration 003 is deployed. Database checks passed for RLS, denied customer/anonymous access, duplicate enqueue and repeat claim. Test records were rolled back. True concurrent-session testing is pending.
- All 23 Node tests pass, including mocked payment endpoint tests. These do not prove end-to-end service integration.

Supabase project ixgjoaaskhadbraaynkm has completed restoration and is responding.

## Required before activation
1. Complete concurrent-session claim testing in the database.
2. Implement authenticated server-side quoting and Checkout Session creation. Save an immutable address/dimension/service/price snapshot and server-verified first-use eligibility. Do not trust frontend prices or phone text as verification.
3. End-to-end test the deployed private verifier with a real sandbox checkout event. Make receives the event ID; the server retrieves event/session/payment directly from Stripe before enqueue. Reconcile refunds/cancellation before purchasing postage.
4. Replace the direct Stripe-to-Shippo path with trusted job lookup and atomic claim. The present Make shipment-ID metadata mapping is only a draft contract; checkout does not yet populate it.
5. Add per-bag/leg state, FedEx-only rate/cost checks, label purchase, transaction persistence and email. For an ambiguous purchase response, send to manual review rather than purchasing again. Email retries must reuse existing labels.
6. Test duplicate events, delayed payments, partial multi-bag failure, expired rates, email retries and failed postage funding. Keep test keys and scenario inactive until verified.
7. Obtain Shippo live-key/reseller approval and authorize a bounded live purchase test before public checkout.

## Current approved USD pricing
| Bag weight | Sticker price | First use | Returning |
|---|---:|---:|---:|
| Below 25 lb | 44.00 | 22.00 | 36.60 |
| 25–50 lb | 72.00 | 36.00 | 51.70 |
| Above 50–75 lb | 118.00 | 59.00 | 89.30 |

These supersede older cost-plus and $15-cap plans. Carrier costs of $18/$32/$55 are estimates, not guaranteed ceilings; live rates require dimensions and route. Do not advertise an exact live competitor discount. The referral offer must not stack with first-use pricing.

## Deployment update — 12 October 2026
Restoration completed. Migration 003 applied successfully in ZIPLOGGProject. Verification script: supabase/verify-fulfillment.sql. Concurrent-session race testing remains pending. Checkout creation and Make job-claim integration are still not deployed; public checkout remains disabled.

## Payment verifier deployment
Deployed verify-payment-job Edge Function in test-only mode. Dedicated Stripe test key has Checkout Sessions Write, Events Read and Payment Intents Read. Stored in Supabase secret ZIPLOGG_STRIPE_TEST_KEY. Worker secret stored as ZIPLOGG_MAKE_TEST_SECRET and Make connection ZIPLOGG TEST - Supabase worker, restricted to this project's HTTPS origin. Never put either credential in source. HTTP module 4 inserted before Shippo lookup. Maps Stripe 1 event_id into POST JSON. Full integration verification pending; scenario remains inactive. 23 local tests pass, including mocked endpoint authorization, amount/mode checks and duplicates.

An isolated HTTP call with a deliberately nonexistent event ID reached the verifier and returned its generic 503 lookup-failure response. This confirms the private worker connection passed authentication, but does NOT prove Stripe lookup permissions or a successful payment. Stripe Workbench currently shows no sandbox events. Do not treat this probe as a successful payment test.

HTTP-to-Shippo filter is explicitly blocked (`blocked` equals `enabled`, always false), labelled "BLOCKED - awaiting trusted job worker". Replace it only when the private atomic-claim worker and trusted shipment mapping are implemented and tested. The scenario is saved and inactive; no label purchases or customer emails occurred.

## Confirmed carrier blocker — 12 October, 1:46 PM Eastern
- User approved storing the existing Shippo TEST key in Supabase. Saved as ZIPLOGG_SHIPPO_TEST_KEY; no key is in source.
- Deployed private `prepare-test-checkout` integration fixture, guarded by the existing worker secret and test-only key checks. It uses fixed demonstration addresses, one 20 lb parcel, the approved operations test customer, and a $22 sandbox checkout. It is NOT a public customer checkout implementation.
- Executed its `probe_only` request through Make. Authentication and Shippo carrier/shipment calls worked. Shippo returned: **"Your account is restricted from using this carrier."** No FedEx rates were returned. Endpoint stopped with HTTP 409 before creating any Stripe checkout, order or label.
- Two test shipment probes were made, zero transactions/labels purchased. No emails sent. Stripe test checkout creation remains unverified because of this carrier gate.
- Make HTTP module was restored to `verify-payment-job` with `{"event_id":"{{1.event_id}}"}` and scenario saved. Do not leave the probe wired into payment events.
- 28 local tests passed, including unauthorized/live credential rejection, no fallback to another carrier, and rate-probe safeguards. Real FedEx access remains blocked despite these tests passing.
- Proof: `outputs/fedex-restriction.png` in the workspace root.
- Asked permission to contact Shippo support about the carrier restriction and reseller approval. Do not claim support has been contacted until submission is confirmed.

## Shippo support submitted — 12 October 2026
User explicitly approved sending the restriction and reseller-approval request. Submitted through Shippo Help Center API / Account Setup / Portal form, using operations@ziplogg.com. Subject: ZIPLOGG: FedEx test carrier restriction and label-resale approval. Page confirmed 'Your request was successfully submitted.' No ticket number was displayed. Approval/removal of restriction is still pending. Confirmation screenshot: outputs/shippo-support-submitted-oct12.png.


## October 12 update — supersedes earlier pricing
- Confirmed by owner: comparable FedEx retail quote × 45%; JAYHO deducts another 20% for the first shipment only, after a referred friend creates a verified account. Example $100 → $45 → $36.
- Local changes: removed old fixed-tier and 50% offers; added password confirmation, password visibility, email sign-in and confirmation resend; added Photon address suggestions with manual fallback to personal and business forms.
- Verified: 28 unit tests pass; links/assets/syntax checks pass; personal origin city suggestions and keyboard selection work in browser.
- NOT deployed yet: Cloudflare login expired; waiting for owner sign-in. Referral qualification/redemption is NOT implemented in the backend; offer remains explicitly pre-launch. No live checkout or label purchase enabled.
- FedEx restriction remains external blocker. Do not use wholesale Shippo rates as the FedEx retail comparison. Do not promise a per-pound flat rate or guaranteed profit.
- Remaining: server-recorded referral attribution and verified-friend eligibility; atomic first-shipment redemption/reservation; trusted matching retail quote; end-to-end account email test; publish and verify.

Published October 12: Cloudflare production upload succeeded (53 files). Verified https://ziplogg.com/account displays new sign-in controls. Removed remaining 'Registration opens soon' text. Referral enforcement and live checkout remain unavailable as disclosed.

## October 13, 2026 — browser payment verification
- Approved refund policy published and verified at /policies#refunds.
- Stripe sandbox generic declined card displayed decline; order remained awaiting_payment.
- Unpaid cancellation confirmed through customer-test-checkout; order 8c45d6b4 displayed cancelled.
- New explicitly simulated quote c9e16ff0-c7d1-4f0b-a081-3edb6c5fe536 ($100 baseline, $45 total) used for successful sandbox payment.
- Make scenario 6603753 Run once received payment; paid and succeeded filters passed, private verification completed, label-worker blocking filter stopped further processing.
- ZIPLOGG /checkout order f8b39bc7 displayed Test payment verified. No real funds or postage used.
- Scenario remains inactive. Live rates, approved carrier resale access, label/email fulfillment and automatic adjustment consent/charging are not complete.
- Proof: outputs/payment-verified-oct13.png, outputs/stripe-decline-oct13.png, outputs/stripe-cancelled-oct13.png (workspace outputs directory).

## October 13 — email, manual delivery audit and consent
- Zoho confirmation and sample-PDF self-delivery to operations@ziplogg.com verified. Manual sends only, no automatic Make email connection.
- Applied migrations 009_manual_delivery_audit and 010_test_adjustment_consent. Private permissions, idempotent preparation, duplicate claims, sample/live separation and consent checks verified using rolled-back database tests.
- Deployed customer-test-checkout consent enforcement and static checkout/policy updates. Browser unchecked-blocking test passed. Explicit test acknowledgement recorded adjustments-test-v1, test_only true, timestamp 2026-10-13 21:12:36 UTC. New unpaid QA session cancelled afterward.
- 39 Node tests and page checks passed. PDF rendered and visually checked.
- Manual operator UI, automated mail transport, live saved-card consent/adjustment charges and actual labels remain incomplete. Do not describe these as enabled.

## Staff screen prepared October 13, 2026
- Added dist/admin-labels.html, CSS and JS plus admin-test-labels function and migration 011.
- Only explicitly approved verified user IDs in private test_label_operators can use the endpoint. No operators have been granted access.
- Backend filters verified paid test orders; rejects live orders. Samples go only to operations@ziplogg.com. Private 2 MB PDF storage uses immutable content hashes; short-lived download links are issued only after staff checks.
- UI supports upload, download, one-time manual-send claim, and sent-mail evidence. It does not send email automatically.
- Six endpoint tests passed; previous 39 tests also passed before the final relation-shape fix. Static page checks passed.
- Local signed-out screen checked. Live backend/UI end-to-end testing is NOT complete.
- Supabase signed out while migration 011 was running: outcome unknown. Before retrying, inspect whether test_label_operators, manual_deliveries.storage_path, and ziplogg-test-labels bucket exist. The restrictive storage policy was added locally AFTER this attempt and still needs applying.
- Edge function and static site have NOT been deployed in this round. Need Supabase sign-in, verify/apply schema, deploy function, publish frontend, then request action-time approval for the exact staff account before granting access and testing.

## Staff workspace deployment verified October 13, 2026, 6:35 PM EDT
Supersedes the deployment-interruption note above. Migration 011 and restrictive storage policy are deployed, admin-test-labels function is deployed, and https://ziplogg.com/admin-labels is published (outputs/ziplogg-admin-labels-oct13.zip).
- Owner explicitly approved dmeda910@gmail.com staff access; its verified user ID alone was added to test_label_operators.
- Before grant, live endpoint returned no staff access. Database verified zero public bucket access, customer cannot read staff table, restrictive storage policy present.
- After grant, verified paid test order f8b39bc7 appeared. Sample PDF upload and private download passed; downloaded SHA-256 equals original.
- Manual claim and sent-record UI completed. Existing Zoho Sent email from 5:10 PM was verified Delivered and recorded retrospectively. NO new email was sent in this round.
- Sample delivery state sent; it does not fulfill a real shipment. No live payment, postage, or automated email was enabled.
- Proof: outputs/admin-labels-verified-oct13.png. Six new backend tests passed; static checks passed.
- Full automatic payment-to-label-to-email and real carrier rates still pending. This page supports only manually audited sample delivery to operations@ziplogg.com.

## ZIPLOGG-only public wording — October 13, 2026
Owner requested removal of all FedEx names/comparison language from website, retaining calculation/payment structure and label integration. Removed carrier branding, comparison examples, 45%/55% public claims and external FedEx links from dist pages/scripts. JAYHO remains extra 20% off eligible ZIPLOGG price. Generic requested service labels replace branded names. Backend pricing/provider configuration unchanged. Static scan found no FedEx references in dist; page/link/JS checks passed. Published outputs/ziplogg-brand-only-oct13.zip. Live Personal, Business, Checkout and Policies checked; screenshot outputs/ziplogg-brand-only-oct13.png. Actual official carrier-issued shipping labels will naturally retain issuer branding when carrier access is enabled; no label PDFs modified.

## Make-to-Zoho transport verified — October 13, 2026, 7:05 PM EDT
- Owner explicitly approved one connection-test email to operations@ziplogg.com. Make Zoho Mail module 5 ran successfully (one operation), message ID 1791932728894155300. Zoho Sent reports Delivered. Proof: outputs/make-zoho-email-delivered-oct13.png.
- Dedicated connection ZIPLOGG TEST - Zoho order emails works for sending. Module is saved but disconnected from the payment route; scenario remains inactive. Do not describe payment-triggered emails as finished.
- Deployed migration 012_test_payment_email_outbox and test-payment-email-job Edge Function. Existing private worker secret is required inside function; legacy JWT gateway disabled to use custom authentication. Test-only recipient fixed to operations@ziplogg.com, no live sends or backfill.
- Rolled-back live database verification passed for single claim, repeated claim suppression, wrong token rejection, idempotent confirmation and restricted customer access. Local npm tests: 50 passed.
- Remaining: wire Make verified payment -> private claim -> send=true filter -> Zoho -> private confirmation with Message ID; test end-to-end, duplicate event and ambiguous send handling. Do not automatically retry sending claims. Current module still contains static connection-test message and must be mapped before routing.
- No new payment, label purchase, live activation or customer email occurred.

## Payment-to-email replay verified — October 13, 2026, 7:37 PM EDT
- Owner authorized one simulated payment-confirmation email and replay duplicate test to operations@ziplogg.com.
- Make scenario 6603753 saved: Stripe 1 -> Stripe 2 -> private verify HTTP 4 -> email claim HTTP 6 -> filter 6.data.send equals true -> Zoho 5 -> confirm HTTP 12. Zoho uses fixed operations recipient, 6.data.subject/text, plain text. Confirm maps provider_reference from 5.messageId (not data.messageId).
- Carrier path is disconnected. Router 7 -> Shippo 3 remains isolated; original blocked filter was removed when unlinking HTTP4 from router. Do NOT reconnect this branch without carrier approval and trusted purchasing implementation. Entire scenario remains inactive.
- Explicit one-order test backfill queued the previously verified paid sandbox order f8b39bc7-0bc4-42ff-825b-ab2cf35eafb9. No general backfill. Replayed saved October 13 4:56:58 PM Stripe event evt_1UQCkoCP5YnOmfh2BfPNPLKM. No new payment or postage was created.
- First replay at 7:35:44 PM succeeded: 6 operations; email delivered in Zoho; outbox state sent, provider_reference 1791934547354138400; claimed_at 23:35:46 UTC, sent_at 23:35:47 UTC. Fixed test recipient operations@ziplogg.com. Email correctly says test only, USD45, no postage and do not pay again.
- Second replay at 7:37 PM succeeded through claim but send filter counted zero; Zoho and confirmation modules did not execute. Duplicate email suppressed.
- Local full suite: 50 tests pass. Proof: outputs/payment-email-automated-oct13.png and outputs/payment-email-duplicate-blocked-oct13.png.
- Scope: replay-based sandbox payment-to-confirmation-email verified. New-payment trigger with this revised chain, real customer recipients, label attachment automation, approved carrier rates/postage and live payments are still not enabled/verified. Do not claim complete payment-to-label fulfillment.
- Claim ambiguity handling remains fail-closed: never reset sending state or resume directly at Zoho after an uncertain send without checking Zoho history. Background automation is inactive.

## Fresh sandbox checkout passed — October 13, 2026, 7:45 PM EDT
- Created explicit simulated quote cf92cb1c-f387-4b7a-8459-d88fbd124c4b for approved test staff user; fake test shipment/rate IDs, evidence.test_fixture true. Not a real carrier rate.
- Opened new Stripe sandbox checkout from public ZIPLOGG checkout, acknowledged test-only adjustment checkbox; paid USD45 using Stripe test card, Link saving unchecked. No real charge or postage.
- Make Run once received the NEW payment event and completed verified payment -> automatic outbox trigger -> claim -> Zoho send -> acknowledgement. No manual outbox insert/backfill for this order.
- New order 8dfefac1-cb5c-443d-b0e0-feb6f460dd54: total4500, live_mode false, status queued; email state sent; Zoho Message ID1791935127011155100. Zoho Sent Delivered7:45PM and ZIPLOGG checkout displays Test payment verified.
- Proof outputs/fresh-payment-email-oct13.png. Scenario remains inactive between supervised tests, carrier branch disconnected. Customer-recipient live delivery, carrier rates, postage and automatic live adjustments still pending. Existing duplicate replay test remains verified.

## JAYHO backend audit passed — October 13, 2026
Executed verify-referral-gates.sql, verify-checkout-promotions.sql and verify-checkout-recovery.sql against deployed database. All returned success. Tests run inside rolled-back transactions: synthetic accounts/orders/referrals leave no persistent access or emails.
Verified: no-referral rejection; unverified friend ineligible; verified friend eligible; attribution unchanged by later user metadata; self-referral blocked; deleted friend ineligible; normalized jayho code; USD45 -> USD36; private referral access; same-order retry idempotent; duplicate reservation blocked; successful test payment consumes promo; second redemption blocked; expired unpaid test checkout releases reservation; paid checkout cannot release consumed promo.
Scope: backend sandbox and referral gates verified, not a real referred friend's signup or live-money redemption. Proof outputs/jayho-backend-checks-oct13.png. No production pricing logic changed.

## Mobile-width and USA suggestions verification — October 13
- Verified live Personal origin Boston and destination Seattle suggestions; selecting Seattle populated Washington.
- Verified Business origin Chicago and destination Austin suggestions.
- Confirmed 390px viewport, document width 375px (no horizontal overflow) for Business and account; Personal dropdown visually checked at 390px.
- Signed-in account and mobile Menu expansion verified; session retained. This round did not repeat password or email sign-in.
- Saved outputs/mobile-personal-address-oct13.png, mobile-business-address-oct13.png, mobile-account-oct13.png.
- No production changes, real payments, postage purchases, or emails in this check. Shippo approval and live fulfillment remain pending.

## Payment failure, expiration and status checks — October 13
- Added regression cases for failed/expired events, unpaid and authentication-required/cancelled payments, and cancelled orders: no fulfillment queue entry. These are local mocked-provider endpoint tests, not fresh Stripe decline-card transactions.
- Added already-expired cancellation and post-expiration race/mismatch tests; uncertain expiration retains reservation. Targeted suite: 16 passed.
- Executed verify-expired-quote.sql against deployed Supabase in a rolled-back transaction. Expired quote rejected; no order, fulfillment job or promo reservation left.
- Live customer checkout reload shows two verified paid sandbox orders and two cancelled orders. Neither has another payment button; no unused quotes currently available. No source deployment required.
- Evidence outputs/payment-status-checks-oct13.png. No real payment, label purchase, email, or activation occurred. Actual live fulfillment remains pending.

## UI corrections published October 14
Fixed stale sign-in instruction after authenticated reload; corrected address selection hint and avoided redundant country change; fixed initial ArrowUp selection to last suggestion. Local Boston browser selection and keyboard check passed. Page/assets/anchors/JS checks passed. Published outputs/ziplogg-ui-fixes-oct14.zip to Cloudflare production; dashboard Success confirmed. Live account status confirmed Signed in. Evidence outputs/account-fix-live-oct14.png. This was a focused pass, not proof that every website issue is resolved.

## October 14: dimensional-weight calculator
- Added per-item US customer-packed parcel dimensional weight: ceil(each outside inch), volume / 139 rounded up, compared with actual pounds rounded up.
- Size handling minimum 40 lb; oversize minimum 90 lb; handling/packaging and ground-size acceptance warnings. Each parcel rated separately; no automatic bulk discount.
- Reference: https://www.fedex.com/content/dam/fedex/us-united-states/services/Service_Guide_2026.pdf (updated September 11, 2026), pp. 127–128, 135, 158. Public branding remains ZIPLOGG.
- Existing 45% retail / additional eligible 20% JAYHO formula verified. No guessed dollar rate, no live checkout activation.
- 8 targeted pricing tests passed; link/asset/anchor/syntax check passed. Browser confirmed 20 lb, 24x16x10 -> 28 lb estimated rating weight.

## October 14: Stripe payment methods
- Live Default configuration pmc_1UKKJiCP5YnOmfh2b1uzIaFm inspected. Cards, Apple Pay, Link and Amazon Pay already Enabled.
- Enabled Google Pay at owner request; row verified Enabled, total enabled methods increased 12 -> 13. No other payment methods modified, no payment or customer charge created.
- Evidence outputs/stripe-methods-oct14.png. ZIPLOGG website still invokes customer-test-checkout; live checkout/payment verification/customer email integration is not deployed. This settings change is not website live activation.

## October 14: live manual checkout connection (partial launch)
- User explicitly approved restricted Stripe LIVE credential (Checkout Sessions Write, Payment Intents Read), private Supabase storage and signed webhook registration. Stripe verification initially failed; user completed it. Created restricted key ZIPLOGG LIVE - Supabase manual checkout and saved ZIPLOGG_STRIPE_LIVE_KEY in Supabase. No secret stored in source or this record.
- Created live webhook we_1UQb6jCP5YnOmfh25C5G7NCY to /functions/v1/live-manual-checkout for checkout.session.completed, checkout.session.expired, checkout.session.async_payment_succeeded. Signing secret saved privately as ZIPLOGG_STRIPE_LIVE_WEBHOOK_SECRET.
- Deployed migration 013 and live-manual-checkout. Gateway legacy-JWT check off because function verifies browser JWT or Stripe HMAC itself. ZIPLOGG_LIVE_MANUAL_ENABLED=true. No approved quotes or live orders exist.
- SQL rollback safety checks passed in Supabase: private privileges, trusted 45% price, retry single order, reserved quote immutability, test-session rejection, wrong-amount rejection, duplicate confirmation. No test rows persisted.
- Seven mocked-provider endpoint tests passed, including signed-event duplicate handling. This is NOT an actual live paid transaction or real Stripe delivery test.
- Published production /pay, pay.js, pay.css and manual-delivery policies; Personal/Business calculators now link to confirmed-quote payment page. Cloudflare Success verified. Signed-in production /pay returns live backend response and empty quotes/orders successfully.
- Important remaining: owner workflow to prepare real quotes (tables are service-only; no live admin role granted), real Stripe checkout creation and real payment/webhook validation, operations payment notification, real manual-label delivery verification. No live card was charged, no real checkout session created in this turn, and no postage bought. Do not describe full payment-to-label launch as verified.
- Quote requirements before accepting money: verified customer UUID; exact shipment addresses/package details; actual matching carrier retail quote incl. charges; actual postage purchase cost and evidence; owner approval; fulfillment_ready true only while owner can send label within 5 minutes. Quote expiry 31 minutes to 24 hours. Existing reserved quotes immutable. Pricing 45% retail; eligible JAYHO additional 20%. Do not create guessed prices or fabricated carrier evidence.
- Current manual checkout does NOT save a card or implement automatic adjustment charges. Policies state this accurately. Refund execution and sent-label marking are not automated by this function.

## October 14 address search update
USA-only origin preserved. Destination countries/territories added as address-search geography (not a supported-shipping promise). Photon country filtering, address autofill, keyboard selection, country-change clearing and international postal format handling implemented in Personal/Business planners and shared search. Browser checks passed for USA, Canada, India and UK, including UK alphanumeric postal code and cleared fields on country change. Live rates and country/service acceptance still require separate confirmation. Deployment bundle: outputs/ziplogg-addresses-oct14.zip.


October 14 search speed: debounce reduced from 650ms to 250ms; normalized country-specific cache now renders before debounce/network; request-local timeout avoids cancelling a newer request. Browser test fresh Toronto search 2434ms, same query case variant 65ms including automation overhead. Provider latency remains variable.


## 2026-10-14 fixed small-parcel checkout
Published fixed-small-checkout.js and calculator integration to Cloudflare production; verified on ziplogg.com. Five owner-supplied fixed prices: $5.72/$7.29/$9.68/$14.76/$20.52. Scope is one USA-to-USA parcel with actual and dimensional weight <=1 lb (rounded dimensions volume <=139 cubic inches). Heavier/international shipments still require a separate quote.
Migration 014 deployed. Rollback SQL tests passed for replay, trusted price, overweight, oversized, international and unknown-service rejection and restricted database permissions. Existing live checkout tests: 7 passed. Static check passed. Public browser review shows all five prices; missing contact information blocks continuation.
No real payment, real shipment or Stripe card-entry session was created in this verification. Full paid end-to-end flow and live operations email delivery are not verified by this update. Labels remain manual. Proof: ../outputs/fixed-checkout-live.png.

## Checkout/address repairs 2026-10-14
Added session-only shipment recovery (24-hour validity), including contact fields, units and all packages; payment page shows the saved shipment and an edit link. Sidebar now reviews the entered shipment instead of bypassing quote creation; eligible service selection updates the visible total and does not invalidate its own review. Heavier/international shipments offer an explicitly customer-sent quote request email, not an invented payable price or a claimed automatic submission. Customer approved confirmed quotes for heavier luggage.
Address suggestions no longer clear fields when results omit state/postal values; city/state searches update only related fields, and duplicate address results are collapsed. Existing backend payment tests: 7 passed. Browser verified $5.72 to $9.68 service switching, reload retention and saved 20 lb shipment on payment page. No real charge performed; actual hosted Stripe creation still not verified in this repair.

## October 14: payment completion audit (sandbox success, downstream pending)
- Owner confirmed no sales-tax registrations. Do not invent registrations, a tax rate, or label shipping exempt. Stripe Tax currently shows default General - Electronically Supplied Services; this needs correct shipping classification before enabling calculation. Tax collection has not been configured. Official reference: https://docs.stripe.com/tax/zero-tax.
- Enabled current Stripe user's Successful payment receipt - Email communication preference; checked state verified. Recipient/inbox delivery not yet verified. This is not proof of an operations@ziplogg.com live order notification.
- Created explicitly synthetic test quote e17bb678-01ab-47d9-88ca-a80bf1c3d7c7 (live_mode false, test_fixture true, no carrier quote/postage). New test order a636d78f; session cs_test_a1Zr9WH0TpVGGoO673504RcG3fCkVBg0JDjux8IlTXwnF058P0Qu82uXzZ.
- Completed Stripe-hosted sandbox checkout with synthetic 4242 test card, no real money or saved card. Stripe dashboard confirms payment pi_3UQclmCP5YnOmfh20TSajq33 Succeeded, USD45, operations@ziplogg.com. Returned to /account?checkout=test-complete.
- ZIPLOGG /checkout still shows Awaiting verified payment. Make is signed out and test verification scenario previously inactive. Asked owner to sign in. Do not mark order paid manually or describe test as end-to-end complete.
- Proof: ../outputs/stripe-sandbox-payment-oct14.png and ../outputs/stripe-payment-email-setting.png.
- Remaining automatic pricing gap: owner supplied fixed prices only <=1 lb plus USD108 additional heavy/large fee; no base weight/route schedule above1 lb. No unsupported automatic base price invented. Live payment -> verified order -> operations notification remains unverified.

## October 14: new sandbox payment confirmation completed
- Make login recovered. Existing test scenario had one queued event; ran Run once -> Use existing data. All six modules completed and run finalized at8:52PM Eastern. Scenario remains inactive between supervised tests; no carrier branch activated.
- ZIPLOGG /checkout now shows Test payment verified for a636d78f, USD45. No extra payment or postage purchase.
- Zoho operations inbox received [TEST] ZIPLOGG payment verified — a636d78f at8:52PM. Opened body confirms USD45, test only, no real payment/postage. Verified inbox delivery, not merely send API success.
- Proof ../outputs/payment-confirmation-delivered-oct14.png. This completes this sandbox payment -> verified order -> confirmation email run. It does not verify live-manual-checkout's distinct live notification flow or establish heavier-baggage base pricing/tax calculations.

## October 14: additional test-only verification
- 23 targeted tests passed across checkout recovery, live manual checkout mocked-provider safety, payment verification and test email worker authorization/claims.
- Replayed real sandbox event from Make run8f2a7cfba02e4b6baf63054337a7a5f7. Replay c24dd539e7ef4677a27fb84fa92ecbe3 succeeded at8:58:04PM Eastern, four operations. Zoho Mail - Send an Email explicitly blocked by filter (zero bundles). No duplicate confirmation email sent, no new charge/postage.
- Proof ../outputs/duplicate-payment-blocked-oct14.png. No live workflow activation or new production prices implemented. Owner chose fictional parcel/test-only, so real purchase verification remains pending.

## October 14, 2026 (late): live paid-order operations notification — built, NOT deployed (Claude)
Picked up from CLAUDE-HANDOFF.txt in Claude. Runbook: LIVE-ORDER-NOTIFICATIONS.md.
Completed and verified locally:
- Migration 015_live_order_notifications.sql: private outbox, trigger queues one notice when a live order becomes paid (same transaction), claim/confirm/backlog functions, back-fill of any already-paid orders.
- Edge function live-order-notification-job (claim/confirm/status, separate secret ZIPLOGG_MAKE_LIVE_SECRET, fixed operations recipient, control characters stripped from customer text).
- live-manual-checkout: optional data-free Make wake-up after verified payment (ZIPLOGG_LIVE_NOTIFY_HOOK; only https://hook.*.make.com URLs; failure ignored).
- Applied migrations 013, 014, 015 to a local PostgreSQL 16 with stubbed Supabase auth/roles. Existing verify-live-manual-checkout.sql still passes. New verify-live-order-notifications.sql passes and leaves zero rows; it fails as expected when the trigger is disabled or a grant is leaked. Two concurrent claims received different notices; a third received none.
- 9 new mocked-provider tests; full suite 74/74 pass; page checks pass; both functions pass `deno check`.
NOT done / NOT verified:
- Nothing deployed to Supabase, Make or Cloudflare. No secret created. No email sent. No live or test payment made.
- Local PostgreSQL is not the Supabase production database; the rollback check must be re-run there after deploying.
- Real Stripe live webhook delivery and an end-to-end live notice remain unverified (zero live orders exist).
- Notice latency depends on the Make trigger/schedule; the 5-minute label promise is not yet measured.
- Marking orders label_sent and refunds are still manual/unbuilt.

## October 14–15, 2026: live notification deployment — PARTIAL (Claude)
Owner approved deployment in chat. Done in production (Supabase project ixgjoaaskhadbraaynkm, branch main):
- Read-only precheck before changes: outbox absent, 0 live orders, 0 paid orders, 0 live quotes, no conflicting functions.
- Applied migration 015_live_order_notifications.sql (exact file contents, 5260 bytes) — "Success. No rows returned".
- Ran tests/verify-live-order-notifications.sql in production: "checks passed, rolled back"; afterwards 0 notices, 0 live orders, 0 live quotes remain.
- Deployed Edge Function live-order-notification-job; deployed source SHA-256 0e32e63e…b4fa77 matches the tested local file. "Verify JWT with legacy secret" turned OFF and saved (function does its own worker-secret check).
NOT done yet:
- Secret ZIPLOGG_MAKE_LIVE_SECRET not set: the function currently refuses every request (by design, returns 503).
- Production probe of the function NOT completed: the dashboard Test panel reported "Unable to reach the server" (the worker sends no CORS headers, so the browser panel cannot read replies), and the owner's computer then lost network access before the Invocations log could be checked.
- live-manual-checkout NOT redeployed with the wake-up change; ZIPLOGG_LIVE_NOTIFY_HOOK not set.
- Make LIVE notice scenario and backlog alert NOT built. No email sent. No payment, charge or label purchase of any kind.
- Until Make is wired, paid live orders will queue notices in live_order_notifications but nobody is emailed.

## October 15, 2026: live paid-order notification DEPLOYED and ACTIVE (Claude) — supersedes the "PARTIAL" entry above
Owner approved deployment; owner generated/pasted secrets themselves. Details: LIVE-ORDER-NOTIFICATIONS.md.
Done and verified:
- Secret ZIPLOGG_MAKE_LIVE_SECRET set (13:31 UTC). New Make connection "ZIPLOGG LIVE - Supabase notice worker" holds it (header x-ziplogg-worker, restricted to the Supabase origin).
- Make scenario 6645386 "ZIPLOGG LIVE - paid order notices" built: webhook -> claim -> filter send=true -> Zoho to operations@ziplogg.com (plain text) -> confirm with Zoho messageId. ACTIVE (instant trigger). TEST scenario 6603753 untouched.
- Production probes through Make: status -> 200, live true, all counts 0, alert false; claim -> 200, send false. Proves key, connection, function and database calls work in production.
- ZIPLOGG_LIVE_NOTIFY_HOOK secret set (digest matches webhook URL). live-manual-checkout redeployed with the data-free wake-up; production source before the change was byte-identical to the local pre-change file; deployed source hash matches the tested file; Verify JWT still OFF.
- Incident: scenario was accidentally switched on 10:56:08–10:57:03 AM EDT during the build; Make history shows no runs in that window.
NOT verified:
- No real paid order has gone through end to end; Zoho send + confirm in the live scenario have not run yet. No payment, charge, label purchase or test email was made.
- No scheduled fallback/alert scenario yet (a lost wake-up leaves the notice pending without an alert).
- Base pricing above 1 lb, tax classification and refund/label_sent marking remain open as before.

## October 15, 2026: automatic pricing over 1 lb (flat Ground tariff v1) — backend LIVE, website NOT yet published (Claude)
Owner instructed Claude to create and deploy prices over 1 lb and committed to them. Details and margin warning: PRICING-GROUND-V1.md.
Done and verified:
- Migration 016_flat_ground_tariff.sql applied in production after checking constraint names and that reserve_live_manual_checkout matched the 013 source. tests/verify-flat-ground.sql + verify-live-manual-checkout.sql passed in production (rolled back; 0 quotes/orders/notices left; 18 bands).
- live-manual-checkout redeployed (quote list shows flat price) and live-order-notification-job redeployed (lists every package); deployed sources hash-match tested files; Verify JWT still OFF on both.
- Website (local dist, not yet live): live price updates while typing; per-package Ground price; "Save shipment & continue to payment" saves a server-priced quote and redirects to /pay?saved=<id>, which highlights it; Stripe payment from there. Fixed <=1 lb flow unchanged.
- 81 Node tests pass (7 new); browser test of the calculator in headless Chromium with no page errors.
NOT done / NOT verified:
- Site not published: Cloudflare sign-in needed; bundle ziplogg-ground-pricing-oct15.zip (64 files) in the project folder.
- No real or test payment through the new flow yet; express/international pricing over 1 lb not offered; tax not configured.
