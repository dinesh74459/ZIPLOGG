import {readFile,writeFile} from 'node:fs/promises';
const root=new URL('../dist/',import.meta.url);
for(const page of ['personal.html','home.html','index.html']){let s=await readFile(new URL(page,root),'utf8');if(!s.includes('location-search.js'))s=s.replace('</head>','<link rel="stylesheet" href="location-search.css"></head>').replace('</body>','<script type="module" src="location-search.js"></script></body>');await writeFile(new URL(page,root),s);}
let h=await readFile(new URL('account.html',root),'utf8');
h=h.replace('id="email-setup-notice" class="account-notice"','id="email-setup-notice" class="account-notice" hidden');
h=h.replace('<p id="password-help"','<button id="show-password" type="button" class="text-btn" aria-pressed="false">Show password</button><label id="confirm-field" hidden>Confirm password<input name="confirmPassword" type="password" maxlength="128" autocomplete="new-password"></label><p id="password-help"');
h=h.replace('<p class="footnote">Account information','<button class="text-btn" type="button" data-auth-mode="magic">Email me a sign-in link</button><button class="text-btn" type="button" id="resend-confirmation">Resend confirmation email</button><p class="footnote">Account information');
await writeFile(new URL('account.html',root),h);
let s=await readFile(new URL('account.js',root),'utf8');
s=s.replace("auth.elements.password.required=next!=='forgot'","auth.elements.password.required=!['forgot','magic'].includes(next)");
s=s.replace("$('#password-field').hidden=next==='forgot';","$('#password-field').hidden=['forgot','magic'].includes(next);$('#show-password').hidden=['forgot','magic'].includes(next);$('#confirm-field').hidden=next!=='signup';auth.elements.confirmPassword.required=next==='signup';auth.elements.password.type='password';$('#show-password').textContent='Show password';$('#show-password').setAttribute('aria-pressed','false');");
s=s.replace("forgot:'Reset your password.'","forgot:'Reset your password.',magic:'Sign in with an email link.'").replace("forgot:'Send reset link →'","forgot:'Send reset link →',magic:'Send sign-in link →'");
s=s.replace("const submittedMode=mode,button=$('#auth-submit');button.disabled=true;","const submittedMode=mode,button=$('#auth-submit');if(mode==='signup'&&auth.elements.password.value!==auth.elements.confirmPassword.value){report('The two passwords must match.');return;}button.disabled=true;");
s=s.replace("const response=submittedMode==='signup'?", "const response=submittedMode==='magic'?await client.auth.signInWithOtp({email,options:{shouldCreateUser:false,emailRedirectTo:redirect.href}}):submittedMode==='signup'?");
s=s.replace("report(submittedMode==='signup'?", "report(submittedMode==='magic'?'If you have a verified account, check your inbox for your sign-in link.':submittedMode==='signup'?");
s=s.replace("const client=await getAccountClient();\n\n client.auth.onAuthStateChange",`$('#show-password').onclick=()=>{const shown=auth.elements.password.type==='password';auth.elements.password.type=shown?'text':'password';$('#show-password').textContent=shown?'Hide password':'Show password';$('#show-password').setAttribute('aria-pressed',String(shown));};
 $('#resend-confirmation').onclick=async()=>{if(!auth.elements.email.reportValidity())return;const b=$('#resend-confirmation');b.disabled=true;try{const c=await getAccountClient();const {error}=await c.auth.resend({type:'signup',email:auth.elements.email.value.trim(),options:{emailRedirectTo:new URL('account.html',location.href).href}});if(error)throw error;report('If confirmation is needed, a new email will arrive. Check your spam folder too.');}catch{report('Could not resend confirmation. Wait a minute and try again.');}finally{b.disabled=false;}};
 const client=await getAccountClient();

 client.auth.onAuthStateChange`);
await writeFile(new URL('account.js',root),s);
