import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
const source=new URL('../node_modules/@supabase/supabase-js/',import.meta.url);
const target=new URL('../dist/vendor/',import.meta.url);
await mkdir(target,{recursive:true});
const bundle=await readFile(new URL('dist/umd/supabase.js',source),'utf8');
await writeFile(new URL('supabase.js',target),bundle+'\nexport const createClient = supabase.createClient;\n');
await copyFile(new URL('LICENSE',source),new URL('supabase-LICENSE.txt',target));
console.log('Prepared the pinned official Supabase browser bundle locally.');
