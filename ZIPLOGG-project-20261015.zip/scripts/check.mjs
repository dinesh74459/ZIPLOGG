import {readFile,readdir,stat} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const root=fileURLToPath(new URL('../dist/',import.meta.url));let errors=[];
for(const file of await readdir(root)){
  if(file.endsWith('.js')){const r=spawnSync(process.execPath,['--check',path.join(root,file)],{encoding:'utf8'});if(r.status!==0)errors.push(r.stderr||String(r.error));}
  if(!file.endsWith('.html'))continue;const html=await readFile(path.join(root,file),'utf8');
  for(const [,ref] of html.matchAll(/(?:src|href)="([^"]+)"/g)){
    if(/^(https?:|data:|mailto:|tel:)/.test(ref))continue;
    const [target,anchor]=ref.split('#');let filename=target.split('?')[0]||file;
    if(filename==='/')filename='index.html';
    else if(filename.startsWith('/')&&!path.extname(filename))filename=filename.slice(1)+'.html';
    try{await stat(path.join(root,filename));if(anchor){const other=await readFile(path.join(root,filename),'utf8');if(!other.includes(`id="${anchor}"`))errors.push(`${file}: missing anchor ${ref}`);}}catch{errors.push(`${file}: missing ${ref}`);}
  }
}
if(errors.length){console.error(errors.join('\n'));process.exit(1);}console.log('All page links, assets, anchors and JavaScript syntax checks passed.');
