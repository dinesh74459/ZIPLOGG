# ZIPLOGG flat Ground tariff v1 (parcels over 1 lb) — October 15, 2026

Owner instruction (chat, Oct 15 2026): "charge for the more than one lb ... you create the prices for it and deploy and i will stick on to that prices".
These are ZIPLOGG selling prices. They are not carrier quotes and not the "45% of retail" formula.

## Scope
- 1–5 packages per order, each up to 100 lb, contiguous USA to contiguous USA, Ground only.
- Alaska, Hawaii, PR/VI, Guam/Pacific, military (APO/FPO), international, faster services over 1 lb, oversize (longest > 96 in, length+girth > 130 in), rating weight > 100 lb: quote by email.
- Parcels up to 1 lb keep the fixed small tariff ($5.72–$20.52, all five services).

## Rating weight
max(actual rounded up, ceil(L x W x H / 139) with dimensions rounded up, 40 lb if large-size handling applies).
Large size = longest > 48 in, second > 30 in, length+girth > 105 in, or volume > 10,368 cu in.

## Base price per package (rating weight up to)
| lb | price | lb | price | lb | price |
|---|---|---|---|---|---|
| 2 | $25.99 | 30 | $49.99 | 60 | $75.99 |
| 5 | $28.99 | 35 | $55.99 | 65 | $78.99 |
| 10 | $31.99 | 40 | $60.99 | 70 | $83.99 |
| 15 | $34.99 | 45 | $66.99 | 80 | $91.99 |
| 20 | $39.99 | 50 | $70.99 | 90 | $104.99 |
| 25 | $43.99 | 55 | $71.99 | 100 | $113.99 |
Derivation: FedEx Ground 2026 standard list rate, zone 5, at the band's top weight × 1.20 (fuel allowance) + $6.45 residential surcharge, rounded up to .99.
Source: FedEx Standard List Rates, FedEx Ground, effective Jan 5 2026 (fedex.com/ratetools/documents2/GroundNoSvc.pdf).

## Handling (per package, only the highest one; not charged when the $108 fee applies)
- Over 50 lb actual: $67.50 (FedEx Additional Handling–weight, zones 5–6 $56.25 × 1.20)
- Large size: $46.20 (Additional Handling–dimension $38.50 × 1.20)
- Suitcase / not boxed: $39.60 (Additional Handling–packaging $33.00 × 1.20)
Source: FedEx 2026 surcharge and fee changes PDF.

## Owner's $108 heavy/large-bag fee
Unchanged rule: per package over 70 lb actual or length+girth over 105 in. Not reduced by JAYHO.

## JAYHO
20% off base + handling only (server: round(price × 0.20)); fee not discounted.

## Margin warning (read before relying on these prices)
At FedEx *list* prices plus fuel, ZIPLOGG roughly breaks even for zone 5, earns on zones 2–4 and loses on zones 6–8
(e.g. 40 lb at zone 8 list ≈ $98 before handling vs $60.99 base). Any account discount improves this.
Delivery Area Surcharges ($6.60–$16.75) and declared-value fees are not included.

## Changing a price
One SQL update, no deploy needed for the server price, e.g.
  update public.ground_tariff_bands set price_cents=5799 where max_rating_lb=35;
then update `groundBands` in dist/luggage-pricing.js (tests/flat-ground.test.mjs fails if they differ) and republish the site.
