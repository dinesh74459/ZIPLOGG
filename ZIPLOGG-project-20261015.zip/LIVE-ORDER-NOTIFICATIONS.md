# Live paid-order notifications to operations — runbook

Status (October 15, 2026, Claude): DEPLOYED and ACTIVE. Production auth/database path verified with safe probes.
NOT yet verified end-to-end with a real paid order (no live orders exist; no fabricated rows used).

## What it does
Every LIVE manual-label order that `live-manual-checkout` verifies as paid with Stripe gets exactly one
operations notice to operations@ziplogg.com. The notice includes the order ID, payment time, label
due time (+5 min), amount, Stripe payment ID, customer account email, service, ship date, both
contacts/addresses and package size/weight.

## Pieces
| Piece | File | Role |
|---|---|---|
| Outbox | `supabase/migrations/015_live_order_notifications.sql` | Trigger writes one `pending` row in the same transaction that sets an order `paid`. Unique per order. Private (service role only). Back-fills any already-paid order. |
| Worker | `supabase/functions/live-order-notification-job/index.ts` | Private endpoint for Make. `claim` returns one prepared notice; `confirm` records the Zoho message ID; `status` returns backlog counts and `alert`. Never sends mail itself. |
| Wake-up | `supabase/functions/live-manual-checkout/index.ts` | After a verified payment, optionally POSTs `{}` to `ZIPLOGG_LIVE_NOTIFY_HOOK` (Make webhook URL only). Failure is ignored; the outbox row stays pending for the scheduled run. |
| Checks | `tests/verify-live-order-notifications.sql`, `tests/live-order-notification-job.test.mjs` | Rolled-back SQL check; mocked-provider endpoint tests. |

## Duplicate and failure rules
- One notice per order (unique `order_id`); replayed Stripe events and repeated confirmations do not add rows.
- `claim` uses row locks with `skip locked`; two simultaneous workers never get the same notice.
- A notice in `sending` (outcome unknown) is NEVER reclaimed automatically. `status` reports it as
  `stuck_sending` after 10 minutes and sets `alert:true`. Staff check Zoho Sent, then either record the
  message ID or set the row back to `pending` by hand.
- `alert` is also true if anything is in `review` or a pending notice is older than 2 minutes.

## Deployment steps (each needs owner sign-in / approval)
1. Supabase SQL editor (project ixgjoaaskhadbraaynkm): run migration 015. Then run
   `tests/verify-live-order-notifications.sql` — expect NOTICE "live order notification checks passed" and ROLLBACK.
2. Create Edge Function `live-order-notification-job` from the file above. Turn OFF "Verify JWT" (custom worker auth).
3. Set Supabase secret `ZIPLOGG_MAKE_LIVE_SECRET` (random, 32+ chars, different from the TEST secret).
   Owner generates and pastes it; do not record it in chat or files.
4. Make (team 3146872): new scenario "ZIPLOGG LIVE - paid order notices", separate from test scenario 6603753:
   Custom webhook trigger → HTTP POST `/functions/v1/live-order-notification-job` `{"action":"claim"}` with header
   `x-ziplogg-worker` (stored in a LIVE-named Make connection/keychain) → filter `data.send = true` → Zoho Mail
   Send an Email to fixed `operations@ziplogg.com`, subject/text from HTTP data, plain text → HTTP POST
   `{"action":"confirm","email_id":…,"claim_token":…,"provider_reference":"{{Zoho.messageId}}"}`.
   Also schedule it (every 1–2 minutes if the Make plan allows) as the fallback for missed webhooks.
5. Second Make scenario or route on a schedule: `{"action":"status"}` → filter `alert = true` → email
   operations "ZIPLOGG notice backlog needs attention" (counts only).
6. Set Supabase secret `ZIPLOGG_LIVE_NOTIFY_HOOK` to the Make webhook URL, and redeploy `live-manual-checkout`.
7. Safe production checks without money: `status` returns zero counts; `claim` returns `send:false`.

## What still requires a real payment to verify
Stripe live webhook delivery → verified paid order → outbox row → Make → Zoho inbox. Only a genuine
customer payment (or an owner-chosen real purchase) can prove this. Do not insert fabricated paid rows
into the live tables to simulate it.

## Deployed configuration (October 15, 2026)
- Supabase: migration 015 applied; function live-order-notification-job deployed (Verify JWT OFF); secret ZIPLOGG_MAKE_LIVE_SECRET set 13:31 UTC (value never in chat/files).
- Supabase: secret ZIPLOGG_LIVE_NOTIFY_HOOK set (digest verified = Make webhook URL); live-manual-checkout redeployed with the wake-up (deployed source SHA-256 6f70dd31…0da8f = tested file; previous production source matched the pre-change local file). Verify JWT still OFF.
- Make scenario 6645386 "ZIPLOGG LIVE - paid order notices" (ACTIVE, instant):
  1 Webhooks Custom webhook "ZIPLOGG LIVE - paid order notice wake-up" (hook.us2.make.com/lr5g…)
  2 HTTP Make a request, API key connection "ZIPLOGG LIVE - Supabase notice worker" (header x-ziplogg-worker, allowed origin only https://ixgjoaaskhadbraaynkm.supabase.co), POST {"action":"claim"}, parse response, error on 4xx/5xx
  filter "Only when a notice was claimed": 2.data.send = true
  3 Zoho Mail Send an Email (existing connection "ZIPLOGG TEST - Zoho order emails", account/from/to operations@ziplogg.com, subject 2.data.subject, content 2.data.text, plain text)
  4 HTTP confirm {"action":"confirm","email_id":2.data.email_id,"claim_token":2.data.claim_token,"provider_reference":3.messageId}
- Separate from TEST scenario 6603753 (untouched). Note: the Zoho connection is shared with the TEST scenario; it is named TEST but sends from the operations mailbox.

## Verified in production (no money, no email)
- Rolled-back SQL check passed in production; 0 rows left.
- Make module 2 with {"action":"status"}: HTTP 200, live true, pending 0, stuck_sending 0, review 0, alert false.
- Make module 2 with {"action":"claim"}: HTTP 200, send false (nothing to send).

## Still open
- First real paid order is the first end-to-end run (Stripe live webhook -> paid -> outbox -> Make -> Zoho inbox -> confirm). Check Zoho inbox, Make history and outbox state after it.
- No scheduled fallback/alert scenario yet: if the wake-up call is lost, a notice stays pending until the webhook fires again or a manual Run once. Recommended: scheduled scenario calling {"action":"status"} every 15 min and emailing operations when alert = true.
- Zoho step failure leaves the notice in 'sending' (never auto-resent); check Zoho Sent before resetting it.
