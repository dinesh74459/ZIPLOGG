const {chromium}=require(process.env.PLAYWRIGHT_MODULE || 'playwright');
const assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({channel:'chrome',headless:true});
 const context=await browser.newContext({viewport:{width:1440,height:1000}}),page=await context.newPage();
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:4173/account.html');
 await page.getByText('Sign in to your private shipment notes.',{exact:true}).waitFor();
 await page.getByRole('button',{name:'Create account',exact:true}).click();
 assert(await page.locator('#auth-submit').isEnabled());
 await page.getByRole('button',{name:'Forgot your password?',exact:true}).click();
 assert(await page.locator('#auth-submit').isEnabled());
 assert(await page.locator('#password-field').isHidden());
 await page.getByRole('button',{name:'Sign in',exact:true}).click();
 await page.screenshot({path:'../outputs/ziplogg-account-desktop.png',fullPage:true});
 await page.setViewportSize({width:390,height:844});
 assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 await page.screenshot({path:'../outputs/ziplogg-account-mobile.png',fullPage:true});
 console.log('PASS: real client loads, email setup gates, desktop/mobile layouts');
 // UI contract tests use mocked responses. Database isolation is tested separately in SQL.
 let drafts=[],failSave=false;
 const user={id:'10000000-0000-4000-8000-000000000001',email:'ui-test@example.invalid',aud:'authenticated',role:'authenticated',app_metadata:{provider:'email'},user_metadata:{},created_at:new Date().toISOString()};
 const jwt=[Buffer.from(JSON.stringify({alg:'HS256',typ:'JWT'})).toString('base64url'),Buffer.from(JSON.stringify({sub:user.id,exp:Math.floor(Date.now()/1000)+3600,aud:'authenticated'})).toString('base64url'),'testsignature'].join('.');
 await context.route('https://ixgjoaaskhadbraaynkm.supabase.co/**',async route=>{
  const req=route.request(),url=new URL(req.url()),method=req.method();let body={},status=200;
  if(url.pathname==='/auth/v1/token')body={access_token:jwt,refresh_token:'ui-test-refresh',expires_in:3600,token_type:'bearer',user};
  else if(url.pathname==='/auth/v1/user')body=user;
  else if(url.pathname==='/auth/v1/logout')body={};
  else if(url.pathname==='/rest/v1/shipments')body=[{reference:'ZIP-TEST',status:'in_transit',shipment_bags:[{description:'Test bag',weight_lb:12,length_in:20,width_in:15,height_in:10}],shipment_events:[{message:'Package collected',occurred_at:'2026-09-27T12:00:00Z'}]}];
  else if(url.pathname==='/rest/v1/shipment_drafts'){
   if(method==='GET')body=drafts;
   else if(failSave){status=500;body={message:'test outage'};}
   else if(method==='POST'){const data=req.postDataJSON();drafts.push({...data,id:'draft-test',updated_at:new Date().toISOString()});body={id:'draft-test'};}
   else if(method==='PATCH'){Object.assign(drafts[0],req.postDataJSON());body={id:'draft-test'};}
   else if(method==='DELETE'){drafts=[];body={id:'draft-test'};}
  }else throw Error('Unexpected mocked request '+url.pathname);
  await route.fulfill({status,contentType:'application/json',body:JSON.stringify(body)});
 });
 await page.getByLabel('Email address',{exact:true}).fill(user.email);await page.getByLabel('Password',{exact:true}).fill('only-a-mocked-password');await page.locator('#auth-submit').click();
 await page.getByRole('heading',{name:'Welcome to ZIPLOGG',exact:true}).waitFor();await page.getByRole('button',{name:'Continue to my account',exact:true}).click();await page.getByRole('heading',{name:'ZIP-TEST',exact:true}).waitFor();assert(await page.getByText('In transit',{exact:true}).isVisible());await page.locator('#new-draft').waitFor({state:'visible'});await page.locator('#new-draft').click();
 await page.getByLabel('Draft title').fill('UI shipping test');await page.getByLabel('Route, packages and notes').fill('3 boxes from New York to London');
 await page.getByRole('button',{name:'Save draft',exact:true}).click();await page.getByRole('heading',{name:'UI shipping test',exact:true}).waitFor();
 await page.reload();await page.getByRole('heading',{name:'UI shipping test',exact:true}).waitFor();
 await page.getByRole('button',{name:'Edit note',exact:true}).click();assert.equal(await page.getByLabel('Route, packages and notes').inputValue(),'3 boxes from New York to London');
 await page.getByLabel('Draft title').fill('<img src=x onerror=alert(1)>');await page.getByRole('button',{name:'Save draft',exact:true}).click();await page.getByRole('heading',{name:'<img src=x onerror=alert(1)>',exact:true}).waitFor();assert.equal(await page.locator('.saved-draft img').count(),0);
 failSave=true;await page.getByLabel('Route, packages and notes').fill('Preserve this unsaved note');await page.getByRole('button',{name:'Save draft',exact:true}).click();await page.getByText('Draft was not saved. Your entered details are still here.',{exact:true}).waitFor();assert.equal(await page.getByLabel('Route, packages and notes').inputValue(),'Preserve this unsaved note');failSave=false;
 page.once('dialog',d=>d.accept());await page.getByRole('button',{name:'Delete',exact:true}).click();await page.getByText('Shipment note deleted.',{exact:true}).waitFor();assert.equal(drafts.length,0);
 await page.goto('http://127.0.0.1:4173/account.html?mode=recovery');await page.getByLabel('New password',{exact:true}).fill('mock-new-password-123');await page.getByLabel('Confirm new password',{exact:true}).fill('mock-new-password-123');await page.getByRole('button',{name:'Save new password',exact:true}).click();await page.getByText('Password updated.',{exact:true}).waitFor();
 const other=await context.newPage();await other.goto('http://127.0.0.1:4173/account.html');await other.locator('#signout').waitFor({state:'visible'});
 await page.getByRole('button',{name:'Sign out',exact:true}).click();await other.locator('#account-workspace').waitFor({state:'hidden'});assert.equal(await other.locator('#saved-drafts').textContent(),'');assert.equal(await other.locator('#shipment-history').textContent(),'');
 assert.deepEqual(errors,[]);console.log('PASS: mocked sign-in, create/edit/reload, escaping, failed-save preservation, deletion, password recovery, cross-tab sign-out');
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
