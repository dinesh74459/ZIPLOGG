import test from 'node:test';
import assert from 'node:assert/strict';
import {calculatePlannedPrice as price} from '../lib/pricing-plan.js';
const base={fedexRetailCents:10000,firstShipment:true};
test('45% of verified retail, with eligible extra 20% JAYHO',()=>{
 assert.equal(price(base).totalCents,4500);
 const q=price({...base,verifiedReferral:true,promoCode:'jayho'});assert.equal(q.totalCents,3600);assert.equal(q.discountCents,900);
 assert.equal(price({...base,fedexRetailCents:20000}).totalCents,9000);
 assert.equal(price({...base,fedexRetailCents:12345}).totalCents,5555);
 assert.equal(price({...base,fedexRetailCents:12345,verifiedReferral:true,promoCode:'JAYHO'}).totalCents,4444);
});
test('invalid rates and ineligible promos rejected',()=>{
 for(const fedexRetailCents of [0,-1,NaN,Infinity,'100',1.5,100000001])assert.throws(()=>price({...base,fedexRetailCents}));
 assert.throws(()=>price({...base,firstShipment:false,verifiedReferral:true,promoCode:'JAYHO'}));
 assert.throws(()=>price({...base,promoCode:'JAYHO'}));assert.throws(()=>price({...base,promoCode:'OTHER'}));
});
