-- ROLLBACK ONLY. Verifies migration 016 (flat Ground tariff). No email, no Stripe, nothing persists.
begin;
do $$
declare u uuid; r uuid:=gen_random_uuid(); r2 uuid:=gen_random_uuid(); o public.live_manual_orders; q public.live_manual_quotes;
 base jsonb; blocked boolean; p record; small uuid:=gen_random_uuid();
begin
 select id into u from auth.users where email_confirmed_at is not null and deleted_at is null limit 1;
 if u is null then raise exception 'Verified test identity required'; end if;
 perform set_config('request.jwt.claim.sub',u::text,true);
 perform set_config('request.jwt.claims',json_build_object('sub',u,'role','authenticated')::text,true);
 if has_table_privilege('anon','public.ground_tariff_bands','INSERT') or has_table_privilege('authenticated','public.ground_tariff_bands','UPDATE')
  or has_function_privilege('anon','public.create_flat_ground_quote(uuid,jsonb)','EXECUTE')
  or has_function_privilege('authenticated','public.reserve_live_manual_checkout(uuid,uuid,text)','EXECUTE')
 then raise exception 'Tariff or checkout privileges leaked'; end if;
 if exists(select 1 from public.live_manual_orders where user_id=u and state='awaiting_payment') then raise exception 'Test identity has a pending order; run later'; end if;

 -- Per-package pricing
 select * into p from public.ground_package_price(40,28,19,11,'luggage');
 if (p.rating_lb,p.base_cents,p.handling_cents,p.fee_cents)<>(43,6699,3960,0) then raise exception 'Suitcase price wrong: %',p; end if;
 select * into p from public.ground_package_price(40,28,19,11,'box');
 if (p.base_cents,p.handling_cents)<>(6699,0) then raise exception 'Boxed price wrong'; end if;
 select * into p from public.ground_package_price(75,30,20,12,'luggage');
 if (p.base_cents,p.handling_cents,p.fee_cents)<>(9199,0,10800) then raise exception 'Heavy fee wrong'; end if;
 select * into p from public.ground_package_price(55,24,18,10,'box');
 if (p.base_cents,p.handling_cents)<>(7199,6750) then raise exception 'Weight handling wrong'; end if;
 select * into p from public.ground_package_price(10,50,12,10,'box');
 if (p.rating_lb,p.handling_cents)<>(44,4620) then raise exception 'Dimension handling/minimum wrong'; end if;
 blocked:=false; begin perform public.ground_package_price(20,60,30,20,'box'); exception when others then blocked:=true; end;
 if not blocked then raise exception 'Oversize accepted'; end if;

 base:=jsonb_build_object('from',jsonb_build_object('name','Rollback Sender','phone','+1 617 555 0100','street','1 Example St','city','Boston','region','MA','postal','02108','country','United States'),
  'to',jsonb_build_object('name','Rollback Recipient','phone','+1 206 555 0100','street','2 Example Ave','city','Seattle','region','WA','postal','98101','country','United States'),
  'ship_date',(current_date+1)::text,
  'packages',jsonb_build_array(jsonb_build_object('weight',40,'length',28,'width',19,'height',11,'packaging','luggage'),jsonb_build_object('weight',75,'length',30,'width',20,'height',12,'packaging','luggage')));
 perform public.create_flat_ground_quote(r,base);
 perform public.create_flat_ground_quote(r,base); -- idempotent replay
 select * into q from public.live_manual_quotes where id=r;
 if q.pricing_source<>'flat_ground_v1' or q.price_cents<>6699+3960+9199 or q.fee_cents<>10800 or q.user_id<>u or not q.fulfillment_ready then raise exception 'Quote wrong: % %',q.price_cents,q.fee_cents; end if;
 blocked:=false; begin perform public.create_flat_ground_quote(r,jsonb_set(base,'{packages,0,weight}','1')); exception when others then blocked:=true; end;
 if not blocked then raise exception 'Changed replay accepted'; end if;
 o:=public.reserve_live_manual_checkout(u,r,'');
 if o.total_cents<>6699+3960+9199+10800 or o.regular_cents<>o.total_cents then raise exception 'Checkout amount wrong: %',o.total_cents; end if;
 blocked:=false; begin update public.live_manual_quotes set price_cents=1 where id=r; exception when others then blocked:=true; end;
 if not blocked then raise exception 'Reserved flat quote mutable'; end if;
 delete from public.live_manual_orders where id=r; -- allow next checks (still inside rollback)

 for p in select * from (values
   (jsonb_set(base,'{to,postal}','"99501"'),'Alaska'),
   (jsonb_set(base,'{to,postal}','"96813"'),'Hawaii'),
   (jsonb_set(base,'{to,postal}','"00901"'),'Puerto Rico'),
   (jsonb_set(base,'{to,country}','"Canada"'),'international'),
   (jsonb_set(base,'{packages}',(select jsonb_agg(base->'packages'->0) from generate_series(1,6))),'six packages'),
   (jsonb_set(base,'{packages,0,packaging}','"crate"'),'unknown packaging'),
   (jsonb_set(base,'{packages,0,weight}','101'),'over 100 lb'),
   (jsonb_set(base,'{to,name}','""'),'missing contact')) as t(s,label) loop
  blocked:=false; begin perform public.create_flat_ground_quote(gen_random_uuid(),p.s); exception when others then blocked:=true; end;
  if not blocked then raise exception 'Accepted: %',p.label; end if;
 end loop;

 -- Fixed small tariff unchanged by the new reserve function
 perform set_config('request.jwt.claim.sub',u::text,true);
 perform public.create_fixed_small_quote(small,jsonb_build_object('from',base->'from','to',base->'to','ship_date',base->'ship_date','package',jsonb_build_object('weight',0.8,'length',8,'width',6,'height',2)),'ground');
 o:=public.reserve_live_manual_checkout(u,small,'');
 if o.total_cents<>572 then raise exception 'Fixed small price changed: %',o.total_cents; end if;
 raise notice 'flat ground tariff checks passed';
end $$;
rollback;
select 'checks passed, rolled back' as result,(select count(*) from public.live_manual_quotes) as quotes_left,(select count(*) from public.live_manual_orders) as orders_left;
