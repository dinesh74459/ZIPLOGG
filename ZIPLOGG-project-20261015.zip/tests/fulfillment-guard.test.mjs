import test from 'node:test';
import assert from 'node:assert/strict';
import {validatePaidCheckout} from '../lib/fulfillment-guard.js';
const fixture = () => ({
 event:{id:'evt_test',type:'checkout.session.completed',livemode:false,data:{object:{id:'cs_test'}}},
 session:{id:'cs_test',livemode:false,mode:'payment',payment_status:'paid',payment_intent:'pi_test',metadata:{order_id:'order1'},client_reference_id:'order1',amount_total:2200,currency:'usd'},
 payment:{id:'pi_test',livemode:false,status:'succeeded',amount:2200,amount_received:2200,currency:'usd'},
 order:{id:'order1',checkout_session_id:'cs_test',live_mode:false,status:'awaiting_payment',total_cents:2200,currency:'usd',shippo_shipment_id:'shipment1',shippo_rate_id:'rate1'}
});
test('accepts a retrieved matching paid checkout',()=>assert.equal(validatePaidCheckout(fixture()).amountCents,2200));
test('accepts delayed payment only once payment succeeded',()=>{const f=fixture();f.event.type='checkout.session.async_payment_succeeded';assert.equal(validatePaidCheckout(f).paymentIntentId,'pi_test');});
test('blocks unpaid, mismatched, duplicate and mixed-mode events',()=>{
 for(const mutate of [
  f=>f.session.payment_status='unpaid', f=>f.payment.status='processing',
  f=>f.payment.amount_received=2100, f=>f.session.amount_total=1,
  f=>f.order.total_cents=0, f=>f.payment.currency='eur',
  f=>f.session.metadata.order_id='other', f=>f.session.payment_intent='other',
  f=>f.event.data.object.id='other', f=>f.order.status='queued',
  f=>f.order.shippo_rate_id='', f=>f.payment.livemode=true,
  f=>delete f.session.livemode, f=>f.event.type='payment_intent.created'
 ]) {const f=fixture();mutate(f);assert.throws(()=>validatePaidCheckout(f));}
});
