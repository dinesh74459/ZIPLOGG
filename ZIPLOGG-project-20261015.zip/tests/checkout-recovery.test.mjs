import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';
const source=stripTypeScriptTypes(readFileSync(new URL('../supabase/functions/customer-test-checkout/index.ts',import.meta.url),'utf8').replace(/^import .*;$/m,''));
const id='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
function fixture(change={}){
 let handler;const calls=[];let reads=0;
 const order={id,user_id:'owner',live_mode:false,retail_quote_id:id,status:'awaiting_payment',checkout_session_id:'cs_test_123',total_cents:3600,...change.order};
 const query={select(){return this},eq(k,v){calls.push({filter:k,value:v});return this},async maybeSingle(){return {data:change.missing?null:order}}};
 const db={auth:{getUser:async()=>({data:{user:{id:'owner',email_confirmed_at:'2026-10-13'}}})},from:()=>query,rpc:async(name,args)=>{calls.push({rpc:name,args});return {};}};
 new Function('Deno','createClient','fetch',source)({env:{get:n=>n==='ZIPLOGG_STRIPE_TEST_KEY'?'rk_test_fixture':'fixture'},serve:fn=>handler=fn},()=>db,async(url,options)=>{
  calls.push({url,method:options.method||'GET'});
  if(url.endsWith('/expire'))return new Response('{}',{status:change.expireFailure?409:200});
  reads++;
  return new Response(JSON.stringify({id:'cs_test_123',livemode:false,client_reference_id:id,amount_total:3600,currency:'usd',status:reads===1?'open':'expired',payment_status:'unpaid',...change.session,...(reads>1?change.after:{})}));
 });
 return {calls,run:()=>handler(new Request('https://example.test',{method:'POST',headers:{authorization:'Bearer fixture'},body:JSON.stringify({action:'cancel',order_id:id})}))};
}
test('cancellation checks owner, expires Stripe, rereads and only then releases',async()=>{const f=fixture();assert.equal((await f.run()).status,200);assert.ok(f.calls.some(c=>c.filter==='user_id'&&c.value==='owner'));assert.deepEqual(f.calls.filter(c=>c.url).map(c=>c.method),['GET','POST','GET']);assert.equal(f.calls.at(-1).rpc,'release_expired_test_checkout');});
test('paid, mismatched, pending and failed expiration never release JAYHO',async()=>{
 for(const change of [{session:{payment_status:'paid'}},{session:{livemode:true}},{session:{amount_total:1}},{session:{client_reference_id:'wrong'}},{order:{checkout_session_id:'pending_unknown'}},{expireFailure:true},{after:{status:'complete',payment_status:'paid'}},{missing:true}]){
  const f=fixture(change);assert.ok([404,409].includes((await f.run()).status));assert.ok(!f.calls.some(c=>c.rpc));
 }
});
test('already cancelled request is idempotent without Stripe access',async()=>{const f=fixture({order:{status:'cancelled'}});assert.equal((await f.run()).status,200);assert.ok(!f.calls.some(c=>c.url||c.rpc));});

test('already expired unpaid session releases reservation without another expiration request',async()=>{
 const f=fixture({session:{status:'expired'}});
 assert.equal((await f.run()).status,200);
 assert.deepEqual(f.calls.filter(c=>c.url).map(c=>c.method),['GET']);
 assert.equal(f.calls.at(-1).rpc,'release_expired_test_checkout');
});

test('incomplete expiration and post-expiration reference changes retain the reservation',async()=>{
 for(const after of [{status:'open'},{amount_total:1},{client_reference_id:'another-order'},{livemode:true}]) {
  const f=fixture({after});
  assert.equal((await f.run()).status,409);
  assert.ok(!f.calls.some(c=>c.rpc));
 }
});
