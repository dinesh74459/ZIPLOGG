-- ROLLBACK ONLY. Verifies the live paid-order notification outbox (migration 015).
-- Creates synthetic rows inside one transaction; nothing persists, no email is sent.
begin;
do $$
declare u uuid; q uuid:=gen_random_uuid(); q2 uuid:=gen_random_uuid(); q3 uuid:=gen_random_uuid();
 o public.live_manual_orders; c record; blocked boolean; n int; tok uuid; eid uuid; b record;
begin
 select id into u from auth.users where email_confirmed_at is not null and deleted_at is null limit 1;
 if u is null then raise exception 'Verified test identity required'; end if;
 if exists(select 1 from public.live_order_notifications where state in ('pending','sending')) then
  raise exception 'Real notices are pending or sending; do not run this check now';
 end if;
 if has_table_privilege('authenticated','public.live_order_notifications','SELECT')
 or has_table_privilege('anon','public.live_order_notifications','SELECT')
 or has_function_privilege('authenticated','public.claim_live_order_notification()','EXECUTE')
 or has_function_privilege('anon','public.claim_live_order_notification()','EXECUTE')
 or has_function_privilege('authenticated','public.confirm_live_order_notification(uuid,uuid,text)','EXECUTE')
 or has_function_privilege('authenticated','public.live_order_notification_backlog(interval)','EXECUTE')
 then raise exception 'Private notification access leaked'; end if;

 -- Order 1: paid exactly once -> exactly one notice.
 insert into public.live_manual_quotes(id,user_id,summary,retail_cents,postage_cents,evidence,shipment,expires_at,approved_by,fulfillment_ready)
 values(q,u,'ROLLBACK ONLY: notification safeguard test',10000,3000,'Synthetic test, never a payable shipment',
  '{"service":"ground","to":{"name":"Rollback Fixture"}}',now()+interval '1 hour',u,true);
 o:=public.reserve_live_manual_checkout(u,q,'');
 perform public.bind_live_manual_checkout(q,'cs_live_rollback_notice_1',4500);
 if exists(select 1 from public.live_order_notifications where order_id=q) then raise exception 'Notice before payment'; end if;
 perform public.confirm_live_manual_payment(q,'cs_live_rollback_notice_1','pi_rollback_notice_1',4500);
 perform public.confirm_live_manual_payment(q,'cs_live_rollback_notice_1','pi_rollback_notice_1',4500);
 select count(*) into n from public.live_order_notifications where order_id=q and state='pending';
 if n<>1 then raise exception 'Expected exactly one pending notice, got %',n; end if;

 select * into b from public.live_order_notification_backlog();
 if b.pending<>1 then raise exception 'Backlog pending count wrong'; end if;

 select * into c from public.claim_live_order_notification();
 if c.order_id is distinct from q or c.recipient<>'operations@ziplogg.com' or c.payment_id<>'pi_rollback_notice_1'
  or c.total_cents<>4500 or c.shipment#>>'{to,name}'<>'Rollback Fixture' or c.customer_email is null
 then raise exception 'Claim payload wrong'; end if;
 eid:=c.email_id; tok:=c.claim_token;
 select count(*) into n from public.claim_live_order_notification();
 if n<>0 then raise exception 'Second claim must not return the same notice'; end if;

 blocked:=false; begin perform public.confirm_live_order_notification(eid,gen_random_uuid(),'zoho-rollback-1'); exception when others then blocked:=true; end;
 if not blocked then raise exception 'Wrong claim token accepted'; end if;
 blocked:=false; begin perform public.confirm_live_order_notification(eid,tok,'  '); exception when others then blocked:=true; end;
 if not blocked then raise exception 'Blank provider evidence accepted'; end if;
 perform public.confirm_live_order_notification(eid,tok,'zoho-rollback-1');
 perform public.confirm_live_order_notification(eid,tok,'zoho-rollback-1');
 blocked:=false; begin perform public.confirm_live_order_notification(eid,tok,'zoho-rollback-2'); exception when others then blocked:=true; end;
 if not blocked then raise exception 'Conflicting evidence accepted'; end if;
 if (select state from public.live_order_notifications where id=eid)<>'sent' then raise exception 'Not marked sent'; end if;

 -- A re-paid/replayed confirmation after sending must not create another notice.
 perform public.confirm_live_manual_payment(q,'cs_live_rollback_notice_1','pi_rollback_notice_1',4500);
 if (select count(*) from public.live_order_notifications where order_id=q)<>1 then raise exception 'Duplicate notice after send'; end if;

 -- Order 2: uncertain send stays out of automatic claims and shows as stuck.
 insert into public.live_manual_quotes(id,user_id,summary,retail_cents,postage_cents,evidence,shipment,expires_at,approved_by,fulfillment_ready)
 values(q2,u,'ROLLBACK ONLY: stuck notice test',10000,3000,'Synthetic test, never a payable shipment','{}',now()+interval '1 hour',u,true);
 o:=public.reserve_live_manual_checkout(u,q2,'');
 perform public.bind_live_manual_checkout(q2,'cs_live_rollback_notice_2',4500);
 perform public.confirm_live_manual_payment(q2,'cs_live_rollback_notice_2','pi_rollback_notice_2',4500);
 select * into c from public.claim_live_order_notification();
 if c.order_id is distinct from q2 then raise exception 'Second order notice not claimed'; end if;
 update public.live_order_notifications set claimed_at=now()-interval '11 minutes' where id=c.email_id;
 select count(*) into n from public.claim_live_order_notification();
 if n<>0 then raise exception 'Uncertain send was reclaimed automatically'; end if;
 select * into b from public.live_order_notification_backlog();
 if b.stuck_sending<>1 then raise exception 'Stuck notice not reported'; end if;

 -- Order 3: expired unpaid checkout never produces a notice.
 insert into public.live_manual_quotes(id,user_id,summary,retail_cents,postage_cents,evidence,shipment,expires_at,approved_by,fulfillment_ready)
 values(q3,u,'ROLLBACK ONLY: expired notice test',10000,3000,'Synthetic test, never a payable shipment','{}',now()+interval '1 hour',u,true);
 o:=public.reserve_live_manual_checkout(u,q3,'');
 update public.live_manual_orders set state='expired' where id=q3;
 if exists(select 1 from public.live_order_notifications where order_id=q3) then raise exception 'Notice for unpaid order'; end if;
 raise notice 'live order notification checks passed';
end $$;
rollback;
