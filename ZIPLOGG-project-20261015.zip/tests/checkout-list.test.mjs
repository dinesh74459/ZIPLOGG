import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';
const source=stripTypeScriptTypes(readFileSync(new URL('../supabase/functions/customer-test-checkout/index.ts',import.meta.url),'utf8').replace(/^import .*;$/m,''));
test('listing is scoped to verified owner and test mode; never sends carrier evidence or calls Stripe',async()=>{
 let handler;const queries=[];
 const db={auth:{getUser:async()=>({data:{user:{id:'owner',email_confirmed_at:'yes'}}})},from(table){const filters=[];queries.push({table,filters});const q={select(s){this.fields=s;return this;},eq(...a){filters.push(a);return this;},gt(...a){filters.push(a);return this;},not(...a){filters.push(a);return this;},order(){return this;},limit(){return Promise.resolve({data:table==='retail_quotes'?[{id:'quote',fedex_retail_cents:10000,test_fixture:true,expires_at:'2099-01-01'}]:[]});}};queries.at(-1).query=q;return q;}};
 new Function('Deno','createClient','fetch',source)({env:{get:n=>n==='ZIPLOGG_STRIPE_TEST_KEY'?'rk_test_fixture':'fixture'},serve:fn=>handler=fn},()=>db,()=>{throw Error('Must not call Stripe');});
 const response=await handler(new Request('https://test.invalid',{method:'POST',headers:{authorization:'Bearer test'},body:JSON.stringify({action:'list',user_id:'other'})}));
 assert.equal(response.status,200);const body=await response.json();assert.equal(body.quotes[0].test_fixture,true);assert.equal(body.quotes[0].regular_cents,4500);assert.equal(body.quotes[0].fedex_retail_cents,10000);
 for(const q of queries){assert.ok(q.filters.some(([key,value])=>key==='user_id'&&value==='owner'));assert.ok(q.filters.some(([key,value])=>key==='live_mode'&&value===false));assert.ok(!/(?:^|,)evidence(?:,|$)|shippo_|checkout_session_id/.test(q.query.fields));}
});
