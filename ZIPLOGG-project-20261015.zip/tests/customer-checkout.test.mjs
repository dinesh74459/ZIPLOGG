import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';
const source=stripTypeScriptTypes(readFileSync(new URL('../supabase/functions/customer-test-checkout/index.ts',import.meta.url),'utf8').replace(/^import .*;$/m,''));
const id='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
function fixture({key='rk_test_fixture',eligible=true,verified=true,consent=true}={}){
 let handler;const calls=[];
 const db={auth:{getUser:async()=>({data:{user:verified?{id:'trusted-user',email_confirmed_at:'2026-10-13'}:null}})},rpc:async(name,args)=>{calls.push({name,args});return name==='reserve_test_checkout'?eligible?{data:{id,total_cents:3600,live_mode:false,promo_code:'JAYHO',checkout_session_id:'pending_'+id}}:{error:{}}:{};}};
 new Function('Deno','createClient','fetch',source)({env:{get:n=>n==='ZIPLOGG_STRIPE_TEST_KEY'?key:'fixture'},serve:fn=>handler=fn},()=>db,async(url,options)=>{calls.push({url,amount:options.body?.get('line_items[0][price_data][unit_amount]')});return new Response(JSON.stringify({id:'cs_test_123',livemode:false,amount_total:3600,client_reference_id:id,status:'open',url:'https://checkout.stripe.com/test'}));});
 return {calls,run:()=>handler(new Request('https://example.test',{method:'POST',headers:{authorization:'Bearer fixture'},body:JSON.stringify({order_id:id,quote_id:id,promo_code:'JAYHO',adjustment_consent:consent,consent_version:'adjustments-test-v1',user_id:'attacker',total_cents:1})}))};
}
test('checkout ignores client price and identity; reserves before Stripe',async()=>{const f=fixture();assert.equal((await f.run()).status,200);assert.equal(f.calls[0].args.p_user_id,'trusted-user');assert.equal(f.calls[2].amount,'3600');assert.equal(f.calls[3].name,'bind_test_checkout');});
test('ineligible promo never creates Stripe session',async()=>{const f=fixture({eligible:false});assert.equal((await f.run()).status,409);assert.equal(f.calls.length,1);});
test('live key and unverified users cannot checkout',async()=>{for(const settings of [{key:'rk_live_fixture'},{verified:false}]){const f=fixture(settings);assert.ok([401,503].includes((await f.run()).status));assert.equal(f.calls.length,0);}});

test('unchecked consent blocks checkout before reservation or Stripe',async()=>{const f=fixture({consent:false});assert.equal((await f.run()).status,400);assert.equal(f.calls.length,0);});
