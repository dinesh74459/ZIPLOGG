import test from 'node:test';
import assert from 'node:assert/strict';
import {convertMeasurement,isInternational,moneyTotal} from '../dist/shipment-utils.js';
test('unit switching converts values rather than relabeling',()=>{assert.equal(convertMeasurement('10','length',true),'25.4');assert.equal(convertMeasurement('25.4','length',false),'10');assert.equal(convertMeasurement('10','weight',true),'4.5359');assert.equal(convertMeasurement('','weight',true),'');});
test('international routes need two different countries',()=>{assert.equal(isInternational('','India'),false);assert.equal(isInternational('India','India'),false);assert.equal(isInternational('India','United States'),true);});
test('customs values multiply quantity by per-unit value',()=>{assert.equal(moneyTotal([{quantity:'3',value:'12.50'},{quantity:'2',value:'0.10'}]),37.7);});
