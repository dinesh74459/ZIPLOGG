begin;
do $$
declare u uuid; q uuid:=gen_random_uuid(); s jsonb; got uuid; amount bigint;
begin
 select id into u from auth.users where email='dmeda910@gmail.com' and email_confirmed_at is not null;
 if u is null then raise exception 'Test account missing'; end if;
 perform set_config('request.jwt.claim.sub',u::text,true);
 s:='{"from":{"country":"United States","name":"Test sender","phone":"+12025550101","street":"Test street","city":"Boston","region":"MA","postal":"02108"},"to":{"country":"United States","name":"Test recipient","phone":"+12025550102","street":"Test street","city":"New York","region":"NY","postal":"10001"},"package":{"weight":1,"length":6,"width":4,"height":3}}'::jsonb||jsonb_build_object('ship_date',current_date::text);
 got:=public.create_fixed_small_quote(q,s,'ground');
 if got<>q or public.create_fixed_small_quote(q,s,'ground')<>q then raise exception 'Retry failed'; end if;
 select round(retail_cents*.45) into amount from public.live_manual_quotes where id=q;
 if amount<>572 then raise exception 'Incorrect price'; end if;
 begin
  perform public.create_fixed_small_quote(gen_random_uuid(),jsonb_set(s,'{package,weight}','2'),'ground');
  raise exception 'FAIL overweight accepted';
 exception when others then if SQLERRM like 'FAIL%' then raise; end if; end;
 begin
  perform public.create_fixed_small_quote(gen_random_uuid(),jsonb_set(s,'{to,country}','"Canada"'),'ground');
  raise exception 'FAIL international accepted';
 exception when others then if SQLERRM like 'FAIL%' then raise; end if; end;
 begin
  perform public.create_fixed_small_quote(gen_random_uuid(),jsonb_set(s,'{package,length}','100'),'ground');
  raise exception 'FAIL dimensional weight accepted';
 exception when others then if SQLERRM like 'FAIL%' then raise; end if; end;
 begin
  perform public.create_fixed_small_quote(gen_random_uuid(),s,'unknown');
  raise exception 'FAIL unknown service accepted';
 exception when others then if SQLERRM like 'FAIL%' then raise; end if; end;
 if has_function_privilege('anon','public.create_fixed_small_quote(uuid,jsonb,text)','execute') then raise exception 'Anonymous access'; end if;
 if has_table_privilege('authenticated','public.live_manual_quotes','insert') then raise exception 'Direct customer price insertion'; end if;
end $$;
rollback;
select 'Fixed checkout safeguards passed; no test records retained' as result;
