import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';
import {createHmac} from 'node:crypto';
const load=f=>stripTypeScriptTypes(readFileSync(new URL('../supabase/functions/'+f+'/index.ts',import.meta.url),'utf8').replace(/^import .*;$/m,''));
const source=load('live-order-notification-job');
const SECRET='s'.repeat(40),E='11111111-1111-4111-8111-111111111111',T='22222222-2222-4222-8222-222222222222',O='33333333-3333-4333-8333-333333333333';
const notice=(o={})=>({email_id:E,claim_token:T,recipient:'operations@ziplogg.com',order_id:O,order_state:'paid',customer_email:'buyer@example.test',total_cents:572,regular_cents:572,promo_code:null,payment_id:'pi_fixture',paid_at:'2026-10-15T01:00:00Z',summary:'Ground delivery · small parcel up to 1 lb · Boston to Seattle',pricing_source:'fixed_small_v1',shipment:{service:'ground',ship_date:'2026-10-16',from:{name:'Ann Sender',phone:'+1 617 555 0100',street:'1 Main St',city:'Boston',region:'MA',postal:'02108',country:'United States'},to:{name:'Bob\r\nBcc: attacker@evil.test',phone:'+1 206 555 0100',street:'2 Pine St',city:'Seattle',region:'WA',postal:'98101',country:'United States'},package:{weight:0.8,length:8,width:6,height:2}},...o});
function fixture({secret=SECRET,claim=[notice()],rpcError=null,backlog={pending:0,stuck_sending:0,review:0,oldest_pending_seconds:0}}={}){
 let handler;const calls=[];
 const db={rpc:async(name,args)=>{calls.push({name,args});if(rpcError)return {error:rpcError};return {data:name==='claim_live_order_notification'?claim:name==='live_order_notification_backlog'?[backlog]:null};}};
 new Function('Deno','createClient',source)({env:{get:n=>n==='ZIPLOGG_MAKE_LIVE_SECRET'?secret:'fixture'},serve:fn=>handler=fn},()=>db);
 return {calls,run:async(body,worker=SECRET)=>{const r=await handler(new Request('https://example.test',{method:'POST',headers:{'x-ziplogg-worker':worker},body:JSON.stringify(body)}));return {status:r.status,body:await r.json()};}};
}
test('missing or weak secret and wrong worker header never touch the database',async()=>{
 for(const s of [null,'short']){const f=fixture({secret:s});assert.equal((await f.run({action:'claim'})).status,503);assert.equal(f.calls.length,0);}
 const f=fixture();assert.equal((await f.run({action:'claim'},'wrong')).status,401);assert.equal((await f.run({action:'claim'},'')).status,401);assert.equal(f.calls.length,0);
});
test('empty outbox returns send:false',async()=>{const r=await fixture({claim:[]}).run({action:'claim'});assert.equal(r.status,200);assert.equal(r.body.send,false);});
test('claimed notice carries fulfillment details, fixed ops recipient, and no injected lines',async()=>{
 const r=await fixture().run({action:'claim'});assert.equal(r.status,200);const b=r.body;
 assert.equal(b.send,true);assert.equal(b.to,'operations@ziplogg.com');assert.equal(b.email_id,E);assert.equal(b.claim_token,T);
 assert.match(b.subject,/^ZIPLOGG LIVE PAID ORDER 33333333 — send label/);assert.ok(!/[\r\n]/.test(b.subject));
 for(const s of [O,'USD 5.72','pi_fixture','buyer@example.test','Ann Sender','1 Main St','Boston, MA 02108','2 Pine St','Seattle, WA 98101','0.8 lb','8 x 6 x 2 in','ground','2026-10-16'])assert.ok(b.text.includes(s),'missing '+s);
 assert.ok(!/^Bcc:/m.test(b.text),'customer text created a new line');assert.match(b.text,/Bob Bcc: attacker/);
 assert.match(b.text,/Oct 14, 2026, 9:00:00 PM EDT — label due by 9:05 PM/);
});
test('promo and non-paid order states are made explicit',async()=>{
 const p=(await fixture({claim:[notice({promo_code:'JAYHO',total_cents:3600,regular_cents:4500})]}).run({action:'claim'})).body;assert.match(p.text,/USD 36\.00 \(regular USD 45\.00, JAYHO applied\)/);
 const r=(await fixture({claim:[notice({order_state:'refunded'})]}).run({action:'claim'})).body;assert.match(r.subject,/^\[ORDER STATE REFUNDED — CHECK BEFORE SENDING\]/);
});
test('suspicious claim payloads fail closed without a sendable notice',async()=>{
 for(const bad of [{recipient:'someone@else.test'},{payment_id:'cs_live_x'},{total_cents:'572'},{claim_token:'x'}]){const r=await fixture({claim:[notice(bad)]}).run({action:'claim'});assert.equal(r.status,503);assert.equal(r.body.send,undefined);}
 const r=await fixture({rpcError:{}}).run({action:'claim'});assert.equal(r.status,503);
});
test('confirm requires claim identity and provider evidence; mismatch is 409',async()=>{
 const f=fixture();
 for(const b of [{},{email_id:E,claim_token:T},{email_id:E,claim_token:T,provider_reference:'  '},{email_id:'x',claim_token:T,provider_reference:'1'},{email_id:E,claim_token:T,provider_reference:'x'.repeat(501)}])assert.equal((await f.run({action:'confirm',...b})).status,400);
 assert.equal(f.calls.length,0);
 const ok=await f.run({action:'confirm',email_id:E,claim_token:T,provider_reference:' 1792000000000 '});assert.equal(ok.status,200);assert.equal(ok.body.recorded,true);assert.equal(f.calls[0].args.p_reference,'1792000000000');
 assert.equal((await fixture({rpcError:{}}).run({action:'confirm',email_id:E,claim_token:T,provider_reference:'1'})).status,409);
});
test('status raises alert for stuck, review or slow notices only',async()=>{
 assert.equal((await fixture().run({action:'status'})).body.alert,false);
 for(const k of [{stuck_sending:1},{review:1},{pending:1,oldest_pending_seconds:121}]){const r=await fixture({backlog:{pending:0,stuck_sending:0,review:0,oldest_pending_seconds:0,...k}}).run({action:'status'});assert.equal(r.body.alert,true);}
 assert.equal((await fixture().run({action:'other'})).status,400);
});

// live-manual-checkout: optional data-free wake-up after verified payment
const checkout=load('live-manual-checkout');
async function webhookRun(hook,hookFails=false){
 let handler;const urls=[];const id='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
 const order={id,session_id:'cs_live_fixture',total_cents:4500,state:'awaiting_payment'};
 const db={from:()=>({select:()=>({eq:()=>({maybeSingle:async()=>({data:order})})})}),rpc:async()=>{order.state='paid';return {};}};
 const env={ZIPLOGG_LIVE_MANUAL_ENABLED:'true',ZIPLOGG_STRIPE_LIVE_KEY:'rk_live_fixture',ZIPLOGG_STRIPE_LIVE_WEBHOOK_SECRET:'fixture',ZIPLOGG_LIVE_NOTIFY_HOOK:hook};
 new Function('Deno','createClient','fetch',checkout)({env:{get:n=>env[n]??'fixture'},serve:fn=>handler=fn},()=>db,async(url,opts)=>{urls.push({url,body:opts?.body});if(url.startsWith('https://hook.'))return hookFails?Promise.reject(new Error('down')):new Response('Accepted');return new Response(JSON.stringify(url.includes('payment_intents/')?{id:'pi_fixture',livemode:true,status:'succeeded',currency:'usd',amount:4500,amount_received:4500}:{id:'cs_live_fixture',livemode:true,client_reference_id:id,metadata:{ziplogg_flow:'manual-v1'},amount_total:4500,currency:'usd',mode:'payment',payment_status:'paid',payment_intent:'pi_fixture'}));});
 const raw=JSON.stringify({livemode:true,type:'checkout.session.completed',data:{object:{id:'cs_live_fixture',metadata:{ziplogg_flow:'manual-v1'}}}});
 const t=String(Math.floor(Date.now()/1000)),sig=createHmac('sha256','fixture').update(t+'.'+raw).digest('hex');
 const res=await handler(new Request('https://example.test',{method:'POST',headers:{'stripe-signature':`t=${t},v1=${sig}`},body:raw}));
 return {status:res.status,urls};
}
test('verified live payment wakes the notice worker with an empty body',async()=>{const r=await webhookRun('https://hook.us2.make.com/abc123XYZ');assert.equal(r.status,200);const k=r.urls.filter(u=>u.url.startsWith('https://hook.'));assert.equal(k.length,1);assert.equal(k[0].body,'{}');});
test('wake-up failure does not fail the Stripe webhook; non-Make URLs are never called',async()=>{
 assert.equal((await webhookRun('https://hook.us2.make.com/abc',true)).status,200);
 for(const h of ['','https://evil.test/hook','http://hook.us2.make.com/abc','https://hook.us2.make.com.evil.test/abc']){const r=await webhookRun(h);assert.equal(r.status,200);assert.equal(r.urls.length,2,h);}
});
