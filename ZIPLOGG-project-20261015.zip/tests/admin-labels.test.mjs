import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';
const source=stripTypeScriptTypes(readFileSync(new URL('../supabase/functions/admin-test-labels/index.ts',import.meta.url),'utf8').replace(/^import .*;$/m,''));
const id='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
function fixture({staff=true,verified=true,live=false,paid=true,conflict=false,oneToOne=false}={}){
 let handler;const calls=[];
 const db={auth:{getUser:async()=>({data:{user:verified?{id:'trusted-user',email_confirmed_at:'2026-10-13'}:null}})},from(table){const q={select(){return q;},eq(){return q;},in(){return q;},order(){return q;},limit:async()=>({data:[]}),update(value){calls.push({update:value});return q;},maybeSingle:async()=>({data:table==='test_label_operators'?(staff?{user_id:'trusted-user'}:null):{id,live_mode:live,status:paid?'queued':'awaiting_payment',fulfillment_jobs:paid?(oneToOne?{id}:[{id}]):[]}})};return q;},rpc:async(name,args)=>{calls.push({name,args});return conflict?{error:{}}:{data:id};},storage:{from(){return {upload:async(path,bytes,options)=>{calls.push({upload:path,options});return {};}};}}};
 new Function('Deno','createClient',source)({env:{get:()=> 'test'},serve:fn=>handler=fn},()=>db);
 return {calls,run:(body)=>handler(new Request('https://example.test',{method:'POST',headers:{authorization:'Bearer fixture',origin:'https://ziplogg.com'},body:JSON.stringify({order_id:id,...body})}))};
}
const upload={action:'upload',sample_confirmed:true,pdf_base64:Buffer.from('%PDF-1.7\nSAMPLE NOT VALID FOR SHIPPING').toString('base64')};
test('customer cannot list staff orders or upload PDFs',async()=>{for(const action of [{action:'list'},upload]){const f=fixture({staff:false});assert.equal((await f.run(action)).status,403);assert.equal(f.calls.length,0);}});
test('unverified, live and unpaid orders are blocked before storage',async()=>{for(const options of [{verified:false},{live:true},{paid:false}]){const f=fixture(options);assert.ok([401,409].includes((await f.run(upload)).status));assert.equal(f.calls.length,0);}});
test('non-PDF and unchecked sample confirmation cannot prepare delivery',async()=>{for(const body of [{...upload,pdf_base64:Buffer.from('<script>bad</script>').toString('base64')},{...upload,sample_confirmed:false}]){const f=fixture();assert.equal((await f.run(body)).status,400);assert.equal(f.calls.length,0);}});
test('upload is content-addressed, private and never overwrites a file',async()=>{const f=fixture();assert.equal((await f.run({...upload,recipient:'attacker@example.test',live_mode:true})).status,200);assert.equal(f.calls[0].name,'prepare_manual_delivery');assert.equal(f.calls[0].args.p_sample,true);assert.equal(f.calls[0].args.p_tracking,null);assert.match(f.calls[1].upload,new RegExp('^'+id+'/[a-f0-9]{64}\\.pdf$'));assert.equal(f.calls[1].options.upsert,false);});
test('different delivery conflict prevents storage mutation',async()=>{const f=fixture({conflict:true});assert.equal((await f.run(upload)).status,409);assert.equal(f.calls.length,1);});
test('unique payment relation supports the one-to-one response',async()=>{const f=fixture({oneToOne:true});assert.equal((await f.run(upload)).status,200);});
