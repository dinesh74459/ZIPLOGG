import test from 'node:test';
import assert from 'node:assert/strict';
import {orderNotification} from '../lib/order-notification.js';
test('review message cannot imply a purchased label or ask for a second payment',()=>{const m=orderNotification({reference:'TEST-1',state:'manual_review',testOnly:true});assert.match(m.subject,/^\[TEST\]/);assert.match(m.text,/No label is ready/);assert.match(m.text,/Do not create another payment/);});
test('label email requires tracking and HTTPS, and escapes customer-controlled text',()=>{for(const p of [{},{trackingNumber:'123',labelUrl:'http://example.com/a'},{trackingNumber:'123',labelUrl:'https://user:password@example.com/a'}])assert.throws(()=>orderNotification({reference:'1',state:'label_ready',...p}));const m=orderNotification({reference:'<script>alert(1)</script>',state:'label_ready',trackingNumber:'123',labelUrl:'https://example.com/label.pdf',testOnly:true});assert.ok(!m.html.includes('<script>'));assert.match(m.text,/no real shipment/);});
test('unknown state and missing order are rejected',()=>{assert.throws(()=>orderNotification({reference:'1',state:'refunded'}));assert.throws(()=>orderNotification({state:'cancelled'}));});
