import test from 'node:test';
import assert from 'node:assert/strict';
import {isConfigured} from '../dist/account-client.js';
test('incomplete settings cannot enable accounts',()=>{assert.equal(isConfigured({enabled:true,url:'',publishableKey:''}),false);});
test('only public keys on a secure Supabase origin enable setup',()=>{const valid={enabled:true,url:'https://test-project.supabase.co',publishableKey:'sb_publishable_example'};assert.equal(isConfigured(valid),true);for(const key of ['sb_secret_example','service_role',''])assert.equal(isConfigured({...valid,publishableKey:key}),false);assert.equal(isConfigured({...valid,url:'http://test-project.supabase.co'}),false);assert.equal(isConfigured({...valid,enabled:false}),false);});
