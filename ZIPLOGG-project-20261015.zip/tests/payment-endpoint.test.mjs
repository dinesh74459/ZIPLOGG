import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';
const source=stripTypeScriptTypes(readFileSync(new URL('../supabase/functions/verify-payment-job/index.ts',import.meta.url),'utf8').replace(/^import .*;$/m,''));
const orderId='12345678-1234-1234-1234-123456789012';
function setup(change=()=>{}) {
 const state={env:{ZIPLOGG_MAKE_TEST_SECRET:'test-worker',ZIPLOGG_STRIPE_TEST_KEY:'rk_test_fixture'},calls:0,queued:0,
 event:{id:'evt_fixture',type:'checkout.session.completed',livemode:false,data:{object:{id:'cs_fixture'}}},
 session:{id:'cs_fixture',metadata:{order_id:orderId},client_reference_id:orderId,mode:'payment',livemode:false,payment_status:'paid',payment_intent:'pi_fixture',amount_total:2200,currency:'usd'},
 payment:{id:'pi_fixture',livemode:false,status:'succeeded',amount:2200,amount_received:2200,currency:'usd'},
 order:{id:orderId,live_mode:false,checkout_session_id:'cs_fixture',total_cents:2200,currency:'usd',status:'awaiting_payment',shippo_shipment_id:'ship_fixture',shippo_rate_id:'rate_fixture'},existing:null};
 change(state);
 let handler;
 const db={from(table){return {select(){return this},eq(){return this},single:async()=>({data:state.order}),maybeSingle:async()=>({data:state.existing})}},rpc:async()=>{state.queued++;return {data:'job_fixture'}}};
 new Function('Deno','createClient','fetch',source)({env:{get:key=>state.env[key]},serve:fn=>handler=fn},()=>db,async url=>{
 state.calls++;const data=url.includes('/events/')?state.event:url.includes('/checkout/')?state.session:state.payment;
 return new Response(JSON.stringify(data),{status:200});
 });
 return {state,run:(key='test-worker')=>handler(new Request('https://example.test',{method:'POST',headers:{'x-ziplogg-worker':key},body:JSON.stringify({event_id:'evt_fixture'})}))};
}
test('endpoint rejects unauthorized callers before Stripe requests',async()=>{const f=setup();assert.equal((await f.run('wrong')).status,401);assert.equal(f.state.calls,0)});
test('endpoint refuses live credentials',async()=>{const f=setup(s=>s.env.ZIPLOGG_STRIPE_TEST_KEY='sk_live_fixture');assert.equal((await f.run()).status,503);assert.equal(f.state.calls,0)});
test('matching test payment is queued without claiming or purchasing',async()=>{const f=setup();const r=await f.run();assert.equal(r.status,200);assert.deepEqual(await r.json(),{ready:false,queued:true,job_id:'job_fixture'});assert.equal(f.state.queued,1)});
test('duplicate notification does not enqueue or purchase again',async()=>{const f=setup(s=>s.existing={id:'job_fixture'});assert.equal((await (await f.run()).json()).duplicate,true);assert.equal(f.state.queued,0)});
test('amount, environment and order-reference tampering cannot queue',async()=>{
 for(const mutate of [s=>s.payment.amount_received=1,s=>s.session.livemode=true,s=>s.order.checkout_session_id='other',s=>s.session.client_reference_id='other',s=>s.order.currency='eur',s=>s.payment.status='processing']) {
 const f=setup(mutate);assert.equal((await f.run()).status,422);assert.equal(f.state.queued,0);
 }
});

test('failed, expired, unpaid and cancelled payments never create fulfillment jobs',async()=>{
 for(const mutate of [
  s=>s.event.type='checkout.session.async_payment_failed',
  s=>s.event.type='checkout.session.expired',
  s=>s.event.type='payment_intent.payment_failed',
  s=>s.session.payment_status='unpaid',
  s=>s.session.payment_status='no_payment_required',
  s=>s.payment.status='requires_payment_method',
  s=>s.payment.status='requires_action',
  s=>s.payment.status='canceled',
  s=>s.order.status='cancelled',
 ]) {
  const f=setup(mutate);
  assert.equal((await f.run()).status,422);
  assert.equal(f.state.queued,0,'Unsafe payment must not enqueue a label or email');
 }
});
