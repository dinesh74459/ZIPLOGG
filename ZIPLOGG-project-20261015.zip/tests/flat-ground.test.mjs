import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';
import {groundBands,groundPackagePrice,contiguousUsZip,heavyBagFee} from '../dist/luggage-pricing.js';
import {groundQuote,smallParcelEligible} from '../dist/fixed-small-checkout.js';
const migration=readFileSync(new URL('../supabase/migrations/016_flat_ground_tariff.sql',import.meta.url),'utf8');
test('website band table is identical to the server tariff in migration 016',()=>{
 const sql=[...migration.match(/insert into public\.ground_tariff_bands values([\s\S]*?);/)[1].matchAll(/\((\d+),(\d+)\)/g)].map(m=>[+m[1],+m[2]]);
 assert.deepEqual(groundBands,sql);
 for(let i=1;i<sql.length;i++)assert.ok(sql[i][1]>sql[i-1][1]&&sql[i][0]>sql[i-1][0],'bands must increase');
});
test('package prices match the server reference cases',()=>{
 const c=(weight,dimensions,packaging)=>groundPackagePrice({weight,dimensions,packaging});
 assert.deepEqual(c(40,[28,19,11],'luggage'),{ratingWeight:43,baseCents:6699,handlingCents:3960,feeCents:0});
 assert.deepEqual(c(40,[28,19,11],'box'),{ratingWeight:43,baseCents:6699,handlingCents:0,feeCents:0});
 assert.deepEqual(c(75,[30,20,12],'luggage'),{ratingWeight:75,baseCents:9199,handlingCents:0,feeCents:10800});
 assert.deepEqual(c(55,[24,18,10],'box'),{ratingWeight:55,baseCents:7199,handlingCents:6750,feeCents:0});
 assert.deepEqual(c(10,[50,12,10],'box'),{ratingWeight:44,baseCents:6699,handlingCents:4620,feeCents:0});
 assert.equal(c(1.5,[6,4,2],'box').baseCents,2599);assert.equal(c(1.5,[10,8,4],'box').baseCents,2899);
 for(const bad of [[0,[1,1,1],'box'],[101,[1,1,1],'box'],[20,[60,30,20],'box'],[5,[10,10,10],'crate'],[5,[10,10],'box']])assert.throws(()=>c(...bad));
});
test('$108 fee in tariff agrees with the existing heavyBagFee rule',()=>{
 for(const [w,d] of [[40,[28,19,11]],[71,[20,15,10]],[30,[40,20,15]],[70,[30,20,12]]])assert.equal(groundPackagePrice({weight:w,dimensions:d,packaging:'box'}).feeCents,heavyBagFee({weight:w,dimensions:d}));
});
test('only contiguous USA ZIPs are priced online',()=>{
 for(const z of ['02108','98101','10001','60601','33101','90210'])assert.equal(contiguousUsZip(z),true,z);
 for(const z of ['99501','96813','00901','00801','96910','09012','34001','96201','1234','abcde',''])assert.equal(contiguousUsZip(z),false,z);
});
const shipment=(over={})=>({from:{country:'United States',postal:'02108'},to:{country:'United States',postal:'98101'},packages:[{weight:40,length:28,width:19,height:11,packaging:'luggage'},{weight:75,length:30,width:20,height:12,packaging:'luggage'}],...over});
test('multi-package Ground quote totals and limits',()=>{
 const q=groundQuote(shipment());
 assert.equal(q.priceCents,6699+3960+9199);assert.equal(q.feeCents,10800);assert.equal(q.totalCents,30658);
 assert.throws(()=>groundQuote(shipment({to:{country:'Canada',postal:'98101'}})),/quote/);
 assert.throws(()=>groundQuote(shipment({to:{country:'United States',postal:'99501'}})),/Alaska/);
 assert.throws(()=>groundQuote(shipment({packages:Array(6).fill({weight:5,length:10,width:10,height:10,packaging:'box'})})),/1 to 5/);
});
test('small parcel path is unchanged',()=>{
 assert.equal(smallParcelEligible({from:{country:'United States'},to:{country:'United States'},package:{weight:0.8,length:8,width:6,height:2}}),true);
 assert.equal(smallParcelEligible({from:{country:'United States'},to:{country:'United States'},package:{weight:1.5,length:8,width:6,height:2}}),false);
});
test('operations notice lists every package of a multi-package order',()=>{
 const src=stripTypeScriptTypes(readFileSync(new URL('../supabase/functions/live-order-notification-job/index.ts',import.meta.url),'utf8').replace(/^import .*;$/m,'')).replace(/Deno\.serve[\s\S]*$/,'return liveNotice;');
 const liveNotice=new Function('Deno',src)({});
 const m=liveNotice({order_id:'33333333-3333-4333-8333-333333333333',order_state:'paid',customer_email:'b@example.test',total_cents:30658,regular_cents:30658,payment_id:'pi_x',paid_at:'2026-10-15T15:00:00Z',summary:'Ground delivery · 2 packages',pricing_source:'flat_ground_v1',shipment:{service:'ground',packages:[{weight:40,length:28,width:19,height:11,packaging:'luggage'},{weight:75,length:30,width:20,height:12,packaging:'box'}]}});
 assert.match(m.text,/PACKAGES \(2\):\n  1\. 40 lb, 28 x 19 x 11 in, suitcase \/ unboxed\n  2\. 75 lb, 30 x 20 x 12 in, box/);
 assert.match(m.text,/USD 306\.58/);
});
