begin;
do $$
declare u uuid; q uuid:=gen_random_uuid(); o public.live_manual_orders; blocked boolean;
begin
 select id into u from auth.users where email_confirmed_at is not null and deleted_at is null limit 1;
 if u is null then raise exception 'Verified test identity required'; end if;
 if has_table_privilege('authenticated','public.live_manual_orders','SELECT')
 or has_table_privilege('anon','public.live_manual_quotes','SELECT')
 or has_function_privilege('authenticated','public.confirm_live_manual_payment(uuid,text,text,bigint)','EXECUTE')
 then raise exception 'Private access leaked'; end if;
 insert into public.live_manual_quotes(id,user_id,summary,retail_cents,postage_cents,evidence,shipment,expires_at,approved_by,fulfillment_ready)
 values(q,u,'ROLLBACK ONLY: checkout safeguard test',10000,3000,'Synthetic test, never a payable shipment','{}',now()+interval '1 hour',u,true);
 o:=public.reserve_live_manual_checkout(u,q,'');
 if o.total_cents<>4500 then raise exception 'Wrong price'; end if;
 o:=public.reserve_live_manual_checkout(u,q,'');
 if (select count(*) from public.live_manual_orders where id=q)<>1 then raise exception 'Duplicate order'; end if;
 blocked:=false;
 begin update public.live_manual_quotes set retail_cents=1 where id=q;
 exception when others then blocked:=true; end;
 if not blocked then raise exception 'Reserved quote mutable'; end if;
 blocked:=false;
 begin perform public.bind_live_manual_checkout(q,'cs_test_fixture',4500);
 exception when others then blocked:=true; end;
 if not blocked then raise exception 'Test session accepted'; end if;
 perform public.bind_live_manual_checkout(q,'cs_live_rollback_fixture',4500);
 blocked:=false;
 begin perform public.confirm_live_manual_payment(q,'cs_live_rollback_fixture','pi_rollback_fixture',1);
 exception when others then blocked:=true; end;
 if not blocked then raise exception 'Wrong amount accepted'; end if;
 perform public.confirm_live_manual_payment(q,'cs_live_rollback_fixture','pi_rollback_fixture',4500);
 perform public.confirm_live_manual_payment(q,'cs_live_rollback_fixture','pi_rollback_fixture',4500);
 if (select state from public.live_manual_orders where id=q)<>'paid' then raise exception 'Confirmation failed'; end if;
end $$;
rollback;
