import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';
const source=stripTypeScriptTypes(readFileSync(new URL('../supabase/functions/test-payment-email-job/index.ts',import.meta.url),'utf8').replace(/^import .*;$/m,''));
const id='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
function fixture(rows=[{email_id:id,claim_token:id,order_id:id,recipient:'operations@ziplogg.com',total_cents:4500}]){let handler;const calls=[];new Function('Deno','createClient',source)({env:{get:()=> 'test-secret'},serve:fn=>handler=fn},()=>({rpc:async(name,args)=>{calls.push({name,args});return {data:rows};}}));return {calls,run:(body,secret='test-secret')=>handler(new Request('https://example.test',{method:'POST',headers:{'x-ziplogg-worker':secret},body:JSON.stringify(body)}))};}
test('email job rejects unauthorized callers before database',async()=>{const f=fixture();assert.equal((await f.run({action:'claim',job_id:id},'wrong')).status,401);assert.equal(f.calls.length,0);});
test('claim uses trusted recipient and clear sandbox wording',async()=>{const f=fixture();const body=await (await f.run({action:'claim',job_id:id,to:'attacker@example.test',total_cents:1})).json();assert.equal(body.to,'operations@ziplogg.com');assert.match(body.text,/USD 45.00/);assert.match(body.text,/no postage has been purchased/i);assert.equal(body.send,true);});
test('already claimed email cannot be sent again',async()=>{const f=fixture([]);assert.deepEqual(await (await f.run({action:'claim',job_id:id})).json(),{test_only:true,send:false});});
test('unexpected recipient fails closed',async()=>{const f=fixture([{email_id:id,claim_token:id,order_id:id,recipient:'outside@example.test',total_cents:4500}]);assert.equal((await f.run({action:'claim',job_id:id})).status,503);});
test('confirmation requires claim token and provider evidence',async()=>{const f=fixture();assert.equal((await f.run({action:'confirm',email_id:id,claim_token:id,provider_reference:''})).status,400);assert.equal(f.calls.length,0);assert.equal((await f.run({action:'confirm',email_id:id,claim_token:id,provider_reference:'provider-message-id'})).status,200);assert.equal(f.calls[0].name,'confirm_test_payment_email');});
