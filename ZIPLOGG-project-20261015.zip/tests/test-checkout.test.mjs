import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';
const source=stripTypeScriptTypes(readFileSync(new URL('../supabase/functions/prepare-test-checkout/index.ts',import.meta.url),'utf8').replace(/^import .*;$/m,''));
function fixture(changes={}){
 const state={env:{ZIPLOGG_MAKE_TEST_SECRET:'private-fixture',ZIPLOGG_STRIPE_TEST_KEY:'rk_test_fixture',ZIPLOGG_SHIPPO_TEST_KEY:'shippo_test_fixture'},accounts:[{active:true,carrier:'fedex',object_id:'carrier_fixture'}],rates:[{provider:'FedEx',currency:'USD',amount:'18.00',object_id:'rate_fixture',servicelevel:{token:'fedex_ground'}}],test:true,calls:[],...changes};let handler;
 new Function('Deno','createClient','fetch',source)({env:{get:n=>state.env[n]},serve:fn=>handler=fn},()=>{throw new Error('Probe must not touch checkout or user data')},async(url,options)=>{state.calls.push({url,options});return new Response(JSON.stringify(url.includes('carrier_accounts')?{results:state.accounts}:{test:state.test,rates:state.rates,messages:[]}),{status:200})});
 return {state,run:(header='private-fixture',body={request_id:'de93bfa4-3e67-41b4-9a21-44e6a4e38498',probe_only:true})=>handler(new Request('https://example.test',{method:'POST',headers:{'x-ziplogg-worker':header},body:JSON.stringify(body)}))};
}
test('test shipment probe rejects unauthorized requests before providers',async()=>{const f=fixture();assert.equal((await f.run('bad')).status,401);assert.equal(f.state.calls.length,0)});
test('test shipment probe refuses live Shippo credentials',async()=>{const f=fixture();f.state.env.ZIPLOGG_SHIPPO_TEST_KEY='shippo_live_fixture';assert.equal((await f.run()).status,503);assert.equal(f.state.calls.length,0)});
test('missing FedEx account stops without falling back to another carrier',async()=>{const f=fixture({accounts:[{active:true,carrier:'ups'}]});const r=await f.run();assert.equal(r.status,409);assert.match((await r.json()).error,/FedEx/);assert.equal(f.state.calls.length,1)});
test('valid FedEx probe obtains rates without creating payment or label',async()=>{const f=fixture();const r=await f.run();assert.equal(r.status,200);assert.equal((await r.json()).fedex_ready,true);assert.equal(f.state.calls.length,2);assert.ok(f.state.calls.every(c=>!c.url.includes('transactions')&&!c.url.includes('stripe')))});
test('live shipment or no FedEx USD rate stops checkout',async()=>{for(const change of [{test:false},{rates:[{provider:'UPS',currency:'USD',amount:'10'}]},{rates:[{provider:'FedEx',currency:'EUR',amount:'10'}]}]){assert.equal((await fixture(change).run()).status,409)}});
