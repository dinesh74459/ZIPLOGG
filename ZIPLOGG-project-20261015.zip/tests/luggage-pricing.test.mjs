import test from 'node:test';
import assert from 'node:assert/strict';
import {luggageEstimate,packageEstimate,heavyBagFee} from '../dist/luggage-pricing.js';
test('weights never fabricate rates',()=>{
 const q=luggageEstimate([20,30,60]);assert.equal(q.requiresCarrierQuote,true);assert.equal(q.first,undefined);assert.equal(q.returning,undefined);
});
test('reject invalid package weights',()=>{for(const w of [[],[0],[101],[NaN],['20'],Array(11).fill(1)])assert.throws(()=>luggageEstimate(w));});
test('dimension weight wins for light bulky luggage',()=>{
 const p=packageEstimate({weight:20,dimensions:[24,16,10]});
 assert.equal(p.dimensionalWeight,28);assert.equal(p.billableWeight,28);assert.equal(p.requiresCarrierQuote,true);
});
test('round each fractional dimension and actual pound up',()=>{
 const p=packageEstimate({weight:49.01,dimensions:[10.01,10,10]});
 assert.deepEqual(p.roundedDimensions,[11,10,10]);assert.equal(p.dimensionalWeight,8);assert.equal(p.billableWeight,50);
});
test('size handling minimum and oversize threshold are strict',()=>{
 assert.equal(packageEstimate({weight:1,dimensions:[48,2,2]}).billableWeight,2);
 assert.equal(packageEstimate({weight:1,dimensions:[48.1,2,2]}).billableWeight,40);
 assert.equal(packageEstimate({weight:1,dimensions:[96.1,2,2]}).billableWeight,90);
});
test('dimensions are independent of orientation; bad or missing dimensions fail',()=>{
 assert.equal(packageEstimate({weight:20,dimensions:[10,24,16]}).billableWeight,28);
 for(const dimensions of [[],[1,2],[1,0,3],[1,NaN,3],[121,1,1],['24',16,10]])assert.throws(()=>packageEstimate({weight:20,dimensions}));
});

test('ZIPLOGG heavy fee uses strict thresholds and charges only once',()=>{
 assert.equal(heavyBagFee({weight:70,dimensions:[35,20,15]}),0);
 assert.equal(heavyBagFee({weight:70.01,dimensions:[35,20,15]}),10800);
 assert.equal(heavyBagFee({weight:20,dimensions:[36,20,15]}),10800);
 assert.equal(heavyBagFee({weight:100,dimensions:[36,20,15]}),10800);
 assert.equal(heavyBagFee({weight:20,dimensions:[15,36,20]}),10800);
 assert.throws(()=>heavyBagFee({weight:101,dimensions:[36,20,15]}));
});
