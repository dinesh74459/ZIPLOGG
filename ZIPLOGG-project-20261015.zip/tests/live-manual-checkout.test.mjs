import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {stripTypeScriptTypes} from 'node:module';
import {createHmac} from 'node:crypto';
const source=stripTypeScriptTypes(readFileSync(new URL('../supabase/functions/live-manual-checkout/index.ts',import.meta.url),'utf8').replace(/^import .*;$/m,''));
const id='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
function fixture({enabled='true',key='rk_live_fixture',verified=true,eligible=true,live=true,amount=4500}={}){
 let handler;const calls=[];
 const db={auth:{getUser:async()=>({data:{user:verified?{id:'owner',email_confirmed_at:'2026-10-14'}:null}})},rpc:async(name,args)=>{calls.push({name,args});return name==='reserve_live_manual_checkout'?(eligible?{data:{id,email:'test@example.test',total_cents:4500,created_at:new Date().toISOString()}}:{error:{}}):{};},from:()=>({select:()=>({eq:()=>({single:async()=>({data:{expires_at:new Date(Date.now()+3600000).toISOString(),summary:'Shipment'}})})})})};
 new Function('Deno','createClient','fetch',source)({env:{get:n=>n==='ZIPLOGG_LIVE_MANUAL_ENABLED'?enabled:n==='ZIPLOGG_STRIPE_LIVE_KEY'?key:'fixture'},serve:fn=>handler=fn},()=>db,async(url,opts)=>{calls.push({url,params:opts.body});return new Response(JSON.stringify({id:'cs_live_fixture',livemode:live,client_reference_id:id,amount_total:amount,currency:'usd',status:'open',url:'https://checkout.stripe.com/c/pay/cs_live_fixture'}));});
 return {calls,run:(body={},headers={})=>handler(new Request('https://example.test',{method:'POST',headers:{authorization:'Bearer fixture',...headers},body:JSON.stringify({action:'create',quote_id:id,accepted:true,terms_version:'manual-shipping-v1',total_cents:1,user_id:'attacker',...body})}))};
}
test('live switch and live key required before provider access',async()=>{for(const o of [{enabled:'false'},{key:'rk_test_fixture'}]){const f=fixture(o);assert.equal((await f.run()).status,503);assert.equal(f.calls.length,0);}});
test('unverified identity, missing consent and invalid quote cannot charge',async()=>{for(const [opts,input] of [[{verified:false},{}],[{}, {accepted:false}],[{}, {quote_id:'bad'}]]){const f=fixture(opts);assert.ok((await f.run(input)).status>=400);assert.equal(f.calls.length,0);}});
test('trusted reservation fixes customer and amount; checkout does not save card',async()=>{const f=fixture();assert.equal((await f.run()).status,200);assert.equal(f.calls[0].args.p_user,'owner');assert.equal(f.calls[1].params.get('line_items[0][price_data][unit_amount]'),'4500');assert.equal(f.calls[1].params.get('payment_intent_data[setup_future_usage]'),null);assert.equal(f.calls[2].name,'bind_live_manual_checkout');});
test('ineligible quote never calls Stripe',async()=>{const f=fixture({eligible:false});assert.equal((await f.run()).status,409);assert.equal(f.calls.length,1);});
test('sandbox responses and wrong amount cannot bind live order',async()=>{for(const o of [{live:false},{amount:1}]){const f=fixture(o);assert.equal((await f.run()).status,503);assert.equal(f.calls.length,2);}});
test('forged webhook and cross-origin requests fail',async()=>{const f=fixture();assert.equal((await f.run({}, {'stripe-signature':'t=1,v1=bad'})).status,400);assert.equal((await f.run({}, {origin:'https://evil.test'})).status,403);assert.equal(f.calls.length,0);});

test('signed events verify provider payment once; duplicates do not reconfirm',async()=>{
 let handler, confirmations=0, fetches=0;
 const order={id,session_id:'cs_live_fixture',total_cents:4500,state:'awaiting_payment'};
 const db={from:()=>({select:()=>({eq:()=>({maybeSingle:async()=>({data:order})})})}),rpc:async(name)=>{assert.equal(name,'confirm_live_manual_payment');confirmations++;order.state='paid';return {};}};
 new Function('Deno','createClient','fetch',source)({env:{get:n=>n==='ZIPLOGG_LIVE_MANUAL_ENABLED'?'true':n==='ZIPLOGG_STRIPE_LIVE_KEY'?'rk_live_fixture':'fixture'},serve:fn=>handler=fn},()=>db,async url=>{fetches++;return new Response(JSON.stringify(url.includes('payment_intents/')?{id:'pi_fixture',livemode:true,status:'succeeded',currency:'usd',amount:4500,amount_received:4500}:{id:'cs_live_fixture',livemode:true,client_reference_id:id,metadata:{ziplogg_flow:'manual-v1'},amount_total:4500,currency:'usd',mode:'payment',payment_status:'paid',payment_intent:'pi_fixture'}));});
 const raw=JSON.stringify({livemode:true,type:'checkout.session.completed',data:{object:{id:'cs_live_fixture',metadata:{ziplogg_flow:'manual-v1'}}}});
 const t=String(Math.floor(Date.now()/1000)),sig=createHmac('sha256','fixture').update(t+'.'+raw).digest('hex');
 const run=()=>handler(new Request('https://example.test',{method:'POST',headers:{'stripe-signature':`t=${t},v1=${sig}`},body:raw}));
 assert.equal((await run()).status,200);assert.equal((await run()).status,200);
 assert.equal(confirmations,1);assert.equal(fetches,2);
});
