begin;
do $$
declare j uuid; o uuid; e record; n integer;
begin
 select f.id,c.id into j,o from public.fulfillment_jobs f join public.checkout_orders c on c.id=f.order_id
 where c.id='f8b39bc7-0bc4-42ff-825b-ab2cf35eafb9' and c.live_mode=false;
 if j is null then raise exception 'Known verified test fixture missing'; end if;
 insert into public.test_payment_emails(order_id,job_id) values(o,j);
 select * into e from public.claim_test_payment_email(j);
 if e.email_id is null or e.recipient<>'operations@ziplogg.com' then raise exception 'Claim failed'; end if;
 select count(*) into n from public.claim_test_payment_email(j);
 if n<>0 then raise exception 'Duplicate claim allowed'; end if;
 begin
  perform public.confirm_test_payment_email(e.email_id,gen_random_uuid(),'wrong claim');
  raise exception 'Wrong token accepted';
 exception when others then if sqlerrm='Wrong token accepted' then raise; end if; end;
 perform public.confirm_test_payment_email(e.email_id,e.claim_token,'TEST-ROLLBACK-NOT-SENT');
 perform public.confirm_test_payment_email(e.email_id,e.claim_token,'TEST-ROLLBACK-NOT-SENT');
 if not exists(select 1 from public.test_payment_emails where id=e.email_id and state='sent') then raise exception 'Confirmation failed'; end if;
 if has_table_privilege('authenticated','public.test_payment_emails','SELECT') or has_function_privilege('authenticated','public.claim_test_payment_email(uuid)','EXECUTE') then raise exception 'Customer access exposed'; end if;
end $$;
rollback;
