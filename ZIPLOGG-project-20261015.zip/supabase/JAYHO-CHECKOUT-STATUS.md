# JAYHO test checkout integration

Deployed 2026-10-13: migrations 004/005/006 and customer-test-checkout.

Authenticated POST accepts order_id (stable UUID), quote_id, promo_code. Identity comes from Supabase getUser; client price and eligibility flags are ignored. Only service-role code may create retail_quotes. Never populate fedex_retail_cents from Shippo wholesale postage. Require matched route, parcel dimensions, service, surcharges and retail evidence.

The SQL reservation is created before Stripe; retries use the same order and Stripe idempotency key. The existing verify-payment-job -> enqueue_paid_order flow consumes JAYHO inside the fulfillment-job transaction. Database fixtures verified totals, retries, duplicate reservation rejection, consumption and repeat redemption rejection; all rolled back.

No public checkout button wired yet: no trusted live retail quote ingestion. Test-only function rejects live keys and live quotes. The legacy JWT gateway check is off because the handler validates the customer's JWT with Supabase getUser itself.

Reservations deliberately do not expire on browser cancellation or timeout. Authenticated action=cancel now retrieves Stripe, expires open/unpaid sessions, retrieves again, and releases only confirmed expired/unpaid matches. Database tests cover release/reuse, idempotence and rejection of paid releases. Pending session-creation ambiguity remains reserved; retry original creation within 23 hours, then manual reconciliation is required to avoid Stripe idempotency-key expiry. No live endpoint, label purchasing or automatic email dispatch has been enabled by this change. Full Stripe event journey remains unverified against an actual session.
