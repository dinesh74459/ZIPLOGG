-- Tests use the verified sandbox QA quote; all changes are rolled back.
begin;
do $$
declare oid uuid; did uuid; again uuid; n integer; before_status text;
begin
 select id,status into oid,before_status from public.checkout_orders
 where retail_quote_id='c9e16ff0-c7d1-4f0b-a081-3edb6c5fe536' and live_mode=false;
 if oid is null then raise exception 'Verified sandbox fixture missing'; end if;
 did := public.prepare_manual_delivery(oid,repeat('a',64),true,'SAMPLE-NO-CARRIER');
 again := public.prepare_manual_delivery(oid,repeat('a',64),true,'SAMPLE-NO-CARRIER');
 if did<>again then raise exception 'Duplicate preparation created another delivery'; end if;
 begin
  perform public.prepare_manual_delivery(oid,repeat('b',64),true,'SAMPLE-NO-CARRIER');
  raise exception 'TEST_FAILED: changed attachment accepted';
 exception when others then if SQLERRM like 'TEST_FAILED:%' then raise; end if; end;
 begin
  perform public.prepare_manual_delivery(oid,repeat('a',64),false,'FedEx','123','test');
  raise exception 'TEST_FAILED: test order accepted real label';
 exception when others then if SQLERRM like 'TEST_FAILED:%' then raise; end if; end;
 select count(*) into n from public.claim_manual_delivery(did);
 if n<>1 then raise exception 'First claim failed'; end if;
 select count(*) into n from public.claim_manual_delivery(did);
 if n<>0 then raise exception 'Duplicate send allowed'; end if;
 perform public.confirm_manual_delivery(did,'TEST-EMAIL-RECEIPT');
 perform public.confirm_manual_delivery(did,'TEST-EMAIL-RECEIPT');
 if (select status from public.checkout_orders where id=oid)<>before_status then raise exception 'Sample changed fulfillment status'; end if;
 if has_table_privilege('authenticated','public.manual_deliveries','SELECT') then raise exception 'Customer can read dispatch records'; end if;
 if has_function_privilege('authenticated','public.prepare_manual_delivery(uuid,text,boolean,text,text,text)','EXECUTE') then raise exception 'Customer can prepare labels'; end if;
end $$;
rollback;
