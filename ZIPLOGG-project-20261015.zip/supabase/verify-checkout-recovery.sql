begin;
do $$
declare u uuid:=gen_random_uuid(); f uuid:=gen_random_uuid(); c uuid:=gen_random_uuid(); q uuid:=gen_random_uuid(); q2 uuid:=gen_random_uuid(); oid uuid:=gen_random_uuid(); o public.checkout_orders; j uuid;
begin
 insert into auth.users(id,email,email_confirmed_at,raw_user_meta_data) values(u,u::text||'@example.invalid',now(),'{}');
 insert into public.referral_codes(user_id,code) values(u,c);
 insert into auth.users(id,email,email_confirmed_at,raw_user_meta_data) values(f,f::text||'@example.invalid',now(),jsonb_build_object('ziplogg_referral',c));
 insert into public.retail_quotes(id,user_id,fedex_retail_cents,pricing_policy,shippo_shipment_id,shippo_rate_id,evidence,expires_at)
 values(q,u,10000,'fedex_45_v2','test_shipment','test_rate','{"test_fixture":true}',now()+interval '10 minutes'),(q2,u,10000,'fedex_45_v2','test_shipment2','test_rate2','{"test_fixture":true}',now()+interval '10 minutes');
 o:=public.reserve_test_checkout(oid,u,q,'JAYHO');
 if o.total_cents<>3600 then raise exception 'Wrong discount total'; end if;
 o:=public.reserve_test_checkout(oid,u,q,'JAYHO');
 if o.id<>oid then raise exception 'Retry not idempotent'; end if;
 begin
  perform public.reserve_test_checkout(gen_random_uuid(),u,q2,'JAYHO');
  raise exception using errcode='ZX001',message='Duplicate reservation allowed';
 exception when sqlstate 'P0001' then null; end;
 perform public.bind_test_checkout(oid,'cs_test_'||oid::text,3600);
 if not public.release_expired_test_checkout(oid,u,'cs_test_'||oid::text) then raise exception 'Release failed'; end if;
 if exists(select 1 from public.promo_reservations where order_id=oid) then raise exception 'Reservation not released'; end if;
 perform public.release_expired_test_checkout(oid,u,'cs_test_'||oid::text);
 oid:=gen_random_uuid();
 o:=public.reserve_test_checkout(oid,u,q2,'JAYHO');
 perform public.bind_test_checkout(oid,'cs_test_'||oid::text,3600);
 j:=public.enqueue_paid_order(oid,'cs_test_'||oid::text,'pi_'||oid::text,'evt_'||oid::text,3600,'usd',false);
 begin
 perform public.release_expired_test_checkout(oid,u,'cs_test_'||oid::text);
 raise exception using errcode='ZX001',message='Paid reservation released';
 exception when sqlstate 'P0001' then null; end;
 if (select state from public.promo_reservations where order_id=oid)<>'consumed' then raise exception 'Promo not consumed'; end if;
 if public.enqueue_paid_order(oid,'cs_test_'||oid::text,'pi_'||oid::text,'evt_'||oid::text,3600,'usd',false)<>j then raise exception 'Duplicate payment not idempotent'; end if;
 begin
  perform public.reserve_test_checkout(gen_random_uuid(),u,q2,'JAYHO');
  raise exception using errcode='ZX001',message='Second redemption allowed';
 exception when sqlstate 'P0001' then null; end;
 if has_function_privilege('authenticated','public.reserve_test_checkout(uuid,uuid,uuid,text)','EXECUTE') then raise exception 'Public reservation access'; end if;
end $$;
rollback;
