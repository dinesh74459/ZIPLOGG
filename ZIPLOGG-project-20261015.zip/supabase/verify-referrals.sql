-- Synthetic database fixtures only. No messages are sent; always rolls back.
begin;
do $$
declare owner_id uuid:=gen_random_uuid(); friend_id uuid:=gen_random_uuid(); token uuid:=gen_random_uuid(); s uuid;
begin
 insert into auth.users(id,email,email_confirmed_at,raw_user_meta_data)
 values(owner_id,owner_id::text||'@example.invalid',now(),'{}');
 insert into public.referral_codes(user_id,code) values(owner_id,token);
 if public.jayho_eligible(owner_id) then raise exception 'Unreferred owner eligible'; end if;
 insert into auth.users(id,email,raw_user_meta_data)
 values(friend_id,friend_id::text||'@example.invalid',jsonb_build_object('ziplogg_referral',token));
 if public.jayho_eligible(owner_id) then raise exception 'Unverified friend counted'; end if;
 update auth.users set email_confirmed_at=now() where id=friend_id;
 if not public.jayho_eligible(owner_id) then raise exception 'Verified friend not counted'; end if;
 update auth.users set raw_user_meta_data='{}' where id=friend_id;
 if not exists(select 1 from public.referrals where referred_user_id=friend_id and referrer_user_id=owner_id) then raise exception 'Attribution changed'; end if;
 perform set_config('request.jwt.claim.sub',owner_id::text,true);
 if (public.my_referral_status()->>'verifiedFriends')::int<>1 then raise exception 'Wrong private count'; end if;
 insert into public.shipments(user_id,reference,kind,origin,destination)
 values(owner_id,gen_random_uuid()::text,'personal','{}','{}') returning id into s;
 insert into public.fulfillment_records(shipment_id,stripe_payment_id,paid_amount_cents,payment_verified_at)
 values(s,gen_random_uuid()::text,1000,now());
 if public.jayho_eligible(owner_id) then raise exception 'Returning customer eligible'; end if;
 if has_table_privilege('authenticated','public.referrals','SELECT') then raise exception 'Customer can read friends'; end if;
 if has_function_privilege('authenticated','public.jayho_eligible(uuid)','EXECUTE') then raise exception 'Customer can query another user'; end if;
end $$;
rollback;
