-- Synthetic fixtures, no credentials or provider calls; every change rolls back.
begin;
do $$
declare u uuid:=gen_random_uuid(); q uuid:=gen_random_uuid(); oid uuid:=gen_random_uuid();
begin
 insert into auth.users(id,email,email_confirmed_at,raw_user_meta_data)
 values(u,u::text||'@example.invalid',now(),'{}');
 insert into public.retail_quotes(id,user_id,fedex_retail_cents,pricing_policy,shippo_shipment_id,shippo_rate_id,evidence,expires_at)
 values(q,u,10000,'fedex_45_v2','test_expired_shipment','test_expired_rate','{"test_fixture":true}',now()-interval '1 minute');
 begin
  perform public.reserve_test_checkout(oid,u,q,'');
  raise exception using errcode='ZX001',message='Expired quote created an order';
 exception when sqlstate 'P0001' then
  if sqlerrm not like '%Valid server-side test retail quote required%' then raise; end if;
 end;
 if exists(select 1 from public.checkout_orders where id=oid) then raise exception 'Expired quote left an order'; end if;
 if exists(select 1 from public.fulfillment_jobs where order_id=oid) then raise exception 'Expired quote queued fulfillment'; end if;
 if exists(select 1 from public.promo_reservations where order_id=oid) then raise exception 'Expired quote reserved a promotion'; end if;
end $$;
rollback;
