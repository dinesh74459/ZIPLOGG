-- Isolated referral checks. Every synthetic row is rolled back; no login or email.
begin;
do $$
declare u uuid:=gen_random_uuid(); f uuid:=gen_random_uuid(); other_u uuid:=gen_random_uuid(); c uuid:=gen_random_uuid(); c2 uuid:=gen_random_uuid(); q uuid:=gen_random_uuid(); o public.checkout_orders;
begin
 insert into auth.users(id,email,email_confirmed_at,raw_user_meta_data) values(u,u::text||'@example.invalid',now(),'{}'),(other_u,other_u::text||'@example.invalid',now(),'{}');
 insert into public.referral_codes(user_id,code) values(u,c),(other_u,c2);
 insert into public.retail_quotes(id,user_id,fedex_retail_cents,pricing_policy,shippo_shipment_id,shippo_rate_id,evidence,expires_at) values(q,u,10000,'fedex_45_v2','test_only','test_only','{"test_fixture":true}',now()+interval '10 minutes');
 if public.jayho_eligible(u) then raise exception 'No referral incorrectly eligible'; end if;
 begin
  perform public.reserve_test_checkout(gen_random_uuid(),u,q,'JAYHO');
  raise exception using errcode='ZX001',message='No-referral discount accepted';
 exception when sqlstate 'P0001' then null; end;
 insert into auth.users(id,email,raw_user_meta_data) values(f,f::text||'@example.invalid',jsonb_build_object('ziplogg_referral',c));
 if public.jayho_eligible(u) then raise exception 'Unverified friend incorrectly eligible'; end if;
 update auth.users set email_confirmed_at=now() where id=f;
 if not public.jayho_eligible(u) then raise exception 'Verified friend not eligible'; end if;
 update auth.users set raw_user_meta_data=jsonb_build_object('ziplogg_referral',c2) where id=f;
 if not exists(select 1 from public.referrals where referred_user_id=f and referrer_user_id=u) or public.jayho_eligible(other_u) then raise exception 'Referral attribution changed'; end if;
 begin
  insert into public.referrals(referred_user_id,referrer_user_id) values(u,u);
  raise exception using errcode='ZX001',message='Self-referral accepted';
 exception when check_violation then null; end;
 update auth.users set deleted_at=now() where id=f;
 if public.jayho_eligible(u) then raise exception 'Deleted friend eligible'; end if;
 update auth.users set deleted_at=null where id=f;
 o:=public.reserve_test_checkout(gen_random_uuid(),u,q,' jayho ');
 if o.total_cents<>3600 or o.promo_code<>'JAYHO' then raise exception 'Discount or normalized code incorrect'; end if;
 if has_table_privilege('authenticated','public.referrals','SELECT') then raise exception 'Referral details publicly readable'; end if;
end $$;
rollback;
