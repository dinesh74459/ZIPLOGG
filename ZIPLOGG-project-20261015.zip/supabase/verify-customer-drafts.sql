-- Run in Supabase SQL Editor. Every fixture and mutation is rolled back.
begin;
insert into auth.users(id,email) values ('10000000-0000-4000-8000-000000000001','ziplogg-test-a@example.invalid'),('10000000-0000-4000-8000-000000000002','ziplogg-test-b@example.invalid');
set local role authenticated;
select set_config('request.jwt.claim.sub','10000000-0000-4000-8000-000000000001',true);
insert into public.shipment_drafts(kind,title,details) values ('personal','Test A','{"notes":"private"}');
do $$ begin if (select count(*) from public.shipment_drafts) <> 1 then raise exception 'own read failed'; end if; end $$;
update public.shipment_drafts set title='Updated A';
select set_config('request.jwt.claim.sub','10000000-0000-4000-8000-000000000002',true);
do $$ declare n integer; begin
if (select count(*) from public.shipment_drafts) <> 0 then raise exception 'cross user read leaked'; end if;
update public.shipment_drafts set title='Intrusion'; get diagnostics n=row_count; if n<>0 then raise exception 'cross user update'; end if;
delete from public.shipment_drafts; get diagnostics n=row_count; if n<>0 then raise exception 'cross user delete'; end if;
begin insert into public.shipment_drafts(user_id,kind,title,details) values('10000000-0000-4000-8000-000000000001','business','Forged','{}'); raise exception 'owner spoof allowed'; exception when insufficient_privilege then null; end;
end $$;
insert into public.shipment_drafts(kind,title,details) values ('business','Test B','{}');
delete from public.shipment_drafts;
do $$ begin if exists(select 1 from public.shipment_drafts) then raise exception 'own delete failed'; end if; end $$;
reset role; set local role anon;
do $$ begin
begin perform * from public.shipment_drafts; raise exception 'anonymous read allowed'; exception when insufficient_privilege then null; end;
begin insert into public.shipment_drafts(kind,title,details) values('personal','Anon','{}'); raise exception 'anonymous write allowed'; exception when insufficient_privilege then null; end;
end $$;
reset role;
select 'PASS: own CRUD, cross-user isolation, owner spoof denied, anonymous access denied; test data rolled back' as test_result;
rollback;
