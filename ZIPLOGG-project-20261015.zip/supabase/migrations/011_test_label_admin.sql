-- Staff-only sample-label workspace. No live orders or public file access.
begin;
create table public.test_label_operators (
 user_id uuid primary key references auth.users(id),
 enabled boolean not null default true,
 created_at timestamptz not null default now()
);
alter table public.test_label_operators enable row level security;
revoke all on public.test_label_operators from public,anon,authenticated;
grant select on public.test_label_operators to service_role;
alter table public.manual_deliveries add column storage_path text;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('ziplogg-test-labels','ziplogg-test-labels',false,2097152,array['application/pdf']);
-- Block browser roles even if a broader permissive policy exists elsewhere.
create policy ziplogg_test_labels_server_only on storage.objects as restrictive
for all to anon,authenticated
using (bucket_id <> 'ziplogg-test-labels')
with check (bucket_id <> 'ziplogg-test-labels');
-- Deliberately no operators seeded. Owner approval is required for access.
commit;
