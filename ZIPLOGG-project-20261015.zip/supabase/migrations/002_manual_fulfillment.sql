-- Manual fulfillment: customers can read their orders; only trusted admins
-- using the Supabase dashboard/server can write financial or delivery records.
begin;
create table public.shipping_profiles (
 user_id uuid primary key default auth.uid() references auth.users(id) on delete cascade,
 full_name text not null check (char_length(btrim(full_name)) between 1 and 120),
 phone text check (char_length(phone) <= 40),
 created_at timestamptz not null default now()
);
create table public.shipments (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id),
 reference text not null unique check (char_length(reference) between 1 and 80),
 kind text not null check (kind in ('personal','business')),
 origin jsonb not null check (jsonb_typeof(origin) = 'object' and octet_length(origin::text) <= 8192),
 destination jsonb not null check (jsonb_typeof(destination) = 'object' and octet_length(destination::text) <= 8192),
 status text not null default 'awaiting_quote' check (status in ('awaiting_quote','awaiting_payment','payment_verified','label_purchased','label_sent','in_transit','delivered','cancelled')),
 currency text not null default 'USD' check (currency ~ '^[A-Z]{3}$'),
 quoted_total_cents bigint check (quoted_total_cents >= 0),
 created_at timestamptz not null default now()
);
create index shipments_owner_created on public.shipments(user_id,created_at desc);
create table public.shipment_bags (
 id uuid primary key default gen_random_uuid(),
 shipment_id uuid not null references public.shipments(id),
 description text not null check (char_length(btrim(description)) between 1 and 200),
 weight_lb numeric(10,2) not null check (weight_lb > 0),
 length_in numeric(10,2) not null check (length_in > 0),
 width_in numeric(10,2) not null check (width_in > 0),
 height_in numeric(10,2) not null check (height_in > 0)
);
create index shipment_bags_parent on public.shipment_bags(shipment_id);
create table public.shipment_events (
 id uuid primary key default gen_random_uuid(),
 shipment_id uuid not null references public.shipments(id),
 message text not null check (char_length(btrim(message)) between 1 and 1000),
 occurred_at timestamptz not null default now()
);
create index shipment_events_parent on public.shipment_events(shipment_id,occurred_at);
-- No customer API access to payment/provider references or internal notes.
create table public.fulfillment_records (
 shipment_id uuid primary key references public.shipments(id),
 stripe_payment_id text unique,
 paid_amount_cents bigint check (paid_amount_cents >= 0),
 payment_verified_at timestamptz,
 provider_label_id text,
 carrier_tracking_number text,
 label_sent_at timestamptz,
 internal_notes text,
 check (payment_verified_at is null or (stripe_payment_id is not null and paid_amount_cents is not null))
);
alter table public.shipping_profiles enable row level security;
alter table public.shipments enable row level security;
alter table public.shipment_bags enable row level security;
alter table public.shipment_events enable row level security;
alter table public.fulfillment_records enable row level security;
revoke all on public.shipping_profiles, public.shipments, public.shipment_bags, public.shipment_events, public.fulfillment_records from public, anon, authenticated;
grant select on public.shipping_profiles, public.shipments, public.shipment_bags, public.shipment_events to authenticated;
grant insert (full_name,phone), update (full_name,phone) on public.shipping_profiles to authenticated;
create policy profile_read on public.shipping_profiles for select to authenticated using ((select auth.uid()) = user_id);
create policy profile_insert on public.shipping_profiles for insert to authenticated with check ((select auth.uid()) = user_id);
create policy profile_update on public.shipping_profiles for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy shipment_read on public.shipments for select to authenticated using ((select auth.uid()) = user_id);
create policy bag_read on public.shipment_bags for select to authenticated using (exists (select 1 from public.shipments s where s.id = shipment_id and s.user_id = (select auth.uid())));
create policy event_read on public.shipment_events for select to authenticated using (exists (select 1 from public.shipments s where s.id = shipment_id and s.user_id = (select auth.uid())));
commit;
