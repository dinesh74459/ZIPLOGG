-- Durable operations notice for every verified LIVE manual-label payment.
-- The outbox row is written in the same transaction that marks the order paid,
-- so a paid order cannot exist without a pending notice. This file never sends
-- email; a private worker claims one notice, sends it, then records evidence.
begin;
create table public.live_order_notifications (
 id uuid primary key default gen_random_uuid(),
 order_id uuid not null unique references public.live_manual_orders(id),
 recipient text not null default 'operations@ziplogg.com' check(recipient='operations@ziplogg.com'),
 state text not null default 'pending' check(state in ('pending','sending','sent','review')),
 claim_token uuid,
 created_at timestamptz not null default now(),
 claimed_at timestamptz,
 sent_at timestamptz,
 provider_reference text,
 check(state <> 'sent' or (sent_at is not null and coalesce(length(btrim(provider_reference)),0)>0))
);
alter table public.live_order_notifications enable row level security;
revoke all on public.live_order_notifications from public,anon,authenticated;
grant all on public.live_order_notifications to service_role;

create function public.queue_live_order_notification() returns trigger
language plpgsql security definer set search_path='' as $$
begin
 if new.state='paid' and new.payment_id is not null and (tg_op='INSERT' or old.state is distinct from 'paid') then
  insert into public.live_order_notifications(order_id) values(new.id) on conflict(order_id) do nothing;
 end if;
 return new;
end $$;
create trigger queue_live_order_notification after insert or update of state on public.live_manual_orders
for each row execute function public.queue_live_order_notification();

-- Claims the oldest pending notice. A notice already in 'sending' is NEVER
-- reclaimed automatically: the send outcome is unknown, so staff must check
-- Zoho Sent and the order before any repeat. Stuck notices surface in the backlog.
create function public.claim_live_order_notification()
returns table(email_id uuid,claim_token uuid,recipient text,order_id uuid,order_state text,customer_email text,
 total_cents bigint,regular_cents bigint,promo_code text,payment_id text,paid_at timestamptz,
 summary text,shipment jsonb,pricing_source text)
language plpgsql security definer set search_path='' as $$
declare n uuid;
begin
 select e.id into n from public.live_order_notifications e
  where e.state='pending' order by e.created_at,e.id limit 1 for update skip locked;
 if n is null then return; end if;
 update public.live_order_notifications e set state='sending',claim_token=gen_random_uuid(),claimed_at=now() where e.id=n;
 return query select e.id,e.claim_token,e.recipient,o.id,o.state,o.email,o.total_cents,o.regular_cents,o.promo_code,
  o.payment_id,o.paid_at,q.summary,q.shipment,q.pricing_source
  from public.live_order_notifications e join public.live_manual_orders o on o.id=e.order_id
  join public.live_manual_quotes q on q.id=o.id where e.id=n;
end $$;

create function public.confirm_live_order_notification(p_email_id uuid,p_claim_token uuid,p_reference text)
returns void language plpgsql security definer set search_path='' as $$
declare e public.live_order_notifications;
begin
 if coalesce(length(btrim(p_reference)),0)=0 or length(p_reference)>500 then raise exception 'Provider evidence required'; end if;
 select * into e from public.live_order_notifications where id=p_email_id for update;
 if not found or p_claim_token is null or e.claim_token is distinct from p_claim_token then raise exception 'Claim mismatch'; end if;
 if e.state='sent' and e.provider_reference=btrim(p_reference) then return; end if;
 if e.state<>'sending' then raise exception 'Delivery state requires review'; end if;
 update public.live_order_notifications set state='sent',sent_at=now(),provider_reference=btrim(p_reference) where id=e.id;
end $$;

-- Monitoring only: counts and ages, no customer data.
create function public.live_order_notification_backlog(p_stuck_after interval default interval '10 minutes')
returns table(pending bigint,stuck_sending bigint,review bigint,oldest_pending_seconds bigint)
language sql security definer set search_path='' stable as $$
 select count(*) filter(where state='pending'),
  count(*) filter(where state='sending' and claimed_at<now()-p_stuck_after),
  count(*) filter(where state='review'),
  coalesce(extract(epoch from now()-min(created_at) filter(where state='pending'))::bigint,0)
 from public.live_order_notifications;
$$;

revoke all on function public.queue_live_order_notification(),public.claim_live_order_notification(),
 public.confirm_live_order_notification(uuid,uuid,text),public.live_order_notification_backlog(interval) from public,anon,authenticated;
grant execute on function public.claim_live_order_notification(),public.confirm_live_order_notification(uuid,uuid,text),
 public.live_order_notification_backlog(interval) to service_role;

-- Any order already verified paid before this migration gets a notice too.
-- At last check there were zero live orders, so this is expected to insert nothing.
insert into public.live_order_notifications(order_id)
 select id from public.live_manual_orders where state='paid' and payment_id is not null
 on conflict(order_id) do nothing;
commit;
