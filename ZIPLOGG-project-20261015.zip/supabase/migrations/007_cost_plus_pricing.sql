begin;
-- Trusted backend supplies costs including fees appropriate to the final charge.
-- Existing retail-only quotes remain unusable under the new policy.
alter table public.retail_quotes alter column fedex_retail_cents drop not null;
alter table public.retail_quotes add column postage_cents bigint check(postage_cents between 1 and 100000000);
alter table public.retail_quotes add column fee_cents bigint check(fee_cents between 0 and 100000000);
alter table public.retail_quotes add column bag_count integer check(bag_count between 1 and 1000);
create or replace function public.reserve_test_checkout(p_order_id uuid,p_user_id uuid,p_quote_id uuid,p_code text default '')
returns public.checkout_orders language plpgsql security definer set search_path='' as $$
declare q public.retail_quotes; o public.checkout_orders; regular bigint; discount bigint; code text:=upper(btrim(coalesce(p_code,'')));
begin
 perform 1 from auth.users where id=p_user_id and email_confirmed_at is not null and deleted_at is null for update;
 if not found then raise exception 'Verified customer required'; end if;
 select * into o from public.checkout_orders where id=p_order_id;
 if found then
  if o.user_id<>p_user_id or o.retail_quote_id is distinct from p_quote_id or coalesce(o.promo_code,'')<>code or o.live_mode then raise exception 'Request ID already used'; end if;
  if o.quote_snapshot->>'pricing_policy' is distinct from 'cost_plus_10' then raise exception 'Previous pricing retired; cancel this checkout first'; end if;
  if o.status<>'awaiting_payment' then raise exception 'Order already completed or cancelled'; end if;
  return o;
 end if;
 select * into q from public.retail_quotes where id=p_quote_id and user_id=p_user_id for update;
 if not found or q.live_mode or q.expires_at<=now() or q.postage_cents is null or q.fee_cents is null or q.bag_count is null then raise exception 'Valid server-side test retail quote required'; end if;
 if code not in ('','JAYHO') then raise exception 'Invalid promo code'; end if;
 if exists(select 1 from public.checkout_orders where user_id=p_user_id and not live_mode and status='awaiting_payment') then raise exception 'Finish or expire the existing checkout first'; end if;
 if code='JAYHO' and (not public.jayho_eligible(p_user_id)
  or exists(select 1 from public.promo_reservations where user_id=p_user_id and not live_mode)
  or exists(select 1 from public.checkout_orders paid_order join public.fulfillment_jobs j on j.order_id=paid_order.id where paid_order.user_id=p_user_id and not paid_order.live_mode)) then raise exception 'JAYHO is unavailable'; end if;
 regular:=q.postage_cents+q.fee_cents+1000*q.bag_count;discount:=case when code='JAYHO' then 200*q.bag_count else 0 end;
 if regular-discount<1 then raise exception 'Invalid quote total'; end if;
 insert into public.checkout_orders(id,user_id,checkout_session_id,total_cents,live_mode,shippo_shipment_id,shippo_rate_id,retail_quote_id,promo_code,quote_snapshot)
 values(p_order_id,p_user_id,'pending_'||p_order_id::text,regular-discount,false,q.shippo_shipment_id,q.shippo_rate_id,q.id,nullif(code,''),
 jsonb_build_object('pricing_policy','cost_plus_10','postage_cents',q.postage_cents,'fee_cents',q.fee_cents,'bag_count',q.bag_count,'service_cents',1000*q.bag_count,'regular_cents',regular,'discount_cents',discount,'evidence',q.evidence)) returning * into o;
 if code='JAYHO' then insert into public.promo_reservations values(p_user_id,false,o.id,'reserved'); end if;
 return o;
end $$;

commit;
