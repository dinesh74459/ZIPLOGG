-- Queue one confirmation per verified test payment. Does not send email.
begin;
create table public.test_payment_emails (
 id uuid primary key default gen_random_uuid(),
 order_id uuid not null unique references public.checkout_orders(id),
 job_id uuid not null unique references public.fulfillment_jobs(id),
 recipient text not null default 'operations@ziplogg.com' check(recipient='operations@ziplogg.com'),
 state text not null default 'pending' check(state in ('pending','sending','sent','review')),
 claim_token uuid,
 created_at timestamptz not null default now(),
 claimed_at timestamptz,
 sent_at timestamptz,
 provider_reference text,
 check(state <> 'sent' or (sent_at is not null and coalesce(length(btrim(provider_reference)),0)>0))
);
alter table public.test_payment_emails enable row level security;
revoke all on public.test_payment_emails from public,anon,authenticated;
grant all on public.test_payment_emails to service_role;

create function public.queue_test_payment_email() returns trigger
language plpgsql security definer set search_path='' as $$
begin
 if exists(select 1 from public.checkout_orders where id=new.order_id and live_mode=false) then
  insert into public.test_payment_emails(order_id,job_id) values(new.order_id,new.id) on conflict(order_id) do nothing;
 end if;
 return new;
end $$;
create trigger queue_test_payment_email after insert on public.fulfillment_jobs
for each row execute function public.queue_test_payment_email();

create function public.claim_test_payment_email(p_job_id uuid)
returns table(email_id uuid,claim_token uuid,order_id uuid,recipient text,total_cents bigint)
language plpgsql security definer set search_path='' as $$
begin
 return query with claimed as (
  update public.test_payment_emails e set state='sending',claim_token=gen_random_uuid(),claimed_at=now()
  from public.checkout_orders o,public.fulfillment_jobs j
  where e.job_id=p_job_id and e.state='pending' and o.id=e.order_id and j.id=e.job_id
   and j.order_id=o.id and o.live_mode=false and o.status in ('queued','manual_review')
  returning e.id,e.claim_token,e.order_id,e.recipient,o.total_cents
 ) select * from claimed;
end $$;

create function public.confirm_test_payment_email(p_email_id uuid,p_claim_token uuid,p_reference text)
returns void language plpgsql security definer set search_path='' as $$
declare e public.test_payment_emails;
begin
 if coalesce(length(btrim(p_reference)),0)=0 or length(p_reference)>500 then raise exception 'Provider evidence required'; end if;
 select * into e from public.test_payment_emails where id=p_email_id for update;
 if not found or p_claim_token is null or e.claim_token is distinct from p_claim_token then raise exception 'Claim mismatch'; end if;
 if e.state='sent' and e.provider_reference=p_reference then return; end if;
 if e.state<>'sending' then raise exception 'Delivery state requires review'; end if;
 update public.test_payment_emails set state='sent',sent_at=now(),provider_reference=p_reference where id=e.id;
end $$;
revoke all on function public.queue_test_payment_email(),public.claim_test_payment_email(uuid),public.confirm_test_payment_email(uuid,uuid,text) from public,anon,authenticated;
grant execute on function public.claim_test_payment_email(uuid),public.confirm_test_payment_email(uuid,uuid,text) to service_role;
-- No backfill: existing orders already received manual test confirmations.
-- A claimed/uncertain send is never automatically reclaimed or resent.
commit;
