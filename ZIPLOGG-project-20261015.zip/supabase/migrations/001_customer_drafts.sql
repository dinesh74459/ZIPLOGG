-- Customer drafts only. Never store authoritative prices, paid status or labels here.
begin;
create table public.shipment_drafts (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
 kind text not null check (kind in ('personal','business')),
 title text not null check (char_length(btrim(title)) between 1 and 120),
 details jsonb not null check (jsonb_typeof(details) = 'object' and octet_length(details::text) <= 65536),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create index shipment_drafts_owner_updated on public.shipment_drafts(user_id, updated_at desc);
alter table public.shipment_drafts enable row level security;
revoke all on public.shipment_drafts from anon, authenticated;
grant select, delete on public.shipment_drafts to authenticated;
grant insert (kind,title,details) on public.shipment_drafts to authenticated;
grant update (title,details) on public.shipment_drafts to authenticated;
create policy read_own on public.shipment_drafts for select to authenticated using ((select auth.uid()) = user_id);
create policy create_own on public.shipment_drafts for insert to authenticated with check ((select auth.uid()) = user_id);
create policy update_own on public.shipment_drafts for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy delete_own on public.shipment_drafts for delete to authenticated using ((select auth.uid()) = user_id);
create function public.stamp_draft_update() returns trigger language plpgsql set search_path = '' as $$
begin new.updated_at = now(); return new; end;
$$;
create trigger stamp_draft_update before update on public.shipment_drafts for each row execute function public.stamp_draft_update();
commit;
