-- Prepared locally. Apply only after reviewing in the intended Supabase project.
begin;
create table public.checkout_orders (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id),
 checkout_session_id text unique not null,
 total_cents bigint not null check (total_cents > 0),
 currency text not null default 'usd' check (currency = 'usd'),
 live_mode boolean not null default false,
 status text not null default 'awaiting_payment' check (status in ('awaiting_payment','queued','cancelled','manual_review','fulfilled')),
 shippo_shipment_id text not null,
 shippo_rate_id text not null,
 quote_snapshot jsonb not null check (jsonb_typeof(quote_snapshot) = 'object'),
 created_at timestamptz not null default now()
);
create table public.fulfillment_jobs (
 id uuid primary key default gen_random_uuid(),
 order_id uuid not null unique references public.checkout_orders(id),
 checkout_session_id text not null unique,
 stripe_payment_intent_id text not null unique,
 stripe_event_id text not null unique,
 state text not null default 'queued' check (state in ('queued','processing','purchase_pending','label_ready','email_sent','manual_review')),
 claimed_at timestamptz,
 provider_transaction_id text unique,
 created_at timestamptz not null default now()
);
alter table public.checkout_orders enable row level security;
alter table public.fulfillment_jobs enable row level security;
revoke all on public.checkout_orders, public.fulfillment_jobs from public, anon, authenticated;
grant all on public.checkout_orders, public.fulfillment_jobs to service_role;

-- Caller must first retrieve/verify the Stripe payment on the server.
create function public.enqueue_paid_order(p_order_id uuid, p_session_id text,
 p_payment_id text, p_event_id text, p_amount bigint, p_currency text, p_live boolean)
returns uuid language plpgsql security definer set search_path = '' as $$
declare o public.checkout_orders; j uuid;
begin
 select * into o from public.checkout_orders where id = p_order_id for update;
 if not found then raise exception 'Order missing'; end if;
 if p_session_id is distinct from o.checkout_session_id or p_amount is distinct from o.total_cents
 or p_currency is distinct from o.currency or p_live is distinct from o.live_mode
 or coalesce(p_payment_id,'') = '' or coalesce(p_event_id,'') = '' then
  raise exception 'Payment does not match order';
 end if;
 select id into j from public.fulfillment_jobs where order_id = p_order_id;
 if j is not null then return j; end if;
 if o.status <> 'awaiting_payment' then raise exception 'Order unavailable'; end if;
 insert into public.fulfillment_jobs(order_id,checkout_session_id,stripe_payment_intent_id,stripe_event_id)
 values(p_order_id,p_session_id,p_payment_id,p_event_id) returning id into j;
 update public.checkout_orders set status = 'queued' where id = p_order_id;
 return j;
end $$;

-- Only one worker can claim a job. No automatic reclaim after ambiguous purchase.
create function public.claim_fulfillment_job(p_job_id uuid)
returns setof public.fulfillment_jobs language sql security definer set search_path = '' as $$
 update public.fulfillment_jobs set state = 'processing', claimed_at = now()
 where id = p_job_id and state = 'queued' returning *;
$$;
revoke all on function public.enqueue_paid_order(uuid,text,text,text,bigint,text,boolean) from public,anon,authenticated;
revoke all on function public.claim_fulfillment_job(uuid) from public,anon,authenticated;
grant execute on function public.enqueue_paid_order(uuid,text,text,text,bigint,text,boolean) to service_role;
grant execute on function public.claim_fulfillment_job(uuid) to service_role;
commit;
