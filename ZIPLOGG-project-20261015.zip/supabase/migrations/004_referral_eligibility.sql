begin;
-- Referral attribution is captured once, on account creation; later editable
-- auth metadata cannot change it. Customer APIs never expose friends' emails.
create table public.referral_codes (
 user_id uuid primary key references auth.users(id) on delete cascade,
 code uuid not null unique default gen_random_uuid(),
 created_at timestamptz not null default now()
);
create table public.referrals (
 referred_user_id uuid primary key references auth.users(id) on delete cascade,
 referrer_user_id uuid not null references auth.users(id) on delete cascade,
 created_at timestamptz not null default now(),
 check (referred_user_id <> referrer_user_id)
);
create index referrals_owner on public.referrals(referrer_user_id);
alter table public.referral_codes enable row level security;
alter table public.referrals enable row level security;
revoke all on public.referral_codes, public.referrals from public, anon, authenticated;
grant all on public.referral_codes, public.referrals to service_role;

create function public.capture_signup_referral()
returns trigger language plpgsql security definer set search_path = '' as $$
declare owner_id uuid; supplied text;
begin
 supplied := new.raw_user_meta_data->>'ziplogg_referral';
 if supplied is null or supplied !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' then return new; end if;
 select c.user_id into owner_id from public.referral_codes c
 join auth.users u on u.id=c.user_id
 where c.code=supplied::uuid and u.email_confirmed_at is not null
 and u.deleted_at is null and u.id<>new.id
 and lower(u.email) is distinct from lower(new.email);
 if owner_id is not null then
  insert into public.referrals(referred_user_id,referrer_user_id) values(new.id,owner_id)
  on conflict (referred_user_id) do nothing;
 end if;
 return new;
end $$;
revoke all on function public.capture_signup_referral() from public,anon,authenticated;
create trigger ziplogg_capture_referral after insert on auth.users
for each row execute function public.capture_signup_referral();

-- Service-only eligibility: identity, verification and payment history come
-- from server records, never caller-supplied firstShipment/verifiedReferral flags.
create function public.jayho_eligible(p_user_id uuid)
returns boolean language sql stable security definer set search_path = '' as $$
 select exists(select 1 from auth.users where id=p_user_id and email_confirmed_at is not null and deleted_at is null)
 and exists(select 1 from public.referrals r join auth.users u on u.id=r.referred_user_id
 where r.referrer_user_id=p_user_id and u.email_confirmed_at is not null and u.deleted_at is null)
 and not exists(select 1 from public.checkout_orders o join public.fulfillment_jobs j on j.order_id=o.id
 where o.user_id=p_user_id and o.live_mode)
 and not exists(select 1 from public.shipments s join public.fulfillment_records f on f.shipment_id=s.id
 where s.user_id=p_user_id and f.payment_verified_at is not null);
$$;
revoke all on function public.jayho_eligible(uuid) from public,anon,authenticated;
grant execute on function public.jayho_eligible(uuid) to service_role;

create function public.my_referral_status()
returns jsonb language plpgsql security definer set search_path = '' as $$
declare uid uuid := auth.uid(); token uuid; verified_count integer;
begin
 if uid is null or not exists(select 1 from auth.users where id=uid and email_confirmed_at is not null and deleted_at is null) then
  raise exception 'Sign in with a verified account';
 end if;
 insert into public.referral_codes(user_id) values(uid) on conflict(user_id) do nothing;
 select code into token from public.referral_codes where user_id=uid;
 select count(*) into verified_count from public.referrals r join auth.users u on u.id=r.referred_user_id
 where r.referrer_user_id=uid and u.email_confirmed_at is not null and u.deleted_at is null;
 return jsonb_build_object('code',token,'verifiedFriends',verified_count,'eligible',public.jayho_eligible(uid));
end $$;
revoke all on function public.my_referral_status() from public,anon,authenticated;
grant execute on function public.my_referral_status() to authenticated;
commit;
