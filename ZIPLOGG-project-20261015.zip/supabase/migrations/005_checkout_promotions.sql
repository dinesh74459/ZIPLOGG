begin;
-- Only trusted backend code can store a matched carrier RETAIL quote here.
-- A wholesale Shippo amount is not a retail quote. Test and live are separated.
create table public.retail_quotes (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id),
 fedex_retail_cents bigint not null check(fedex_retail_cents between 1 and 100000000),
 live_mode boolean not null default false,
 shippo_shipment_id text not null,
 shippo_rate_id text not null,
 evidence jsonb not null check(jsonb_typeof(evidence)='object'),
 expires_at timestamptz not null,
 created_at timestamptz not null default now()
);
create table public.promo_reservations (
 user_id uuid not null references auth.users(id),
 live_mode boolean not null,
 order_id uuid not null unique references public.checkout_orders(id),
 state text not null check(state in ('reserved','consumed')),
 primary key(user_id,live_mode)
);
alter table public.checkout_orders add column retail_quote_id uuid unique references public.retail_quotes(id);
alter table public.checkout_orders add column promo_code text check(promo_code is null or promo_code='JAYHO');
alter table public.retail_quotes enable row level security;
alter table public.promo_reservations enable row level security;
revoke all on public.retail_quotes,public.promo_reservations from public,anon,authenticated;
grant all on public.retail_quotes,public.promo_reservations to service_role;

-- Called BEFORE Stripe. A durable reservation survives timeouts; never release
-- it on a browser cancel redirect or a timer because payment could still succeed.
create function public.reserve_test_checkout(p_order_id uuid,p_user_id uuid,p_quote_id uuid,p_code text default '')
returns public.checkout_orders language plpgsql security definer set search_path='' as $$
declare q public.retail_quotes; o public.checkout_orders; regular bigint; discount bigint; code text:=upper(btrim(coalesce(p_code,'')));
begin
 perform 1 from auth.users where id=p_user_id and email_confirmed_at is not null and deleted_at is null for update;
 if not found then raise exception 'Verified customer required'; end if;
 select * into o from public.checkout_orders where id=p_order_id;
 if found then
  if o.user_id<>p_user_id or o.retail_quote_id is distinct from p_quote_id or coalesce(o.promo_code,'')<>code or o.live_mode then raise exception 'Request ID already used'; end if;
  if o.status<>'awaiting_payment' then raise exception 'Order already completed or cancelled'; end if;
  return o;
 end if;
 select * into q from public.retail_quotes where id=p_quote_id and user_id=p_user_id for update;
 if not found or q.live_mode or q.expires_at<=now() then raise exception 'Valid server-side test retail quote required'; end if;
 if code not in ('','JAYHO') then raise exception 'Invalid promo code'; end if;
 if exists(select 1 from public.checkout_orders where user_id=p_user_id and not live_mode and status='awaiting_payment') then raise exception 'Finish or expire the existing checkout first'; end if;
 if code='JAYHO' and (not public.jayho_eligible(p_user_id)
  or exists(select 1 from public.promo_reservations where user_id=p_user_id and not live_mode)
  or exists(select 1 from public.checkout_orders paid_order join public.fulfillment_jobs j on j.order_id=paid_order.id where paid_order.user_id=p_user_id and not paid_order.live_mode)) then raise exception 'JAYHO is unavailable'; end if;
 regular:=round(q.fedex_retail_cents*0.45);discount:=case when code='JAYHO' then round(regular*0.20) else 0 end;
 if regular-discount<1 then raise exception 'Invalid quote total'; end if;
 insert into public.checkout_orders(id,user_id,checkout_session_id,total_cents,live_mode,shippo_shipment_id,shippo_rate_id,retail_quote_id,promo_code,quote_snapshot)
 values(p_order_id,p_user_id,'pending_'||p_order_id::text,regular-discount,false,q.shippo_shipment_id,q.shippo_rate_id,q.id,nullif(code,''),
 jsonb_build_object('pricing_policy','fedex45','fedex_retail_cents',q.fedex_retail_cents,'regular_cents',regular,'discount_cents',discount,'evidence',q.evidence)) returning * into o;
 if code='JAYHO' then insert into public.promo_reservations values(p_user_id,false,o.id,'reserved'); end if;
 return o;
end $$;

-- Attach only the Stripe session returned for this order's idempotency key.
create function public.bind_test_checkout(p_order_id uuid,p_session_id text,p_amount bigint)
returns void language plpgsql security definer set search_path='' as $$
begin
 if p_session_id !~ '^cs_test_' then raise exception 'Test session required'; end if;
 update public.checkout_orders set checkout_session_id=p_session_id
 where id=p_order_id and not live_mode and retail_quote_id is not null and status='awaiting_payment'
 and total_cents=p_amount and checkout_session_id in ('pending_'||p_order_id::text,p_session_id);
 if not found then raise exception 'Session does not match reserved order'; end if;
end $$;

-- Runs inside the existing verified-payment enqueue transaction. A retry cannot
-- consume a second discount: fulfillment_jobs and reservations are unique.
create function public.consume_order_promo()
returns trigger language plpgsql security definer set search_path='' as $$
declare o public.checkout_orders;
begin
 select * into o from public.checkout_orders where id=new.order_id;
 if o.promo_code='JAYHO' then
  update public.promo_reservations set state='consumed' where order_id=o.id and user_id=o.user_id and live_mode=o.live_mode;
  if not found then raise exception 'Missing promo reservation'; end if;
 end if;
 return new;
end $$;
create trigger consume_verified_payment_promo before insert on public.fulfillment_jobs for each row execute function public.consume_order_promo();
revoke all on function public.reserve_test_checkout(uuid,uuid,uuid,text),public.bind_test_checkout(uuid,text,bigint),public.consume_order_promo() from public,anon,authenticated;
grant execute on function public.reserve_test_checkout(uuid,uuid,uuid,text),public.bind_test_checkout(uuid,text,bigint) to service_role;
commit;
