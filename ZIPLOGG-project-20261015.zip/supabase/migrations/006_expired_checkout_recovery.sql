begin;
-- Service role only. Caller must retrieve the matching Stripe session and
-- verify expired + unpaid before calling. No client redirect can release it.
create function public.release_expired_test_checkout(p_order_id uuid,p_user_id uuid,p_session_id text)
returns boolean language plpgsql security definer set search_path='' as $$
declare o public.checkout_orders;
begin
 perform 1 from auth.users where id=p_user_id for update;
 select * into o from public.checkout_orders where id=p_order_id and user_id=p_user_id for update;
 if not found or o.live_mode or o.retail_quote_id is null
 or p_session_id !~ '^cs_test_' or o.checkout_session_id is distinct from p_session_id then
  raise exception 'Checkout mismatch';
 end if;
 if o.status='cancelled' then return true; end if;
 if o.status<>'awaiting_payment' or exists(select 1 from public.fulfillment_jobs where order_id=o.id)
 or exists(select 1 from public.promo_reservations where order_id=o.id and state='consumed') then
  raise exception 'Payment already processed; reservation cannot be released';
 end if;
 delete from public.promo_reservations where order_id=o.id and state='reserved';
 update public.checkout_orders set status='cancelled' where id=o.id;
 return true;
end $$;
revoke all on function public.release_expired_test_checkout(uuid,uuid,text) from public,anon,authenticated;
grant execute on function public.release_expired_test_checkout(uuid,uuid,text) to service_role;
commit;
