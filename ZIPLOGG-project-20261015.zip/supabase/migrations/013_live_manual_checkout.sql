-- Live manual-fulfillment orders are isolated from all sandbox/Shippo workers.
begin;
create table public.live_manual_quotes (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id),
 summary text not null check(length(summary) between 10 and 2000),
 retail_cents bigint not null check(retail_cents between 100 and 10000000),
 postage_cents bigint not null check(postage_cents between 1 and 10000000),
 evidence text not null check(length(evidence) between 10 and 4000),
 shipment jsonb not null check(jsonb_typeof(shipment)='object'),
 expires_at timestamptz not null,
 created_at timestamptz not null default now(),
 approved_by uuid not null references auth.users(id),
 fulfillment_ready boolean not null default false
);
create table public.live_manual_orders (
 id uuid primary key references public.live_manual_quotes(id),
 user_id uuid not null references auth.users(id),
 email text not null,
 total_cents bigint not null check(total_cents>0),
 regular_cents bigint not null,
 promo_code text check(promo_code is null or promo_code='JAYHO'),
 session_id text unique,
 payment_id text unique,
 state text not null default 'awaiting_payment' check(state in ('awaiting_payment','paid','expired','label_sent','refunded','review')),
 terms_version text not null,
 accepted_at timestamptz not null default now(),
 created_at timestamptz not null default now(),
 paid_at timestamptz,
 label_sent_at timestamptz,
 mail_reference text
);
create unique index live_manual_one_pending on public.live_manual_orders(user_id) where state='awaiting_payment';
alter table public.live_manual_quotes enable row level security;
alter table public.live_manual_orders enable row level security;
revoke all on public.live_manual_quotes,public.live_manual_orders from public,anon,authenticated;
grant all on public.live_manual_quotes,public.live_manual_orders to service_role;

-- A reserved quote is an immutable checkout snapshot, including its expiry.
-- Locking the quote also serializes staff edits with the reservation transaction.
create function public.protect_reserved_live_quote()
returns trigger language plpgsql security definer set search_path='' as $$
begin
 if exists(select 1 from public.live_manual_orders where id=old.id) then
  raise exception 'Reserved quotes cannot be edited; review the existing order';
 end if;
 return new;
end $$;
create trigger protect_reserved_live_quote before update on public.live_manual_quotes
for each row execute function public.protect_reserved_live_quote();
revoke all on function public.protect_reserved_live_quote() from public,anon,authenticated;

create function public.reserve_live_manual_checkout(p_user uuid,p_quote uuid,p_promo text)
returns public.live_manual_orders language plpgsql security definer set search_path='' as $$
declare q public.live_manual_quotes; o public.live_manual_orders; customer_email text;
 code text:=upper(btrim(coalesce(p_promo,''))); regular bigint; amount bigint;
begin
 select email into customer_email from auth.users where id=p_user and email_confirmed_at is not null and deleted_at is null for update;
 if not found then raise exception 'Verified customer required'; end if;
 select * into o from public.live_manual_orders where id=p_quote;
 if found then
  if o.user_id<>p_user or coalesce(o.promo_code,'')<>code or o.state<>'awaiting_payment' then raise exception 'Existing order must be reviewed'; end if;
  return o;
 end if;
 select * into q from public.live_manual_quotes where id=p_quote and user_id=p_user for update;
 if not found or not q.fulfillment_ready or q.expires_at<now()+interval '31 minutes' or q.expires_at>now()+interval '24 hours' then raise exception 'Confirmed available shipment quote required'; end if;
 if code not in ('','JAYHO') then raise exception 'Invalid promo'; end if;
 if code='JAYHO' and (not public.jayho_eligible(p_user) or exists(select 1 from public.live_manual_orders where user_id=p_user and state<>'expired')) then raise exception 'JAYHO unavailable'; end if;
 regular:=round(q.retail_cents*0.45);
 amount:=regular-case when code='JAYHO' then round(regular*0.20) else 0 end;
 insert into public.live_manual_orders(id,user_id,email,total_cents,regular_cents,promo_code,terms_version)
 values(q.id,p_user,customer_email,amount,regular,nullif(code,''),'manual-shipping-v1') returning * into o;
 return o;
end $$;
create function public.bind_live_manual_checkout(p_order uuid,p_session text,p_amount bigint)
returns void language plpgsql security definer set search_path='' as $$
begin
 if p_session !~ '^cs_live_' then raise exception 'Live session required'; end if;
 update public.live_manual_orders set session_id=p_session where id=p_order and total_cents=p_amount and state='awaiting_payment' and (session_id is null or session_id=p_session);
 if not found then raise exception 'Session mismatch'; end if;
end $$;
create function public.confirm_live_manual_payment(p_order uuid,p_session text,p_payment text,p_amount bigint)
returns void language plpgsql security definer set search_path='' as $$
declare o public.live_manual_orders;
begin
 select * into o from public.live_manual_orders where id=p_order for update;
 if not found or o.session_id is distinct from p_session or o.total_cents<>p_amount or p_payment !~ '^pi_' then raise exception 'Payment mismatch'; end if;
 if o.state in ('paid','label_sent') and o.payment_id=p_payment then return; end if;
 if o.state<>'awaiting_payment' then raise exception 'Order requires review'; end if;
 update public.live_manual_orders set state='paid',payment_id=p_payment,paid_at=now() where id=p_order;
end $$;
revoke all on function public.reserve_live_manual_checkout(uuid,uuid,text),public.bind_live_manual_checkout(uuid,text,bigint),public.confirm_live_manual_payment(uuid,text,text,bigint) from public,anon,authenticated;
grant execute on function public.reserve_live_manual_checkout(uuid,uuid,text),public.bind_live_manual_checkout(uuid,text,bigint),public.confirm_live_manual_payment(uuid,text,text,bigint) to service_role;
commit;
