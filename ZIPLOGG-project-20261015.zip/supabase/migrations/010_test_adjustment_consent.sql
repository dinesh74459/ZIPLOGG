begin;
create table public.checkout_adjustment_consents (
 order_id uuid primary key references public.checkout_orders(id),
 user_id uuid not null references auth.users(id),
 policy_version text not null,
 consent_text text not null,
 accepted_at timestamptz not null default now(),
 test_only boolean not null default true check (test_only=true)
);
alter table public.checkout_adjustment_consents enable row level security;
revoke all on public.checkout_adjustment_consents from public,anon,authenticated;
grant all on public.checkout_adjustment_consents to service_role;
create function public.record_test_adjustment_consent(p_order_id uuid,p_user_id uuid,p_version text,p_accepted boolean)
returns void language plpgsql security definer set search_path='' as $$
declare o public.checkout_orders;
begin
 if p_accepted is distinct from true or p_version is distinct from 'adjustments-test-v1' then raise exception 'Explicit current consent required'; end if;
 select * into o from public.checkout_orders where id=p_order_id for update;
 if not found or o.user_id<>p_user_id or o.live_mode or o.status<>'awaiting_payment' then raise exception 'Eligible test order required'; end if;
 insert into public.checkout_adjustment_consents(order_id,user_id,policy_version,consent_text)
 values(o.id,p_user_id,p_version,'TEST ONLY: I understand the proposed adjustment policy: ZIPLOGG will email documented carrier weight, dimensions or address corrections and the itemized amount at least 7 days before charging. A dispute raised during that period pauses the charge for review. This test checkbox does not save my card or authorize any real charge.')
 on conflict (order_id) do nothing;
end $$;
revoke all on function public.record_test_adjustment_consent(uuid,uuid,text,boolean) from public,anon,authenticated;
grant execute on function public.record_test_adjustment_consent(uuid,uuid,text,boolean) to service_role;
commit;
