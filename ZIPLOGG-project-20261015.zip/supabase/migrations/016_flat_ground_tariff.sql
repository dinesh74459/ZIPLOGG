-- ZIPLOGG flat national Ground tariff for parcels over 1 lb (owner-approved October 15, 2026:
-- "create the prices ... I will stick to that prices"). These are ZIPLOGG selling prices, not
-- carrier quotes. Derivation (documented in PRICING-GROUND-V1.md): FedEx Ground 2026 standard list
-- rate, zone 5, at the top weight of each band x 1.20 (fuel allowance) + $6.45 residential, rounded
-- up to .99. Handling = FedEx 2026 zone 5-6 Additional Handling x 1.20, highest single charge only.
-- The owner's $108 heavy/large-bag fee replaces handling when it applies and is not discounted.
begin;
alter table public.live_manual_quotes add column price_cents bigint check(price_cents is null or price_cents between 100 and 10000000);
alter table public.live_manual_quotes add column fee_cents bigint not null default 0 check(fee_cents between 0 and 1000000);
alter table public.live_manual_quotes drop constraint live_manual_quotes_pricing_source_check;
alter table public.live_manual_quotes add constraint live_manual_quotes_pricing_source_check
 check(pricing_source in ('manual_carrier_quote','fixed_small_v1','flat_ground_v1'));
alter table public.live_manual_quotes drop constraint manual_quote_evidence_required;
alter table public.live_manual_quotes add constraint manual_quote_evidence_required
 check(pricing_source in ('fixed_small_v1','flat_ground_v1') or (postage_cents is not null and approved_by is not null));
alter table public.live_manual_quotes add constraint flat_ground_price_required
 check(pricing_source<>'flat_ground_v1' or price_cents is not null);

-- Band table is data, so a price change is an UPDATE, not code.
create table public.ground_tariff_bands (
 max_rating_lb int primary key check(max_rating_lb between 2 and 100),
 price_cents bigint not null check(price_cents between 100 and 1000000)
);
alter table public.ground_tariff_bands enable row level security;
revoke all on public.ground_tariff_bands from public,anon,authenticated;
grant all on public.ground_tariff_bands to service_role;
grant select on public.ground_tariff_bands to anon,authenticated;
create policy ground_tariff_public_read on public.ground_tariff_bands for select to anon,authenticated using(true);
insert into public.ground_tariff_bands values
 (2,2599),(5,2899),(10,3199),(15,3499),(20,3999),(25,4399),(30,4999),(35,5599),(40,6099),(45,6699),
 (50,7099),(55,7199),(60,7599),(65,7899),(70,8399),(80,9199),(90,10499),(100,11399);

-- Price one package. Mirrors dist/luggage-pricing.js packageEstimate + heavyBagFee.
create function public.ground_package_price(p_weight numeric,p_l numeric,p_w numeric,p_h numeric,p_packaging text)
returns table(rating_lb int,base_cents bigint,handling_cents bigint,fee_cents bigint)
language plpgsql stable security definer set search_path='' as $$
declare d int[]; l int; w int; h int; vol int; girth int; dimw int; ah boolean; rating int; band bigint;
begin
 if p_weight is null or p_weight<=0 or p_weight>100 then raise exception 'Each package must weigh more than 0 and no more than 100 lb'; end if;
 if p_l is null or p_w is null or p_h is null or least(p_l,p_w,p_h)<=0 or greatest(p_l,p_w,p_h)>120 then raise exception 'Enter all three dimensions, up to 120 in'; end if;
 if p_packaging not in ('luggage','box') then raise exception 'Choose suitcase or box packaging'; end if;
 select array_agg(x order by x desc) into d from unnest(array[ceil(p_l)::int,ceil(p_w)::int,ceil(p_h)::int]) x;
 l:=d[1]; w:=d[2]; h:=d[3]; vol:=l*w*h; girth:=l+2*w+2*h;
 if l>96 or girth>130 or vol>17280 then raise exception 'Oversize package: request a quote'; end if;
 dimw:=ceil(vol/139.0)::int;
 ah:= l>48 or w>30 or girth>105 or vol>10368;
 rating:=greatest(ceil(p_weight)::int,dimw,case when ah then 40 else 0 end);
 select b.price_cents into band from public.ground_tariff_bands b where b.max_rating_lb>=rating order by b.max_rating_lb limit 1;
 if band is null then raise exception 'Rating weight over 100 lb: request a quote'; end if;
 fee_cents:=case when p_weight>70 or girth>105 then 10800 else 0 end;
 handling_cents:=case when fee_cents>0 then 0 else greatest(
   case when p_weight>50 then 6750 else 0 end,
   case when ah then 4620 else 0 end,
   case when p_packaging='luggage' then 3960 else 0 end) end;
 rating_lb:=rating; base_cents:=band;
 return next;
end $$;

create function public.create_flat_ground_quote(p_request uuid,p_shipment jsonb)
returns uuid language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); q public.live_manual_quotes; side text; field text; zip3 int; pkg jsonb; n int;
 p record; price bigint:=0; fee bigint:=0; label text;
begin
 if u is null or not exists(select 1 from auth.users where id=u and email_confirmed_at is not null and deleted_at is null) then raise exception 'Sign in with a verified ZIPLOGG account first'; end if;
 perform 1 from auth.users where id=u for update;
 if p_request is null or p_shipment is null or jsonb_typeof(p_shipment)<>'object' or octet_length(p_shipment::text)>16000 then raise exception 'Invalid shipment details'; end if;
 select * into q from public.live_manual_quotes where id=p_request;
 if found then
  if q.user_id<>u or q.pricing_source<>'flat_ground_v1' or q.shipment<>p_shipment||jsonb_build_object('service','ground') then raise exception 'Quote conflict'; end if;
  return q.id;
 end if;
 if exists(select 1 from public.live_manual_orders where user_id=u and state='awaiting_payment') then raise exception 'Resume your existing payment from My payments first'; end if;
 foreach side in array array['from','to'] loop
  if p_shipment#>>array[side,'country'] is distinct from 'United States' then raise exception 'Flat Ground prices cover USA-to-USA only; request a quote'; end if;
  foreach field in array array['name','phone','street','city','region','postal'] loop
   if length(btrim(coalesce(p_shipment#>>array[side,field],''))) not between 1 and 160 then raise exception 'Complete sender and recipient contact details and addresses'; end if;
  end loop;
  if (p_shipment#>>array[side,'postal']) !~ '^[0-9]{5}(-[0-9]{4})?$' then raise exception 'Enter a valid US ZIP code'; end if;
  zip3:=left(p_shipment#>>array[side,'postal'],3)::int;
  -- Contiguous USA only: AK, HI, PR/VI, Guam/Pacific, military APO/FPO need a quote.
  if zip3 between 995 and 999 or zip3 between 967 and 969 or zip3 between 6 and 9 or zip3 between 962 and 966 or zip3 between 90 and 98 or zip3=340 then
   raise exception 'Alaska, Hawaii, territories and military addresses need a quote';
  end if;
 end loop;
 if jsonb_typeof(p_shipment->'packages')<>'array' then raise exception 'Package details required'; end if;
 n:=jsonb_array_length(p_shipment->'packages');
 if n not between 1 and 5 then raise exception 'Flat Ground checkout covers 1 to 5 packages; request a quote for more'; end if;
 for pkg in select * from jsonb_array_elements(p_shipment->'packages') loop
  select * into p from public.ground_package_price((pkg->>'weight')::numeric,(pkg->>'length')::numeric,(pkg->>'width')::numeric,(pkg->>'height')::numeric,pkg->>'packaging');
  price:=price+p.base_cents+p.handling_cents; fee:=fee+p.fee_cents;
 end loop;
 if (p_shipment->>'ship_date') is null or (p_shipment->>'ship_date')::date<current_date or (p_shipment->>'ship_date')::date>current_date+30 then raise exception 'Choose a ship date within the next 30 days'; end if;
 if (select count(*) from public.live_manual_quotes where user_id=u and created_at>now()-interval '1 day')>=10 then raise exception 'Daily quote limit reached'; end if;
 label:='Ground delivery · '||n||' package'||case when n>1 then 's' else '' end||' · '||(p_shipment#>>'{from,city}')||' to '||(p_shipment#>>'{to,city}');
 insert into public.live_manual_quotes(id,user_id,summary,retail_cents,postage_cents,evidence,shipment,expires_at,approved_by,fulfillment_ready,pricing_source,price_cents,fee_cents)
 values(p_request,u,label,price+fee,null,
 'ZIPLOGG flat Ground tariff v1 (owner-approved October 15, 2026). price_cents = band price + handling; fee_cents = $108 heavy/large-bag fees. Not a live carrier quote or postage cost.',
 p_shipment||jsonb_build_object('service','ground'),now()+interval '2 hours',null,true,'flat_ground_v1',price,fee);
 return p_request;
end $$;
revoke all on function public.ground_package_price(numeric,numeric,numeric,numeric,text),public.create_flat_ground_quote(uuid,jsonb) from public,anon;
grant execute on function public.create_flat_ground_quote(uuid,jsonb) to authenticated;

-- Checkout amount: flat tariff uses its own price; JAYHO 20% applies to price, never to the $108 fee.
create or replace function public.reserve_live_manual_checkout(p_user uuid,p_quote uuid,p_promo text)
returns public.live_manual_orders language plpgsql security definer set search_path='' as $$
declare q public.live_manual_quotes; o public.live_manual_orders; customer_email text;
 code text:=upper(btrim(coalesce(p_promo,''))); base bigint; regular bigint; amount bigint;
begin
 select email into customer_email from auth.users where id=p_user and email_confirmed_at is not null and deleted_at is null for update;
 if not found then raise exception 'Verified customer required'; end if;
 select * into o from public.live_manual_orders where id=p_quote;
 if found then
  if o.user_id<>p_user or coalesce(o.promo_code,'')<>code or o.state<>'awaiting_payment' then raise exception 'Existing order must be reviewed'; end if;
  return o;
 end if;
 select * into q from public.live_manual_quotes where id=p_quote and user_id=p_user for update;
 if not found or not q.fulfillment_ready or q.expires_at<now()+interval '31 minutes' or q.expires_at>now()+interval '24 hours' then raise exception 'Confirmed available shipment quote required'; end if;
 if code not in ('','JAYHO') then raise exception 'Invalid promo'; end if;
 if code='JAYHO' and (not public.jayho_eligible(p_user) or exists(select 1 from public.live_manual_orders where user_id=p_user and state<>'expired')) then raise exception 'JAYHO unavailable'; end if;
 base:=case when q.pricing_source='flat_ground_v1' then q.price_cents else round(q.retail_cents*0.45) end;
 regular:=base+coalesce(q.fee_cents,0);
 amount:=regular-case when code='JAYHO' then round(base*0.20) else 0 end;
 insert into public.live_manual_orders(id,user_id,email,total_cents,regular_cents,promo_code,terms_version)
 values(q.id,p_user,customer_email,amount,regular,nullif(code,''),'manual-shipping-v1') returning * into o;
 return o;
end $$;
revoke all on function public.reserve_live_manual_checkout(uuid,uuid,text) from public,anon,authenticated;
grant execute on function public.reserve_live_manual_checkout(uuid,uuid,text) to service_role;
commit;
