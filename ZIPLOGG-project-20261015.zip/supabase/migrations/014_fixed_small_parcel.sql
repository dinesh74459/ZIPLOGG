-- Owner-authorized fixed ZIPLOGG tariff. No claim that these are live carrier rates.
begin;
alter table public.live_manual_quotes alter column postage_cents drop not null;
alter table public.live_manual_quotes alter column approved_by drop not null;
alter table public.live_manual_quotes add column pricing_source text not null default 'manual_carrier_quote'
 check(pricing_source in ('manual_carrier_quote','fixed_small_v1'));
alter table public.live_manual_quotes add constraint manual_quote_evidence_required
 check(pricing_source='fixed_small_v1' or (postage_cents is not null and approved_by is not null));

create function public.create_fixed_small_quote(p_request uuid,p_shipment jsonb,p_service text)
returns uuid language plpgsql security definer set search_path='' as $$
declare u uuid:=auth.uid(); q public.live_manual_quotes; reference bigint; side text; field text;
 weight numeric; l numeric; w numeric; h numeric; label text;
begin
 if u is null or not exists(select 1 from auth.users where id=u and email_confirmed_at is not null and deleted_at is null) then raise exception 'Sign in with a verified ZIPLOGG account first'; end if;
 perform 1 from auth.users where id=u for update;
 if p_request is null or p_shipment is null or jsonb_typeof(p_shipment)<>'object' or octet_length(p_shipment::text)>12000 then raise exception 'Invalid shipment details'; end if;
 select * into q from public.live_manual_quotes where id=p_request;
 if found then
  if q.user_id<>u or q.pricing_source<>'fixed_small_v1' or q.shipment<>p_shipment||jsonb_build_object('service',p_service) then raise exception 'Quote conflict'; end if;
  return q.id;
 end if;
 if exists(select 1 from public.live_manual_orders where user_id=u and state='awaiting_payment') then raise exception 'Resume your existing payment from My payments first'; end if;
 foreach side in array array['from','to'] loop
  if p_shipment#>>array[side,'country'] is distinct from 'United States' then raise exception 'Fixed prices currently cover USA-to-USA only'; end if;
  foreach field in array array['name','phone','street','city','region','postal'] loop
   if length(btrim(coalesce(p_shipment#>>array[side,field],''))) not between 1 and 160 then raise exception 'Complete sender and recipient contact details and addresses'; end if;
  end loop;
  if (p_shipment#>>array[side,'postal']) !~ '^[0-9]{5}(-[0-9]{4})?$' then raise exception 'Enter a valid US ZIP code'; end if;
 end loop;
 weight:=(p_shipment#>>'{package,weight}')::numeric;
 l:=(p_shipment#>>'{package,length}')::numeric;
 w:=(p_shipment#>>'{package,width}')::numeric;
 h:=(p_shipment#>>'{package,height}')::numeric;
 if weight is null or l is null or w is null or h is null or weight not between 0.01 and 1 or l not between 0.1 and 120 or w not between 0.1 and 120 or h not between 0.1 and 120 then raise exception 'One package up to 1 lb with valid dimensions is required'; end if;
 -- Bound the launch offer to a small parcel: large lightweight bags still need a quote.
 if ceil(l)*ceil(w)*ceil(h)>139 then raise exception 'This package exceeds the 1 lb dimensional-weight limit; request a quote'; end if;
 if (p_shipment->>'ship_date') is null or (p_shipment->>'ship_date')::date<current_date or (p_shipment->>'ship_date')::date>current_date+30 then raise exception 'Choose a ship date within the next 30 days'; end if;
 reference:=case p_service when 'ground' then 1270 when 'three_day' then 1620 when 'two_day' then 2150 when 'next_pm' then 3280 when 'next_am' then 4560 else null end;
 label:=case p_service when 'ground' then 'Ground delivery' when 'three_day' then 'Three-day delivery' when 'two_day' then 'Two-day delivery' when 'next_pm' then 'Next-day afternoon' when 'next_am' then 'Next-day morning' end;
 if reference is null then raise exception 'Select a valid service'; end if;
 if (select count(*) from public.live_manual_quotes where user_id=u and created_at>now()-interval '1 day')>=10 then raise exception 'Daily quote limit reached'; end if;
 insert into public.live_manual_quotes(id,user_id,summary,retail_cents,postage_cents,evidence,shipment,expires_at,approved_by,fulfillment_ready,pricing_source)
 values(p_request,u,label||' · small parcel up to 1 lb · '||(p_shipment#>>'{from,city}')||' to '||(p_shipment#>>'{to,city}'),reference,null,
 'Owner-approved fixed ZIPLOGG small-parcel tariff, October 14, 2026. Reference amounts supplied by owner; no live carrier quote or postage purchase cost represented.',
 p_shipment||jsonb_build_object('service',p_service),now()+interval '2 hours',null,true,'fixed_small_v1');
 return p_request;
end $$;
revoke all on function public.create_fixed_small_quote(uuid,jsonb,text) from public,anon;
grant execute on function public.create_fixed_small_quote(uuid,jsonb,text) to authenticated;
commit;
