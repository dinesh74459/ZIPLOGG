-- Private operator workflow. No browser/customer access and no automatic sending.
begin;
create table public.manual_deliveries (
 id uuid primary key default gen_random_uuid(),
 order_id uuid not null unique references public.checkout_orders(id),
 recipient text not null,
 sample_only boolean not null,
 carrier text not null,
 tracking_number text,
 provider_label_reference text,
 attachment_sha256 text not null check (attachment_sha256 ~ '^[a-f0-9]{64}$'),
 state text not null default 'prepared' check (state in ('prepared','sending','sent','review')),
 prepared_at timestamptz not null default now(),
 claimed_at timestamptz,
 sent_at timestamptz,
 mail_reference text,
 check (sample_only or (coalesce(length(btrim(tracking_number)),0) > 0 and coalesce(length(btrim(provider_label_reference)),0) > 0)),
 check (state <> 'sent' or (sent_at is not null and coalesce(length(btrim(mail_reference)),0) > 0))
);
alter table public.manual_deliveries enable row level security;
revoke all on public.manual_deliveries from public, anon, authenticated;
grant all on public.manual_deliveries to service_role;

create function public.prepare_manual_delivery(p_order_id uuid,p_sha256 text,p_sample boolean,
 p_carrier text,p_tracking text default null,p_label_reference text default null)
returns uuid language plpgsql security definer set search_path='' as $$
declare o public.checkout_orders; d public.manual_deliveries; recipient_email text;
begin
 select * into o from public.checkout_orders where id=p_order_id for update;
 if not found or o.status not in ('queued','manual_review') then raise exception 'Verified paid order required'; end if;
 if not exists (select 1 from public.fulfillment_jobs where order_id=o.id) then raise exception 'Payment verification missing'; end if;
 if p_sample is null or p_sample=o.live_mode then raise exception 'Sample/live mismatch'; end if;
 if p_sample then recipient_email := 'operations@ziplogg.com';
 else
  -- Real carrier labels remain gated until an approved carrier implementation exists.
  raise exception 'Live manual delivery is not enabled';
 end if;
 if coalesce(p_sha256,'') !~ '^[a-f0-9]{64}$' or coalesce(btrim(p_carrier),'')='' then raise exception 'Attachment and carrier required'; end if;
 select * into d from public.manual_deliveries where order_id=o.id;
 if found then
  if d.attachment_sha256<>p_sha256 or d.sample_only<>p_sample or d.carrier<>p_carrier
   or d.tracking_number is distinct from p_tracking or d.provider_label_reference is distinct from p_label_reference
   then raise exception 'Existing delivery differs; operator review required'; end if;
  return d.id;
 end if;
 insert into public.manual_deliveries(order_id,recipient,sample_only,carrier,tracking_number,provider_label_reference,attachment_sha256)
 values(o.id,recipient_email,p_sample,p_carrier,p_tracking,p_label_reference,p_sha256) returning id into d.id;
 return d.id;
end $$;

create function public.claim_manual_delivery(p_delivery_id uuid)
returns setof public.manual_deliveries language sql security definer set search_path='' as $$
 update public.manual_deliveries set state='sending',claimed_at=now()
 where id=p_delivery_id and state='prepared' returning *;
$$;

create function public.confirm_manual_delivery(p_delivery_id uuid,p_mail_reference text)
returns void language plpgsql security definer set search_path='' as $$
declare d public.manual_deliveries;
begin
 if coalesce(btrim(p_mail_reference),'')='' or length(p_mail_reference)>500 then raise exception 'Sent-mail evidence required'; end if;
 select * into d from public.manual_deliveries where id=p_delivery_id for update;
 if not found then raise exception 'Delivery missing'; end if;
 if d.state='sent' and d.mail_reference=p_mail_reference then return; end if;
 if d.state<>'sending' then raise exception 'Delivery not awaiting confirmation'; end if;
 update public.manual_deliveries set state='sent',sent_at=now(),mail_reference=p_mail_reference where id=d.id;
 -- Sample delivery must never mark the order fulfilled or imply real postage.
end $$;
revoke all on function public.prepare_manual_delivery(uuid,text,boolean,text,text,text),public.claim_manual_delivery(uuid),public.confirm_manual_delivery(uuid,text) from public,anon,authenticated;
grant execute on function public.prepare_manual_delivery(uuid,text,boolean,text,text,text),public.claim_manual_delivery(uuid),public.confirm_manual_delivery(uuid,text) to service_role;
commit;
