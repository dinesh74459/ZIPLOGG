begin;
do $$
declare u uuid; o uuid; j uuid; j2 uuid; n integer;
begin
select id into u from auth.users limit 1;
if u is null then raise exception 'Test needs existing user'; end if;
insert into public.checkout_orders(user_id,checkout_session_id,total_cents,shippo_shipment_id,shippo_rate_id,quote_snapshot) values(u,'cs_guard_'||gen_random_uuid(),2200,'test_shipment','test_rate','{}') returning id into o;
select public.enqueue_paid_order(o,checkout_session_id,'pi_guard_'||o,'evt_guard_'||o,2200,'usd',false) into j from public.checkout_orders where id=o;
select public.enqueue_paid_order(o,checkout_session_id,'pi_guard_'||o,'evt_duplicate_'||o,2200,'usd',false) into j2 from public.checkout_orders where id=o;
if j is distinct from j2 then raise exception 'Duplicate job created'; end if;
select count(*) into n from public.claim_fulfillment_job(j);
if n <> 1 then raise exception 'First claim failed'; end if;
select count(*) into n from public.claim_fulfillment_job(j);
if n <> 0 then raise exception 'Duplicate claim allowed'; end if;
if has_function_privilege('authenticated','public.claim_fulfillment_job(uuid)','EXECUTE') or has_function_privilege('anon','public.enqueue_paid_order(uuid,text,text,text,bigint,text,boolean)','EXECUTE') then raise exception 'Public execution allowed'; end if;
end $$;
select 'PASS: duplicate event reuses job; second claim blocked; customer execution denied; test data rolled back' as verification;
rollback;