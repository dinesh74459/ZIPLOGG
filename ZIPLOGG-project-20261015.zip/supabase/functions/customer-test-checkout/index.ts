// Authenticated TEST checkout. No rates or eligibility accepted from the browser.
import { createClient } from 'npm:@supabase/supabase-js@2.117.2';
Deno.serve(async req=>{
 const origin=req.headers.get('origin')||'';
 const allowed=['https://ziplogg.com','https://www.ziplogg.com','https://ziplogg.pages.dev'];
 const headers={'Content-Type':'application/json','Cache-Control':'no-store','Access-Control-Allow-Origin':allowed.includes(origin)?origin:'https://ziplogg.com','Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info','Access-Control-Allow-Methods':'POST, OPTIONS','Vary':'Origin'};
 const reply=(status:number,body:object)=>new Response(JSON.stringify(body),{status,headers});
 if(origin&&!allowed.includes(origin))return reply(403,{error:'Origin not allowed'});
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers});
 if(req.method!=='POST')return reply(405,{error:'POST required'});
 const key=Deno.env.get('ZIPLOGG_STRIPE_TEST_KEY');
 if(!key||!/^(sk|rk)_test_/.test(key))return reply(503,{error:'Test checkout unavailable'});
 try{
  const token=req.headers.get('authorization')?.replace(/^Bearer /i,'');
  if(!token)return reply(401,{error:'Sign in first'});
  const db=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false,autoRefreshToken:false}});
  const {data:identity,error:authError}=await db.auth.getUser(token);
  if(authError||!identity.user?.email_confirmed_at)return reply(401,{error:'Verified account required'});
  const raw=await req.text();if(raw.length>1024)return reply(413,{error:'Request too large'});
  const input=JSON.parse(raw),uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  if(input.action==='list'){
   const [quotes,orders]=await Promise.all([
    db.from('retail_quotes').select('id,fedex_retail_cents,expires_at,test_fixture:evidence->test_fixture').eq('user_id',identity.user.id).eq('live_mode',false).not('fedex_retail_cents','is',null).eq('pricing_policy','fedex_45_v2').gt('expires_at',new Date().toISOString()).order('created_at',{ascending:false}).limit(50),
    db.from('checkout_orders').select('id,retail_quote_id,total_cents,promo_code,status,created_at').eq('user_id',identity.user.id).eq('live_mode',false).not('retail_quote_id','is',null).order('created_at',{ascending:false}).limit(100)
   ]);
   if(quotes.error||orders.error)throw new Error('Order lookup failed');
   return reply(200,{test_only:true,quotes:(quotes.data||[]).map(q=>({id:q.id,test_fixture:q.test_fixture===true,fedex_retail_cents:Number(q.fedex_retail_cents),regular_cents:Math.round(Number(q.fedex_retail_cents)*45/100),expires_at:q.expires_at})),orders:orders.data||[]});
  }
  if(input.action==='cancel'){
   if(!uuid.test(input.order_id||''))return reply(400,{error:'Valid order required'});
   const {data:order,error:lookupError}=await db.from('checkout_orders').select('*').eq('id',input.order_id).eq('user_id',identity.user.id).maybeSingle();
   if(lookupError||!order||order.live_mode!==false||!order.retail_quote_id)return reply(404,{error:'Test checkout not found'});
   if(order.status==='cancelled')return reply(200,{test_only:true,cancelled:true});
   if(order.status!=='awaiting_payment')return reply(409,{error:'Payment is already being processed'});
   if(!order.checkout_session_id.startsWith('cs_test_'))return reply(409,{error:'Checkout creation is unresolved. Retry the original checkout before cancelling.'});
   const path='https://api.stripe.com/v1/checkout/sessions/'+encodeURIComponent(order.checkout_session_id);
   const retrieve=async()=>{const r=await fetch(path,{headers:{Authorization:'Bearer '+key},signal:AbortSignal.timeout(20000)});if(!r.ok)throw new Error('Stripe unavailable');return r.json();};
   let session=await retrieve();
   const matches=()=>session.id===order.checkout_session_id&&session.livemode===false&&session.client_reference_id===order.id&&session.amount_total===order.total_cents&&session.currency==='usd';
   if(!matches()||session.payment_status!=='unpaid')return reply(409,{error:'Payment state prevents cancellation'});
   if(session.status==='open'){
    const expired=await fetch(path+'/expire',{method:'POST',headers:{Authorization:'Bearer '+key,'Idempotency-Key':'ziplogg-expire-'+order.id},signal:AbortSignal.timeout(20000)});
    if(!expired.ok)return reply(409,{error:'Could not confirm expiration. Your reservation is kept safe; retry later.'});
    session=await retrieve();
   }
   if(!matches()||session.status!=='expired'||session.payment_status!=='unpaid')return reply(409,{error:'Expiration not confirmed; reservation retained'});
   const {error:releaseError}=await db.rpc('release_expired_test_checkout',{p_order_id:order.id,p_user_id:identity.user.id,p_session_id:session.id});
   if(releaseError)throw new Error('Release failed');
   return reply(200,{test_only:true,cancelled:true});
  }
  if(input.action&&input.action!=='create')return reply(400,{error:'Unknown checkout action'});
  if(!uuid.test(input.order_id||'')||!uuid.test(input.quote_id||'')||typeof(input.promo_code??'')!=='string')return reply(400,{error:'Valid order and quote required'});
  if(input.adjustment_consent!==true||input.consent_version!=='adjustments-test-v1')return reply(400,{error:'Please review and select the separate test adjustment-policy checkbox.'});
  const {data:order,error:reserveError}=await db.rpc('reserve_test_checkout',{p_order_id:input.order_id,p_user_id:identity.user.id,p_quote_id:input.quote_id,p_code:input.promo_code||''});
  if(reserveError||!order)return reply(409,{error:'Quote expired, checkout already pending, or promo not eligible. Please review your account.'});
  if(order.live_mode!==false||!Number.isSafeInteger(order.total_cents)||order.total_cents<1)return reply(409,{error:'Invalid test order'});
  const {error:consentError}=await db.rpc('record_test_adjustment_consent',{p_order_id:order.id,p_user_id:identity.user.id,p_version:input.consent_version,p_accepted:input.adjustment_consent});
  if(consentError)throw new Error('Consent not recorded');
  const params=new URLSearchParams({mode:'payment',client_reference_id:order.id,'metadata[order_id]':order.id,success_url:'https://ziplogg.com/account?checkout=test-complete',cancel_url:'https://ziplogg.com/account?checkout=test-cancelled','line_items[0][price_data][currency]':'usd','line_items[0][price_data][unit_amount]':String(order.total_cents),'line_items[0][price_data][product_data][name]':'ZIPLOGG TEST shipment — no postage','line_items[0][quantity]':'1'});
  const existing=!order.checkout_session_id.startsWith('pending_');
  if(!existing&&order.created_at&&Date.now()-Date.parse(order.created_at)>23*60*60*1000)return reply(409,{error:'This unresolved checkout needs support review before retrying.'});
  const response=await fetch('https://api.stripe.com/v1/checkout/sessions'+(existing?'/'+encodeURIComponent(order.checkout_session_id):''),{method:existing?'GET':'POST',headers:{Authorization:'Bearer '+key,...(!existing?{'Content-Type':'application/x-www-form-urlencoded','Idempotency-Key':'ziplogg-customer-test-'+order.id}:{})},body:existing?undefined:params,signal:AbortSignal.timeout(20000)});
  if(!response.ok)throw new Error('Stripe unavailable');
  const session=await response.json();
  if(session.livemode!==false||session.amount_total!==order.total_cents||session.client_reference_id!==order.id||session.status!=='open'||typeof session.url!=='string'||!session.url.startsWith('https://checkout.stripe.com/'))throw new Error('Session mismatch');
  const {error:bindError}=await db.rpc('bind_test_checkout',{p_order_id:order.id,p_session_id:session.id,p_amount:session.amount_total});
  if(bindError)throw new Error('Session not bound');
  return reply(200,{test_only:true,checkout_url:session.url,total_cents:order.total_cents,promo_code:order.promo_code});
 }catch{return reply(503,{error:'Checkout could not finish. Retry using the same order ID. No new discount reservation is needed.'});}
});
