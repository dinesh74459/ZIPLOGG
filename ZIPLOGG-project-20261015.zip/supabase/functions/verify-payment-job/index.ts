// TEST ONLY. Make passes a Stripe event ID; payment facts are retrieved from Stripe.
// Secrets stay in Supabase. No public client may call this worker endpoint.
import { createClient } from 'npm:@supabase/supabase-js@2.117.2';

const reply = (status: number, body: object) => new Response(JSON.stringify(body), {
  status, headers: {'Content-Type':'application/json', 'Cache-Control':'no-store'},
});
async function equalSecret(a: string, b: string) {
  const digest = async (s: string) => new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)));
  const [x,y] = await Promise.all([digest(a),digest(b)]);
  let mismatch = 0;
  for (let i=0;i<x.length;i++) mismatch |= x[i]^y[i];
  return mismatch === 0;
}

Deno.serve(async req => {
  if (req.method !== 'POST') return reply(405,{error:'POST required'});
  const workerSecret = Deno.env.get('ZIPLOGG_MAKE_TEST_SECRET');
  const stripeKey = Deno.env.get('ZIPLOGG_STRIPE_TEST_KEY');
  if (!workerSecret || !stripeKey || !/^(sk|rk)_test_/.test(stripeKey)) return reply(503,{error:'Test connection not configured'});
  if (!await equalSecret(req.headers.get('x-ziplogg-worker') || '',workerSecret)) return reply(401,{error:'Unauthorized'});
  try {
    const raw = await req.text();
    if (raw.length > 2048) return reply(413,{error:'Request too large'});
    const input = JSON.parse(raw);
    if (typeof input.event_id !== 'string' || !/^evt_[A-Za-z0-9]+$/.test(input.event_id)) return reply(400,{error:'Valid event_id required'});
    const stripe = async (path: string) => {
      const response = await fetch('https://api.stripe.com/v1/'+path,{
        headers:{Authorization:`Bearer ${stripeKey}`},signal:AbortSignal.timeout(15000),
      });
      if (!response.ok) throw new Error('Stripe lookup failed');
      return response.json();
    };
    const event = await stripe('events/'+encodeURIComponent(input.event_id));
    if (event.livemode !== false || !['checkout.session.completed','checkout.session.async_payment_succeeded'].includes(event.type)) return reply(422,{error:'Not a supported test checkout event'});
    const session = await stripe('checkout/sessions/'+encodeURIComponent(event.data.object.id));
    if (session.mode !== 'payment' || session.livemode !== false || session.payment_status !== 'paid' || typeof session.payment_intent !== 'string') return reply(422,{error:'Test payment not settled'});
    const payment = await stripe('payment_intents/'+encodeURIComponent(session.payment_intent));
    if (payment.livemode !== false || payment.status !== 'succeeded') return reply(422,{error:'Test payment not succeeded'});
    const orderId = session.metadata?.order_id;
    if (typeof orderId !== 'string' || !/^[0-9a-f-]{36}$/i.test(orderId) || session.client_reference_id !== orderId) return reply(422,{error:'Missing trusted order reference'});
    const db = createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false,autoRefreshToken:false}});
    const {data:order,error:orderError} = await db.from('checkout_orders').select('*').eq('id',orderId).single();
    if (orderError || !order) return reply(422,{error:'Order unavailable'});
    if (order.live_mode !== false || order.checkout_session_id !== session.id || !Number.isSafeInteger(order.total_cents) || order.total_cents <= 0 ||
      [session.amount_total,payment.amount,payment.amount_received].some(n=>n!==order.total_cents) ||
      [order.currency,session.currency,payment.currency].some(c=>c!=='usd')) return reply(422,{error:'Payment does not match order'});
    const {data:existing,error:jobError} = await db.from('fulfillment_jobs').select('id,stripe_payment_intent_id').eq('order_id',orderId).maybeSingle();
    if (jobError) throw new Error('Job lookup failed');
    if (existing) return reply(200,{duplicate:true,job_id:existing.id,ready:false});
    if (order.status !== 'awaiting_payment' || !order.shippo_shipment_id || !order.shippo_rate_id) return reply(422,{error:'Order not eligible'});
    const {data:jobId,error:enqueueError} = await db.rpc('enqueue_paid_order',{
      p_order_id:order.id,p_session_id:session.id,p_payment_id:payment.id,p_event_id:event.id,
      p_amount:payment.amount_received,p_currency:payment.currency,p_live:false,
    });
    if (enqueueError) throw new Error('Enqueue failed');
    // Durable queue only: a separate authenticated worker must atomically claim the
    // job. Keeping enqueue separate avoids losing a claim on a network timeout.
    return reply(200,{ready:false,queued:true,job_id:jobId});
  } catch {
    // Never echo credentials, addresses, provider bodies or labels into logs.
    return reply(503,{error:'Verification unavailable; retry the same event'});
  }
});
