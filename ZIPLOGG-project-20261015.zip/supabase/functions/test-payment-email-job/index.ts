// Private Make worker. Only supplies/acknowledges a test email; never sends itself.
import { createClient } from 'npm:@supabase/supabase-js@2.117.2';
Deno.serve(async req=>{
 const reply=(status:number,body:object)=>new Response(JSON.stringify(body),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
 if(req.method!=='POST')return reply(405,{error:'POST required'});
 const secret=Deno.env.get('ZIPLOGG_MAKE_TEST_SECRET');
 if(!secret)return reply(503,{error:'Test worker unavailable'});
 const digest=async(s:string)=>new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)));
 const [a,b]=await Promise.all([digest(secret),digest(req.headers.get('x-ziplogg-worker')||'')]);let difference=0;for(let i=0;i<a.length;i++)difference|=a[i]^b[i];
 if(difference)return reply(401,{error:'Unauthorized'});
 try{
  const raw=await req.text();if(raw.length>2048)return reply(413,{error:'Request too large'});
  const input=JSON.parse(raw),uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  const db=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false,autoRefreshToken:false}});
  if(input.action==='claim'){
   if(!uuid.test(input.job_id||''))return reply(400,{error:'Valid job required'});
   const {data,error}=await db.rpc('claim_test_payment_email',{p_job_id:input.job_id});if(error)throw new Error('claim');
   if(!data?.length)return reply(200,{test_only:true,send:false});
   const item=data[0];if(item.recipient!=='operations@ziplogg.com'||!Number.isSafeInteger(item.total_cents))throw new Error('payload');
   const reference=item.order_id.slice(0,8);
   return reply(200,{test_only:true,send:true,email_id:item.email_id,claim_token:item.claim_token,to:item.recipient,subject:'[TEST] ZIPLOGG payment verified — '+reference,text:'TEST ONLY — NO REAL PAYMENT OR POSTAGE\n\nOrder: '+reference+'\nTest amount: USD '+(item.total_cents/100).toFixed(2)+'\n\nYour test payment has been verified. Label processing is not enabled and no postage has been purchased. Do not pay again.\n\nZIPLOGG support: operations@ziplogg.com | 831-809-0310'});
  }
  if(input.action==='confirm'){
   if(!uuid.test(input.email_id||'')||!uuid.test(input.claim_token||'')||typeof input.provider_reference!=='string'||!input.provider_reference.trim()||input.provider_reference.length>500)return reply(400,{error:'Valid claim and provider reference required'});
   const {error}=await db.rpc('confirm_test_payment_email',{p_email_id:input.email_id,p_claim_token:input.claim_token,p_reference:input.provider_reference.trim()});if(error)return reply(409,{error:'Claim or delivery state mismatch'});
   return reply(200,{test_only:true,recorded:true});
  }
  return reply(400,{error:'Unknown action'});
 }catch{return reply(503,{error:'Email state could not be confirmed. Do not resend; inspect the outbox and provider history.'});}
});
