import { createClient } from 'npm:@supabase/supabase-js@2.117.2';
const MAX=2097152,BUCKET='ziplogg-test-labels';
const sha=async(bytes:Uint8Array)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))).map(n=>n.toString(16).padStart(2,'0')).join('');
Deno.serve(async req=>{
 const origin=req.headers.get('origin')||'',allowed=['https://ziplogg.com','https://www.ziplogg.com','https://ziplogg.pages.dev'];
 const headers={'Content-Type':'application/json','Cache-Control':'no-store','Access-Control-Allow-Origin':allowed.includes(origin)?origin:allowed[0],'Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info','Access-Control-Allow-Methods':'POST, OPTIONS','Vary':'Origin'};
 const reply=(status:number,body:object)=>new Response(JSON.stringify(body),{status,headers});
 if(origin&&!allowed.includes(origin))return reply(403,{error:'Origin not allowed'});
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers});
 if(req.method!=='POST')return reply(405,{error:'POST required'});
 try{
  const token=req.headers.get('authorization')?.replace(/^Bearer /i,'');
  if(!token)return reply(401,{error:'Sign in to your approved staff account.'});
  const db=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false,autoRefreshToken:false}});
  const {data:identity,error:authError}=await db.auth.getUser(token);
  if(authError||!identity.user?.email_confirmed_at)return reply(401,{error:'Verified staff account required.'});
  const {data:operator,error:accessError}=await db.from('test_label_operators').select('user_id').eq('user_id',identity.user.id).eq('enabled',true).maybeSingle();
  if(accessError||!operator)return reply(403,{error:'This account does not have staff access.'});
  // Enforce a streaming limit even when Content-Length is absent.
  const reader=req.body?.getReader();let size=0;const chunks:Uint8Array[]=[];
  if(!reader)return reply(400,{error:'Request required'});
  while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>MAX*1.4+4096){await reader.cancel();return reply(413,{error:'PDF must be 2 MB or smaller.'});}chunks.push(value);}
  const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
  let input;try{input=JSON.parse(new TextDecoder().decode(bytes));}catch{return reply(400,{error:'Invalid request'});}
  if(input.action==='list'){
   const {data:orders,error}=await db.from('checkout_orders').select('id,total_cents,status,created_at,fulfillment_jobs!inner(id),manual_deliveries(id,state,recipient,storage_path,sent_at,mail_reference)').eq('live_mode',false).in('status',['queued','manual_review']).order('created_at',{ascending:false}).limit(50);
   if(error)throw new Error('lookup');
   return reply(200,{test_only:true,orders:orders||[]});
  }
  if(!['upload','download','claim','confirm'].includes(input.action))return reply(400,{error:'Unknown action'});
  if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(input.order_id||''))return reply(400,{error:'Valid order required'});
  const {data:order,error:orderError}=await db.from('checkout_orders').select('id,live_mode,status,fulfillment_jobs!inner(id)').eq('id',input.order_id).maybeSingle();
  const job=Array.isArray(order?.fulfillment_jobs)?order.fulfillment_jobs[0]:order?.fulfillment_jobs;
  if(orderError||!order||order.live_mode!==false||!['queued','manual_review'].includes(order.status)||!job?.id)return reply(409,{error:'Verified paid test order required.'});
  if(input.action==='upload'){
   if(input.sample_confirmed!==true||typeof input.pdf_base64!=='string'||input.pdf_base64.length>Math.ceil(MAX/3)*4||!/^[A-Za-z0-9+/]+={0,2}$/.test(input.pdf_base64))return reply(400,{error:'Choose a sample PDF and confirm it is not valid postage.'});
   let pdf;try{pdf=Uint8Array.from(atob(input.pdf_base64),c=>c.charCodeAt(0));}catch{return reply(400,{error:'Invalid PDF encoding'});}
   if(pdf.length>MAX||pdf.length<8||new TextDecoder().decode(pdf.slice(0,5))!=='%PDF-')return reply(400,{error:'A PDF of 2 MB or smaller is required.'});
   const hash=await sha(pdf),path=order.id+'/'+hash+'.pdf';
   const {data:deliveryId,error:prepareError}=await db.rpc('prepare_manual_delivery',{p_order_id:order.id,p_sha256:hash,p_sample:true,p_carrier:'SAMPLE — NOT VALID FOR SHIPPING',p_tracking:null,p_label_reference:null});
   if(prepareError||!deliveryId)return reply(409,{error:'A different file may already be attached. Refresh and review; do not resend.'});
   const {error:uploadError}=await db.storage.from(BUCKET).upload(path,pdf,{contentType:'application/pdf',upsert:false});
   if(uploadError){
    // A timeout/retry is safe only if the stored file matches exactly.
    const existing=await db.storage.from(BUCKET).download(path);
    if(existing.error||!existing.data||await sha(new Uint8Array(await existing.data.arrayBuffer()))!==hash)throw new Error('upload');
   }
   const {error:recordError}=await db.from('manual_deliveries').update({storage_path:path}).eq('id',deliveryId).eq('attachment_sha256',hash);
   if(recordError)throw new Error('record');
   return reply(200,{test_only:true,message:'Sample PDF stored privately. No email has been sent.'});
  }
  const {data:delivery,error:deliveryError}=await db.from('manual_deliveries').select('*').eq('order_id',order.id).eq('sample_only',true).maybeSingle();
  if(deliveryError||!delivery||delivery.storage_path!==order.id+'/'+delivery.attachment_sha256+'.pdf')return reply(409,{error:'Upload the sample PDF first.'});
  if(input.action==='download'){
   const {data,error}=await db.storage.from(BUCKET).createSignedUrl(delivery.storage_path,60,{download:'ZIPLOGG-SAMPLE-NOT-VALID-FOR-SHIPPING.pdf'});
   if(error||!data)throw new Error('download');
   return reply(200,{test_only:true,url:data.signedUrl});
  }
  if(input.action==='claim'){
   const stored=await db.storage.from(BUCKET).download(delivery.storage_path);
   if(stored.error||!stored.data||await sha(new Uint8Array(await stored.data.arrayBuffer()))!==delivery.attachment_sha256)throw new Error('attachment');
   const {data,error}=await db.rpc('claim_manual_delivery',{p_delivery_id:delivery.id});
   if(error||!data?.length)return reply(409,{error:'Already claimed or sent. Check Zoho Sent mail before any further action.'});
   return reply(200,{test_only:true,message:'Reserved for manual sending to operations@ziplogg.com. This button does not send email.'});
  }
  if(input.sent_confirmed!==true||typeof input.mail_reference!=='string'||!input.mail_reference.trim()||input.mail_reference.length>500)return reply(400,{error:'Confirm the email was sent and enter its message reference.'});
  const {error:confirmError}=await db.rpc('confirm_manual_delivery',{p_delivery_id:delivery.id,p_mail_reference:input.mail_reference.trim()});
  if(confirmError)return reply(409,{error:'Delivery is not awaiting confirmation, or the recorded reference differs.'});
  return reply(200,{test_only:true,message:'Manual test delivery recorded. The order has not been marked as a real shipment.'});
 }catch{return reply(503,{error:'The operation could not be confirmed. Refresh the order before retrying. Do not send an email twice.'});}
});
