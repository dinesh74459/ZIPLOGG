// Private integration fixture. NOT the public customer checkout endpoint.
// Fixed demonstration addresses and 20 lb parcel; no real postage or live payments.
import { createClient } from 'npm:@supabase/supabase-js@2.117.2';
const reply=(status:number,body:object)=>new Response(JSON.stringify(body),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
async function same(a:string,b:string){
 const hash=async(s:string)=>new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)));
 const [x,y]=await Promise.all([hash(a),hash(b)]);let d=0;for(let i=0;i<x.length;i++)d|=x[i]^y[i];return d===0;
}
Deno.serve(async req=>{
 if(req.method!=='POST')return reply(405,{error:'POST required'});
 const secret=Deno.env.get('ZIPLOGG_MAKE_TEST_SECRET'),sk=Deno.env.get('ZIPLOGG_STRIPE_TEST_KEY'),shipKey=Deno.env.get('ZIPLOGG_SHIPPO_TEST_KEY');
 if(!secret||!sk||!shipKey||!/^(sk|rk)_test_/.test(sk)||!shipKey.startsWith('shippo_test_'))return reply(503,{error:'Test credentials required'});
 if(!await same(req.headers.get('x-ziplogg-worker')||'',secret))return reply(401,{error:'Unauthorized'});
 let stage='input';
 try{
  const raw=await req.text();if(raw.length>1024)return reply(413,{error:'Request too large'});
  const input=JSON.parse(raw);
  const id=input.request_id;
  if(typeof id!=='string'||!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id))return reply(400,{error:'A stable UUID v4 request_id is required'});
  stage='carrier_accounts';
  const shippo=async(path:string,body?:object)=>{
   const r=await fetch('https://api.goshippo.com/'+path,{method:body?'POST':'GET',headers:{Authorization:'ShippoToken '+shipKey,'Content-Type':'application/json','SHIPPO-API-VERSION':'2018-02-08'},body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(25000)});
   if(!r.ok)throw new Error('Provider response');return r.json();
  };
  const accounts=await shippo('carrier_accounts/?results=100');
  const fedex=(accounts.results||[]).filter((a:any)=>a.carrier==='fedex'&&a.active===true);
  if(!fedex.length)return reply(409,{error:'No active FedEx test carrier account',stage,test_only:true});
  stage='shipment_rates';
  const from={name:'ZIPLOGG TEST Sender',street1:'215 Clayton St',city:'San Francisco',state:'CA',zip:'94117',country:'US',phone:'+14155550100'};
  const to={name:'ZIPLOGG TEST Recipient',street1:'965 Mission St',city:'San Francisco',state:'CA',zip:'94103',country:'US',phone:'+14155550101'};
  const parcel={length:'20',width:'14',height:'10',distance_unit:'in',weight:'20',mass_unit:'lb'};
  const shipment=await shippo('shipments/',{address_from:from,address_to:to,parcels:[parcel],carrier_accounts:fedex.map((a:any)=>a.object_id),async:false,metadata:'ZIPLOGG test fixture '+id});
  if(shipment.test!==true)return reply(409,{error:'Provider did not confirm test shipment',stage,test_only:true});
  const rates=(shipment.rates||[]).filter((r:any)=>r.provider==='FedEx'&&r.currency==='USD'&&Number.isFinite(Number(r.amount))&&Number(r.amount)>0).sort((a:any,b:any)=>Number(a.amount)-Number(b.amount));
  if(!rates.length)return reply(409,{error:'FedEx did not return a test rate',stage,test_only:true,message_codes:(shipment.messages||[]).map((m:any)=>({source:m.source,code:m.code,text:String(m.text||'').slice(0,800)}))});
  const rate=rates[0];
  if(input.probe_only===true)return reply(200,{test_only:true,fedex_ready:true,rate_count:rates.length,sample_postage:rate.amount,currency:rate.currency,service:rate.servicelevel?.token});
  stage='test_account';
  const db=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false,autoRefreshToken:false}});
  const {data:users,error:userError}=await db.auth.admin.listUsers({page:1,perPage:100});
  if(userError)throw new Error('Account lookup');
  const user=users.users.find((u:any)=>u.email?.toLowerCase()==='operations@ziplogg.com');
  if(!user)return reply(409,{error:'Approved operations test customer account is missing',stage});
  const stripe=async(path:string,body?:URLSearchParams)=>{
   const r=await fetch('https://api.stripe.com/v1/'+path,{method:body?'POST':'GET',headers:{Authorization:'Bearer '+sk,...(body?{'Content-Type':'application/x-www-form-urlencoded','Idempotency-Key':'ziplogg-demo-'+id}:{})},body,signal:AbortSignal.timeout(20000)});
   if(!r.ok)throw new Error('Stripe response');return r.json();
  };
  stage='order_lookup';
  const {data:existing,error:readError}=await db.from('checkout_orders').select('*').eq('id',id).maybeSingle();
  if(readError)throw new Error('Order read');
  if(existing){
   if(existing.live_mode!==false||existing.user_id!==user.id||existing.quote_snapshot?.fixture!==true)return reply(409,{error:'Request ID already in use'});
   const session=await stripe('checkout/sessions/'+encodeURIComponent(existing.checkout_session_id));
   return reply(200,{test_only:true,order_id:id,checkout_url:session.url,status:session.status,reused:true});
  }
  stage='stripe_checkout';
  const params=new URLSearchParams({mode:'payment',client_reference_id:id,'metadata[order_id]':id,'metadata[ziplogg_test_fixture]':'true',customer_email:'operations@ziplogg.com',success_url:'https://ziplogg.com/account?checkout=test-complete',cancel_url:'https://ziplogg.com/personal?checkout=test-cancelled','line_items[0][price_data][currency]':'usd','line_items[0][price_data][unit_amount]':'2200','line_items[0][price_data][product_data][name]':'ZIPLOGG TEST ONLY — Small 20 lb — first shipment','line_items[0][quantity]':'1'});
  const session=await stripe('checkout/sessions',params);
  if(session.livemode!==false||session.amount_total!==2200||!session.url)throw new Error('Unexpected session');
  stage='save_order';
  const {error:saveError}=await db.from('checkout_orders').insert({id,user_id:user.id,checkout_session_id:session.id,total_cents:2200,currency:'usd',live_mode:false,shippo_shipment_id:shipment.object_id,shippo_rate_id:rate.object_id,quote_snapshot:{fixture:true,address_from:from,address_to:to,parcel,carrier:'FedEx',postage_cents:Math.round(Number(rate.amount)*100),service:rate.servicelevel?.token,customer_email:'operations@ziplogg.com'}});
  if(saveError)throw new Error('Save order');
  return reply(200,{test_only:true,order_id:id,checkout_url:session.url,total_cents:2200,currency:'usd'});
 }catch{return reply(503,{error:'Test setup could not complete',stage,test_only:true});}
});

