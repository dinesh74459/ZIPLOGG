// Private Make worker for LIVE paid-order notices to operations. Never sends email itself:
// claim returns one prepared notice; Make sends via Zoho; confirm records the Zoho message ID.
// An uncertain send is never reclaimed automatically; it appears in status as stuck.
import {createClient} from 'npm:@supabase/supabase-js@2.117.2';
const OPS='operations@ziplogg.com';
const clean=(v:unknown,max=200)=>String(v??'').replace(/[\u0000-\u001f\u007f]+/g,' ').trim().slice(0,max);
const usd=(c:number)=>'USD '+(c/100).toFixed(2);
const party=(p:any)=>{
 if(!p||typeof p!=='object')return '  (not recorded in quote; see summary)';
 const line=[clean(p.city),[clean(p.region),clean(p.postal)].filter(Boolean).join(' ')].filter(Boolean).join(', ');
 return ['  Name: '+(clean(p.name)||'(missing)'),'  Phone: '+(clean(p.phone)||'(missing)'),'  Street: '+(clean(p.street)||'(missing)'),'  City/State/ZIP: '+(line||'(missing)'),'  Country: '+(clean(p.country)||'(missing)')].join('\n');
};
function liveNotice(n:any){
 const ref=clean(n.order_id,36).slice(0,8),s=n.shipment&&typeof n.shipment==='object'?n.shipment:{},p=s.package||{};
 const paid=n.paid_at?new Date(n.paid_at):null;
 const paidText=paid&&!isNaN(+paid)?paid.toLocaleString('en-US',{timeZone:'America/New_York',dateStyle:'medium',timeStyle:'long'})+' — label due by '+new Date(+paid+5*60000).toLocaleTimeString('en-US',{timeZone:'America/New_York',timeStyle:'short'}):'(missing — check Stripe)';
 const warn=n.order_state!=='paid'?`[ORDER STATE ${clean(n.order_state,20).toUpperCase()} — CHECK BEFORE SENDING] `:'';
 const one=(p:any)=>[p.weight!=null?clean(p.weight,12)+' lb':'',[p.length,p.width,p.height].every((x:unknown)=>x!=null)?[p.length,p.width,p.height].map(x=>clean(x,12)).join(' x ')+' in':'',p.packaging?(clean(p.packaging,10)==='box'?'box':'suitcase / unboxed'):''].filter(Boolean).join(', ');
 const pkg=Array.isArray(s.packages)&&s.packages.length?s.packages.slice(0,10).map((x:any,i:number)=>'\n  '+(i+1)+'. '+one(x||{})).join(''):one(p);
 const text=[
  'LIVE PAID ORDER — real customer payment verified with Stripe by ZIPLOGG.',
  ...(warn?['',warn.trim(),'']:[]),
  'Order: '+clean(n.order_id,36),
  'Paid: '+paidText,
  'Amount charged: '+usd(n.total_cents)+(n.promo_code?` (regular ${usd(n.regular_cents)}, ${clean(n.promo_code,10)} applied)`:''),
  'Stripe payment: '+clean(n.payment_id,100),
  'Customer account email (send label here): '+clean(n.customer_email,254),
  '',
  'Service: '+(clean(s.service,40)||'(see summary)'),
  'Ship date: '+(clean(s.ship_date,20)||'(not recorded)'),
  'Summary: '+clean(n.summary,400),
  'Pricing source: '+clean(n.pricing_source,40),
  '',
  'FROM',party(s.from),
  '',
  'TO',party(s.to),
  '',
  (Array.isArray(s.packages)&&s.packages.length?'PACKAGES ('+s.packages.length+'):'+pkg:'PACKAGE: '+(pkg||'(not recorded; see summary)')),
  '',
  'Before buying postage: confirm this payment shows Succeeded in the Stripe live dashboard.',
  'If this order reference has already been handled, do NOT buy or send a second label.',
  'This message is sent once per paid order to '+OPS+' only. Customer address data — do not forward.'
 ].join('\n');
 return {subject:`${warn}ZIPLOGG LIVE PAID ORDER ${ref} — send label within 5 min`,text};
}
Deno.serve(async req=>{
 const reply=(status:number,body:object)=>new Response(JSON.stringify(body),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
 if(req.method!=='POST')return reply(405,{error:'POST required'});
 const secret=Deno.env.get('ZIPLOGG_MAKE_LIVE_SECRET');
 if(!secret||secret.length<32)return reply(503,{error:'Live notification worker unavailable'});
 const digest=async(s:string)=>new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)));
 const [a,b]=await Promise.all([digest(secret),digest(req.headers.get('x-ziplogg-worker')||'')]);let difference=0;for(let i=0;i<a.length;i++)difference|=a[i]^b[i];
 if(difference)return reply(401,{error:'Unauthorized'});
 try{
  const raw=await req.text();if(raw.length>2048)return reply(413,{error:'Request too large'});
  const input=JSON.parse(raw||'{}'),uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  const db=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false,autoRefreshToken:false}});
  if(input.action==='claim'){
   const {data,error}=await db.rpc('claim_live_order_notification');if(error)throw new Error('claim');
   if(!data?.length)return reply(200,{live:true,send:false});
   const n=data[0];
   if(n.recipient!==OPS||!uuid.test(n.email_id||'')||!uuid.test(n.claim_token||'')||!Number.isSafeInteger(n.total_cents)||!/^pi_/.test(n.payment_id||''))throw new Error('payload');
   return reply(200,{live:true,send:true,email_id:n.email_id,claim_token:n.claim_token,to:OPS,...liveNotice(n)});
  }
  if(input.action==='confirm'){
   if(!uuid.test(input.email_id||'')||!uuid.test(input.claim_token||'')||typeof input.provider_reference!=='string'||!input.provider_reference.trim()||input.provider_reference.length>500)return reply(400,{error:'Valid claim and provider reference required'});
   const {error}=await db.rpc('confirm_live_order_notification',{p_email_id:input.email_id,p_claim_token:input.claim_token,p_reference:input.provider_reference.trim()});
   if(error)return reply(409,{error:'Claim or delivery state mismatch'});
   return reply(200,{live:true,recorded:true});
  }
  if(input.action==='status'){
   const {data,error}=await db.rpc('live_order_notification_backlog');if(error||!data?.length)throw new Error('status');
   const s=data[0],num=(x:unknown)=>Number(x)||0;
   const result={pending:num(s.pending),stuck_sending:num(s.stuck_sending),review:num(s.review),oldest_pending_seconds:num(s.oldest_pending_seconds)};
   return reply(200,{live:true,...result,alert:result.stuck_sending>0||result.review>0||result.oldest_pending_seconds>120});
  }
  return reply(400,{error:'Unknown action'});
 }catch{return reply(503,{error:'Notice state could not be confirmed. Do not resend; check Zoho Sent and the outbox first.'});}
});
