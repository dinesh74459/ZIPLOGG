// Live checkout for individually approved manual-label shipments. No postage API.
import {createClient} from 'npm:@supabase/supabase-js@2.117.2';
Deno.serve(async req=>{
 const origin=req.headers.get('origin')||'';
 const allowed=['https://ziplogg.com','https://www.ziplogg.com','https://ziplogg.pages.dev'];
 const headers={'Content-Type':'application/json','Cache-Control':'no-store','Access-Control-Allow-Origin':allowed.includes(origin)?origin:allowed[0],'Access-Control-Allow-Headers':'authorization, apikey, content-type, x-client-info','Access-Control-Allow-Methods':'POST, OPTIONS','Vary':'Origin'};
 const reply=(status:number,data:object)=>new Response(JSON.stringify(data),{status,headers});
 if(origin&&!allowed.includes(origin))return reply(403,{error:'Origin not allowed'});
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers});
 if(req.method!=='POST')return reply(405,{error:'POST required'});
 const key=Deno.env.get('ZIPLOGG_STRIPE_LIVE_KEY');
 if(Deno.env.get('ZIPLOGG_LIVE_MANUAL_ENABLED')!=='true'||!key||!/^(rk|sk)_live_/.test(key))return reply(503,{error:'Live checkout is not activated yet. No payment has been taken.'});
 try{
  const raw=await req.text();if(raw.length>262144)return reply(413,{error:'Request too large'});
  const db=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false,autoRefreshToken:false}});
  const stripe=async(path:string,body?:URLSearchParams,idempotency?:string)=>{
   const response=await fetch('https://api.stripe.com/v1/'+path,{method:body?'POST':'GET',headers:{Authorization:'Bearer '+key,...(body?{'Content-Type':'application/x-www-form-urlencoded','Idempotency-Key':idempotency!}:{})},body,signal:AbortSignal.timeout(20000)});
   if(!response.ok)throw new Error('Stripe unavailable');return response.json();
  };
  const verify=async(order:any)=>{
   if(!order.session_id)return;
   const s=await stripe('checkout/sessions/'+encodeURIComponent(order.session_id));
   if(s.livemode!==true||s.id!==order.session_id||s.client_reference_id!==order.id||s.metadata?.ziplogg_flow!=='manual-v1'||s.amount_total!==order.total_cents||s.currency!=='usd')throw new Error('Session mismatch');
   if(s.payment_status==='paid'){
    if(s.mode!=='payment'||typeof s.payment_intent!=='string')throw new Error('Payment missing');
    const p=await stripe('payment_intents/'+encodeURIComponent(s.payment_intent));
    if(p.livemode!==true||p.status!=='succeeded'||p.currency!=='usd'||p.amount!==order.total_cents||p.amount_received!==order.total_cents)throw new Error('Unsettled payment');
    const {error}=await db.rpc('confirm_live_manual_payment',{p_order:order.id,p_session:s.id,p_payment:p.id,p_amount:p.amount_received});if(error)throw error;
    // Best-effort wake-up for the operations notice worker. Carries no data; the database outbox row
    // (migration 015) is the durable record, and a scheduled Make run picks it up if this call fails.
    const hook=Deno.env.get('ZIPLOGG_LIVE_NOTIFY_HOOK')||'';
    if(/^https:\/\/hook\.[a-z0-9]+\.make\.com\/[A-Za-z0-9]+$/.test(hook))await fetch(hook,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}',signal:AbortSignal.timeout(5000)}).catch(()=>{});
   }else if(s.status==='expired'&&s.payment_status==='unpaid'){
    const {error}=await db.from('live_manual_orders').update({state:'expired'}).eq('id',order.id).eq('session_id',s.id).eq('state','awaiting_payment');if(error)throw error;
   }
  };
  // Stripe POSTs its signed raw event. Verify signature AND retrieve current facts.
  if(req.headers.has('stripe-signature')){
   const secret=Deno.env.get('ZIPLOGG_STRIPE_LIVE_WEBHOOK_SECRET');if(!secret)return reply(503,{error:'Webhook not configured'});
   const parts=req.headers.get('stripe-signature')!.split(',').map(x=>x.split('='));
   const timestamp=parts.find(x=>x[0]==='t')?.[1];
   if(!timestamp||!/^\d+$/.test(timestamp)||Math.abs(Date.now()/1000-Number(timestamp))>300)return reply(400,{error:'Invalid signature timestamp'});
   const enc=new TextEncoder();const hmac=await crypto.subtle.importKey('raw',enc.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
   const signature=new Uint8Array(await crypto.subtle.sign('HMAC',hmac,enc.encode(timestamp+'.'+raw)));
   const valid=parts.filter(x=>x[0]==='v1'&&/^[0-9a-f]{64}$/.test(x[1]||'')).some(x=>{let diff=0;for(let i=0;i<32;i++)diff|=signature[i]^parseInt(x[1].slice(i*2,i*2+2),16);return diff===0;});
   if(!valid)return reply(400,{error:'Invalid signature'});
   const event=JSON.parse(raw);
   if(event.livemode!==true||!['checkout.session.completed','checkout.session.expired','checkout.session.async_payment_succeeded'].includes(event.type))return reply(200,{ignored:true});
   const session=event.data?.object;if(session?.metadata?.ziplogg_flow!=='manual-v1')return reply(200,{ignored:true});
   const {data:order,error}=await db.from('live_manual_orders').select('*').eq('session_id',session.id).maybeSingle();
   if(error||!order)throw new Error('Order binding pending');
   if(order.state==='awaiting_payment')await verify(order);
   return reply(200,{received:true});
  }
  if(raw.length>2048)return reply(413,{error:'Request too large'});
  const token=req.headers.get('authorization')?.replace(/^Bearer /i,'');
  if(!token)return reply(401,{error:'Sign in first'});
  const {data:identity,error:authError}=await db.auth.getUser(token);
  if(authError||!identity.user?.email_confirmed_at)return reply(401,{error:'Verified account required'});
  const uid=identity.user.id,input=JSON.parse(raw);
  if(input.action==='list'){
   const pending=await db.from('live_manual_orders').select('*').eq('user_id',uid).eq('state','awaiting_payment').limit(1);if(pending.error)throw pending.error;
   for(const o of pending.data||[])await verify(o);
   const [q,o]=await Promise.all([
    db.from('live_manual_quotes').select('id,summary,retail_cents,expires_at,pricing_source,price_cents,fee_cents').eq('user_id',uid).eq('fulfillment_ready',true).gt('expires_at',new Date().toISOString()).order('created_at',{ascending:false}).limit(30),
    db.from('live_manual_orders').select('id,total_cents,regular_cents,promo_code,state,paid_at,created_at').eq('user_id',uid).order('created_at',{ascending:false}).limit(100)
   ]);if(q.error||o.error)throw new Error('Lookup failed');
   return reply(200,{live:true,quotes:(q.data||[]).map(x=>({id:x.id,summary:x.summary,regular_cents:x.pricing_source==='flat_ground_v1'?Number(x.price_cents)+Number(x.fee_cents||0):Math.round(x.retail_cents*.45),expires_at:x.expires_at})),orders:o.data||[]});
  }
  if(input.action!=='create'||!/^([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i.test(input.quote_id||'')||typeof(input.promo_code??'')!=='string')return reply(400,{error:'Valid quote required'});
  if(input.accepted!==true||input.terms_version!=='manual-shipping-v1')return reply(400,{error:'Please accept the shipping and manual-delivery terms.'});
  const {data:order,error:reserveError}=await db.rpc('reserve_live_manual_checkout',{p_user:uid,p_quote:input.quote_id,p_promo:input.promo_code||''});
  if(reserveError||!order)return reply(409,{error:'Quote unavailable, another payment is pending, or JAYHO is not eligible. Refresh your orders.'});
  const quote=await db.from('live_manual_quotes').select('expires_at,summary').eq('id',order.id).single();if(quote.error)throw quote.error;
  if(!order.session_id&&Date.now()-Date.parse(order.created_at)>23*60*60*1000)return reply(409,{error:'This unresolved checkout needs ZIPLOGG review. Do not start another payment.'});
  const params=new URLSearchParams({mode:'payment','payment_method_types[0]':'card',client_reference_id:order.id,'metadata[ziplogg_flow]':'manual-v1','metadata[order_id]':order.id,customer_email:order.email,'payment_intent_data[receipt_email]':order.email,'payment_intent_data[metadata][order_id]':order.id,success_url:'https://ziplogg.com/pay?payment=returned',cancel_url:'https://ziplogg.com/pay?payment=cancelled',expires_at:String(Math.floor(Date.parse(quote.data.expires_at)/1000)),'line_items[0][price_data][currency]':'usd','line_items[0][price_data][unit_amount]':String(order.total_cents),'line_items[0][price_data][product_data][name]':'ZIPLOGG shipping — '+order.id.slice(0,8),'line_items[0][quantity]':'1','custom_text[submit][message]':'After confirmed payment, ZIPLOGG manually emails your shipping label from operations@ziplogg.com within 5 minutes.'});
  const session=order.session_id?await stripe('checkout/sessions/'+encodeURIComponent(order.session_id)):await stripe('checkout/sessions',params,'ziplogg-live-manual-'+order.id);
  if(session.livemode!==true||session.client_reference_id!==order.id||session.amount_total!==order.total_cents||session.currency!=='usd'||session.status!=='open'||!session.id?.startsWith('cs_live_')||typeof session.url!=='string'||new URL(session.url).origin!=='https://checkout.stripe.com')throw new Error('Session mismatch');
  const bound=await db.rpc('bind_live_manual_checkout',{p_order:order.id,p_session:session.id,p_amount:session.amount_total});if(bound.error)throw bound.error;
  return reply(200,{live:true,checkout_url:session.url});
 }catch{return reply(503,{error:'Payment status could not be confirmed. Refresh the same order; do not pay again or start a different order.'});}
});
